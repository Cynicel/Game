(function () {
  const slider = document.getElementById("fwMusicVolume");
  const display = document.getElementById("fwMusicPercent");
  const music = document.getElementById("settingMusic");
  function render() {
    display.textContent = slider.value + "%";
    slider.style.opacity = music.checked ? "1" : ".55";
  }
  slider.addEventListener("input", function () {
    render();
    try {
      localStorage.setItem("fortress_music_volume", slider.value);
    } catch (e) {}
  });
  music.addEventListener("change", render);
  try {
    const v = localStorage.getItem("fortress_music_volume");
    if (v !== null) slider.value = v;
  } catch (e) {}
  render();
  const panel = document.getElementById("settingsPanel");
  new MutationObserver(function () {
    if (!panel.hidden) render();
  }).observe(panel, { attributes: true, attributeFilter: ["hidden"] });
})();
