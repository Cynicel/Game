(function () {
  const slider = document.getElementById("fwMusicVolume"),
    percent = document.getElementById("fwMusicPercent");
  function paint() {
    let value = Math.max(0, Math.min(100, Number(slider.value) || 0));
    slider.style.setProperty("--fw-progress", value + "%");
    percent.textContent = value + "%";
  }
  slider.addEventListener("input", paint);
  slider.addEventListener("change", paint);
  const p = document.getElementById("settingsPanel");
  new MutationObserver(paint).observe(p, { attributes: true, attributeFilter: ["hidden"] });
  paint();
})();
