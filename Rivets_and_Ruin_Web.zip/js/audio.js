// V15.60: Real sound effects and a looping battle theme (assets/sfx, assets/music).
// Replaces the synthesised placeholder sounds of game.js. If a file cannot be
// loaded the original synthesiser is used as a fallback.
(function () {
  "use strict";
  const SFX = [
    "cannon", "heavy", "autocannon", "mg", "sniper", "rocket", "mortar", "flak",
    "impact_small", "impact_large", "reactor", "wood_break", "build", "research", "click",
  ];
  const buffers = {};
  let loading = false;
  let musicBuffer = null,
    musicSource = null,
    musicGain = null;

  // Safari (iPhone/iPad) cannot decode Ogg Vorbis – it gets the same sounds as MP3.
  const EXT = (() => {
    try {
      return new Audio().canPlayType('audio/ogg; codecs="vorbis"') ? ".ogg" : ".mp3";
    } catch (e) {
      return ".ogg";
    }
  })();
  function load(ctx) {
    if (loading) return;
    loading = true;
    const get = (url) =>
      fetch(url)
        .then((r) => (r.ok ? r.arrayBuffer() : Promise.reject(r.status)))
        .then((data) => new Promise((ok, fail) => ctx.decodeAudioData(data, ok, fail)));
    for (const name of SFX)
      get("assets/sfx/" + name + EXT)
        .then((b) => (buffers[name] = b))
        .catch(() => {});
    get("assets/music/march_theme" + EXT) // V15.60: nostalgic march (tools/make_march.py)
      .then((b) => (musicBuffer = b))
      .catch(() => {});
  }

  const origReady = audioReady;
  audioReady = function () {
    const c = origReady();
    if (audioCtx) load(audioCtx);
    return c;
  };
  document.addEventListener("pointerdown", () => audioReady(), { passive: true });

  function play(name, volume, rateJitter = 0.04) {
    const ctx = audioReady();
    const buf = buffers[name];
    if (!ctx || !buf) return false;
    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.playbackRate.value = 1 + (Math.random() * 2 - 1) * rateJitter;
    const g = ctx.createGain();
    g.gain.value = volume;
    src.connect(g);
    g.connect(masterAudio);
    src.start();
    return true;
  }

  const WEAPON_VOLUME = { mg: 0.32, flak: 0.3, autocannon: 0.38, cannon: 0.5, sniper: 0.45, rocket: 0.5, mortar: 0.5, heavy: 0.62 };
  const origWeapon = playWeaponSound;
  let lastShot = 0;
  playWeaponSound = function (type) {
    if (!soundEnabled) return;
    const now = performance.now();
    if (now - lastShot < 42) return;
    if (buffers[type] && play(type, WEAPON_VOLUME[type] || 0.45)) {
      lastShot = now;
      return;
    }
    origWeapon(type);
  };

  const origImpact = playImpactSound;
  let lastImpact = 0;
  playImpactSound = function (damage, radius) {
    if (!soundEnabled) return;
    const now = performance.now();
    if (now - lastImpact < 85) return;
    const big = (radius || 95) >= 110 || (damage || 0) >= 80;
    const name = big ? "impact_large" : "impact_small";
    if (buffers[name] && play(name, big ? 0.6 : 0.42, 0.08)) {
      lastImpact = now;
      return;
    }
    origImpact(damage, radius);
  };

  const origBuild = playBuildSound;
  playBuildSound = function () {
    if (soundEnabled && !play("build", 0.32)) origBuild();
  };
  const origResearch = playResearchSound;
  playResearchSound = function () {
    if (soundEnabled && !play("research", 0.4, 0)) origResearch();
  };

  // Reactor destruction gets its own long explosion.
  const origFinish = finishRound;
  finishRound = function (core) {
    if (!gameOver && soundEnabled) play("reactor", 0.85, 0);
    return origFinish(core);
  };

  // Splintering wood whenever an explosion breaks at least one beam.
  const origExplode = explode;
  explode = function (x, y, damage, radius) {
    const before = beams.filter((b) => b.hp > 0).length;
    const r = origExplode.apply(this, arguments);
    const after = beams.filter((b) => b.hp > 0).length;
    if (soundEnabled && after < before) play("wood_break", Math.min(0.5, 0.25 + 0.08 * (before - after)), 0.1);
    return r;
  };

  // Battle theme: loops while music is on – in the main menu and during play
  // (not while paused). Volume follows the music slider.
  const origMusic = updateMusic;
  updateMusic = function (dt) {
    const ctx = audioCtx;
    if (!musicBuffer || !ctx || ctx.state !== "running") {
      if (!musicBuffer) origMusic(dt);
      return;
    }
    const menuOpen = document.getElementById("mainOverlay")?.hidden === false;
    const want = musicEnabled && (menuOpen || !paused);
    const target = want ? 0.34 * (window.fwMusicGain ? fwMusicGain() : 1) * (menuOpen ? 0.7 : 1) : 0;
    if (!musicSource && want) {
      musicGain = ctx.createGain();
      musicGain.gain.value = 0;
      musicGain.connect(masterAudio);
      musicSource = ctx.createBufferSource();
      musicSource.buffer = musicBuffer;
      musicSource.loop = true;
      musicSource.connect(musicGain);
      musicSource.start();
    }
    if (musicGain) {
      const g = musicGain.gain.value;
      musicGain.gain.value = g + (target - g) * Math.min(1, dt * 2.5);
      if (!want && musicGain.gain.value < 0.003 && musicSource) {
        try {
          musicSource.stop();
        } catch (e) {}
        musicSource.disconnect();
        musicGain.disconnect();
        musicSource = null;
        musicGain = null;
      }
    }
  };
})();
