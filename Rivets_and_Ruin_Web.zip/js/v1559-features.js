(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const store = {
    get(k, d) {
      try {
        const v = localStorage.getItem(k);
        return v == null ? d : JSON.parse(v);
      } catch (e) {
        return d;
      }
    },
    set(k, v) {
      try {
        localStorage.setItem(k, JSON.stringify(v));
      } catch (e) {}
    },
    del(k) {
      try {
        localStorage.removeItem(k);
      } catch (e) {}
    },
  };
  const Cap = (window.Capacitor && window.Capacitor.Plugins) || {};

  /* ---------------- developer cheat only on request ---------------- */
  try {
    if (/[?&]dev\b/.test(location.search) || localStorage.getItem("fw_dev") === "1")
      document.documentElement.classList.add("fw-dev");
  } catch (e) {}
  let cheatUsedThisMatch = false;
  $("cheatButton")?.addEventListener("click", () => {
    if (cheatMode) cheatUsedThisMatch = true;
  });

  /* ---------------- toast ---------------- */
  let toastTimer = null;
  window.fwToast = function (text, kind) {
    const t = $("fwToast");
    if (!t) return;
    t.textContent = text;
    t.classList.toggle("info", kind === "info");
    t.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove("show"), 4200);
  };

  /* ---------------- vibration ---------------- */
  window.fwVibrate = function (pattern) {
    try {
      if (localStorage.getItem("fortress_vibration") === "off") return;
    } catch (e) {}
    const ms = Array.isArray(pattern) ? pattern.reduce((a, b, i) => (i % 2 ? a : a + b), 0) : pattern;
    try {
      if (Cap.Haptics && Cap.Haptics.vibrate) {
        Cap.Haptics.vibrate({ duration: Math.max(10, Math.min(1000, ms)) });
        return;
      }
    } catch (e) {}
    try {
      navigator.vibrate && navigator.vibrate(pattern);
    } catch (e) {}
  };

  /* ---------------- statistics ---------------- */
  const STATS_KEY = "fw_stats_v1";
  function stats() {
    return Object.assign(
      {
        games: 0,
        wins: 0,
        losses: 0,
        shots: 0,
        hits: 0,
        playTime: 0,
        fastestWin: 0,
        fastestDiff: "",
        wins_easy: 0,
        wins_normal: 0,
        wins_hard: 0,
        losses_easy: 0,
        losses_normal: 0,
        losses_hard: 0,
        time_easy: 0,
        time_normal: 0,
        time_hard: 0,
      },
      store.get(STATS_KEY, {}),
    );
  }
  window.fwStatAdd = function (key, n) {
    if (cheatMode || cheatUsedThisMatch) return;
    const s = stats();
    s[key] = (s[key] || 0) + n;
    store.set(STATS_KEY, s);
  };
  const DIFF_LABEL = { easy: "Leicht", normal: "Normal", hard: "Schwer" };
  function fmtTime(sec) {
    sec = Math.max(0, Math.round(sec));
    const h = Math.floor(sec / 3600),
      m = Math.floor((sec % 3600) / 60),
      s = sec % 60;
    return h
      ? h + ":" + String(m).padStart(2, "0") + ":" + String(s).padStart(2, "0")
      : m + ":" + String(s).padStart(2, "0");
  }
  function renderRecord() {
    const btn = $("fwRecord");
    if (!btn) return;
    let v = $("fwRecordValue");
    if (!v) {
      v = document.createElement("span");
      v.id = "fwRecordValue";
      btn.appendChild(v);
    }
    const s = stats();
    v.textContent = s.fastestWin
      ? "Sieg in " + fmtTime(s.fastestWin)
      : s.wins
        ? s.wins + " Siege"
        : "Noch kein Sieg";
    btn.setAttribute("aria-label", "Bestleistung: " + v.textContent);
  }
  function renderStats() {
    const row = (k, v) => '<span class="k">' + k + '</span><span class="v">' + v + "</span>",
      head = (t) => '<span class="fwStatsHead">' + t + "</span>";
    const s = stats(),
      box = $("fwStatsDialog")?.querySelector("section");
    if (!box) return;
    const rate = s.games ? Math.round((s.wins / s.games) * 100) + " %" : "–";
    const acc = s.shots ? Math.round((s.hits / s.shots) * 100) + " %" : "–";
    box.innerHTML =
      '<h2>▥ Statistiken</h2><div class="fwStatsGrid">' +
      head("PARTIEN") +
      row("Gespielt", s.games) +
      row("Siege", s.wins) +
      row("Niederlagen", s.losses) +
      row("Siegquote", rate) +
      head("PRO SCHWIERIGKEIT (SIEGE : NIEDERLAGEN · Ø DAUER)") +
      ["easy", "normal", "hard"]
        .map((d) => {
          const n = (s["wins_" + d] || 0) + (s["losses_" + d] || 0);
          return row(
            DIFF_LABEL[d],
            (s["wins_" + d] || 0) + " : " + (s["losses_" + d] || 0) + (n ? " · " + fmtTime((s["time_" + d] || 0) / n) : ""),
          );
        })
        .join("") +
      head("REKORDE") +
      row(
        "Schnellster Sieg",
        s.fastestWin ? fmtTime(s.fastestWin) + " (" + (DIFF_LABEL[s.fastestDiff] || "") + ")" : "–",
      ) +
      row("Gesamte Spielzeit", fmtTime(s.playTime)) +
      head("KAMPF") +
      row("Abgefeuerte Schüsse", s.shots) +
      row("Treffer auf den Gegner", s.hits) +
      row("Trefferquote", acc) +
      '</div><button type="button" id="fwStatsReset">Statistik zurücksetzen</button><button type="button" id="fwStatsClose">Schließen</button>';
    $("fwStatsClose").onclick = () => {
      $("fwStatsDialog").hidden = true;
    };
    $("fwStatsReset").onclick = function () {
      if (this.dataset.armed) {
        store.del(STATS_KEY);
        renderStats();
        renderRecord();
        return;
      }
      this.dataset.armed = "1";
      this.textContent = "Wirklich alles zurücksetzen? Nochmal tippen";
    };
  }
  function openStats() {
    renderStats();
    $("fwStatsDialog").hidden = false;
  }
  for (const id of ["fwStats", "fwRecord"]) {
    const el = $(id);
    if (el) {
      el.addEventListener(
        "click",
        (e) => {
          e.stopImmediatePropagation();
          openStats();
        },
        true,
      );
    }
  }

  window.fwOnMatchEnd = function (win) {
    const s = stats();
    if (!(cheatMode || cheatUsedThisMatch)) {
      s.games++;
      win ? s.wins++ : s.losses++;
      s.playTime += fwMatchTime || 0;
      if (!win) s["losses_" + difficulty] = (s["losses_" + difficulty] || 0) + 1;
      s["time_" + difficulty] = (s["time_" + difficulty] || 0) + (fwMatchTime || 0);
      if (win) {
        s["wins_" + difficulty] = (s["wins_" + difficulty] || 0) + 1;
        if (!s.fastestWin || (fwMatchTime || 0) < s.fastestWin) {
          s.fastestWin = Math.round(fwMatchTime || 0);
          s.fastestDiff = difficulty;
        }
      }
      store.set(STATS_KEY, s);
      renderRecord();
    }
    fwVibrate(win ? [80, 60, 80, 60, 220] : [350]);
    clearSave();
    setTimeout(() => {
      const sub = $("resultSubtitle");
      if (!sub) return;
      let t = $("fwResultTime");
      if (!t) {
        t = document.createElement("div");
        t.id = "fwResultTime";
        t.style.cssText = "font-size:13px;color:#c9d8e4;margin:-4px 0 12px";
        sub.after(t);
      }
      t.textContent =
        "Spielzeit " +
        fmtTime(fwMatchTime || 0) +
        (cheatMode || cheatUsedThisMatch ? " · Test-Cheat, nicht gewertet" : "");
    }, 1500);
  };

  /* ---------------- profile ---------------- */
  (function () {
    const box = $("fwProfileDialog")?.querySelector("section");
    if (!box) return;
    const p = box.querySelector("p");
    const label = document.createElement("label");
    label.className = "fwProfileName";
    label.innerHTML =
      'Spielername<input id="fwProfileNameInput" maxlength="20" autocomplete="nickname" placeholder="Kommandant">';
    const summary = document.createElement("p");
    summary.id = "fwProfileSummary";
    p.after(label, summary);
    const input = label.querySelector("input");
    input.value = (() => {
      try {
        return localStorage.getItem("fw_online_name") || "";
      } catch (e) {
        return "";
      }
    })();
    input.addEventListener("input", () => {
      try {
        localStorage.setItem("fw_online_name", input.value.trim());
      } catch (e) {}
      const on = $("onlineName");
      if (on) on.value = input.value.trim();
    });
    $("fwProfile")?.addEventListener("click", () => {
      const s = stats();
      summary.textContent = s.games
        ? s.wins +
          " Siege aus " +
          s.games +
          " Partien · Bestzeit " +
          (s.fastestWin ? fmtTime(s.fastestWin) : "–")
        : "Noch keine Partie beendet.";
      const c = $("fwProfileContinue");
      if (c) c.hidden = !fwCanContinue();
    });
  })();

  /* ---------------- guide / tutorial ---------------- */
  const GUIDE = [
    [
      "🎯",
      "Dein Ziel",
      "Zerstöre den <b>Reaktor</b> des Gegners, bevor er deinen zerstört. Beide Seiten starten mit derselben Festung, denselben Kosten und ohne Waffen.",
    ],
    [
      "⛏",
      "Wirtschaft aufbauen",
      "Öffne <b>Wirtschaft</b> und ziehe eine <b>Mine</b> auf einen Balken direkt am Boden (+4 Eisen/s). Ein <b>Windrad</b> liefert Energie (+3/s) für Schüsse und Forschung. Ohne Mine fließt langsam eine Notversorgung bis 80 Eisen.",
    ],
    [
      "🏭",
      "Waffenwerkstatt",
      "Waffen kannst du erst bauen, wenn deine <b>Werkstatt</b> (95 Eisen) fertig ist. Wird sie zerstört, stoppt auch der Bau neuer Waffen.",
    ],
    [
      "🔫",
      "Waffen platzieren",
      "Ziehe eine Waffe aus <b>Waffen</b> auf einen waagerechten eigenen Balken. <b>Grün</b> = freie Schusslinie, <b>Gelb</b> = eine eigene Wand ist im Weg – dort brauchst du davor eine Panzertür.",
    ],
    [
      "🚪",
      "Wichtig: Panzertüren",
      "Vordere Balken blockieren auch <b>deine eigenen Schüsse</b>! Tippe im Bau-Modus die Wand vor deiner Waffe an und wähle <b>Panzertür</b> – was der Umbau kostet, steht direkt im Menü. Die Tür öffnet sich beim Schuss automatisch. Triffst du dich selbst, blinkt der störende Balken rot.",
    ],
    [
      "💥",
      "Feuern",
      "Tippe <b>Feuer</b>, wähle bis zu 3 Waffen, ziehe das Ziel und drücke <b>FEUER</b>. Wo die Granate einschlägt, musst du selbst herausfinden: beobachte die Einschläge und korrigiere deinen Winkel.",
    ],
    [
      "🔧",
      "Halten & ausbauen",
      "<b>Reparatur</b>: beschädigte eigene Balken antippen (8 Eisen); ein Reparaturturm heilt alles im Umkreis – nur der <b>Reaktor</b> lässt sich nie reparieren, also schütze ihn gut! <b>Forschung</b> schaltet stärkere Waffen frei. <b>Zwei Finger</b> verschieben und zoomen die Kamera. Viel Erfolg, Kommandant!",
    ],
  ];
  let guideIndex = 0,
    guidePausedGame = false;
  function renderGuide() {
    const [icon, title, text] = GUIDE[guideIndex];
    $("fwGuideIcon").textContent = icon;
    $("fwGuideTitle").textContent = title;
    $("fwGuideText").innerHTML = text;
    $("fwGuideStep").textContent = "SCHRITT " + (guideIndex + 1) + " VON " + GUIDE.length;
    $("fwGuideDots").innerHTML = GUIDE.map(
      (_, i) => '<i class="' + (i === guideIndex ? "on" : "") + '"></i>',
    ).join("");
    $("fwGuidePrev").disabled = guideIndex === 0;
    $("fwGuideNext").textContent = guideIndex === GUIDE.length - 1 ? "Los geht’s!" : "Weiter ›";
  }
  window.fwOpenGuide = function (fromMatch) {
    guideIndex = 0;
    guidePausedGame = false;
    if (fromMatch && !paused) {
      paused = true;
      fwSetPauseOrb(true);
      guidePausedGame = true;
    }
    renderGuide();
    $("fwGuide").hidden = false;
  };
  function closeGuide() {
    $("fwGuide").hidden = true;
    store.set("fw_tutorial_v1", 1);
    if (guidePausedGame && !gameOver) {
      paused = false;
      fwSetPauseOrb(false);
      hud();
    }
    guidePausedGame = false;
  }
  $("fwGuidePrev").onclick = () => {
    if (guideIndex > 0) {
      guideIndex--;
      renderGuide();
    }
  };
  $("fwGuideNext").onclick = () => {
    if (guideIndex < GUIDE.length - 1) {
      guideIndex++;
      renderGuide();
    } else closeGuide();
  };
  $("fwGuideSkip").onclick = closeGuide;
  // Tools menu: open guide
  (function () {
    const menu = $("menu");
    if (!menu) return;
    const b = document.createElement("button");
    b.type = "button";
    b.textContent = "❓ Anleitung";
    b.style.cssText = "width:100%;margin-bottom:8px";
    b.onclick = () => {
      menu.hidden = true;
      fwOpenGuide(true);
    };
    const home = $("openMainFromTools");
    home ? home.after(b) : menu.prepend(b);
  })();

  /* ---------------- own hit warning ---------------- */
  let lastOwnHit = 0;
  window.fwOwnHit = function (beam) {
    const now = performance.now();
    if (beam && beam.id != null) window.__fwOwnHitBeam = { id: beam.id, until: now + 3500 };
    if (now - lastOwnHit < 6000) return;
    lastOwnHit = now;
    const msg =
      "⚠ Eigener Treffer! Der rot blinkende Balken blockiert deine Waffe. Tippe ihn im Bau-Modus an und mache ihn zur Panzertür.";
    const tip = $("tip");
    if (tip) tip.textContent = msg;
    fwToast(msg);
    fwVibrate(40);
  };

  /* ---------------- match start hooks ---------------- */
  $("difficultyStart")?.addEventListener("click", () => {
    cheatUsedThisMatch = !!cheatMode;
    setTimeout(() => {
      saveMatch();
      if (!store.get("fw_tutorial_v1", 0)) fwOpenGuide(true);
    }, 50);
  });

  /* ---------------- save / continue ---------------- */
  const SAVE_KEY = "fw_match_save_v1";
  const SAVE_VARS = [
    "nodes",
    "beams",
    "guns",
    "resources",
    "aiResources",
    "metal",
    "energy",
    "aiMetal",
    "aiEnergy",
    "playerCore",
    "enemyCore",
    "researchJob",
    "aiResearchJob",
    "difficulty",
    "nextBeamId",
    "enemyOn",
    "enemyStarted",
    "enemyReady",
    "enemyTimer",
    "enemyBuildTimer",
    "enemyPlan",
    "aiStage",
    "aiLevel",
    "aiRebuild",
    "aiShots",
    "aiLastAction",
    "aiBuildStyle",
    "aiBuildMirror",
    "aiBlueprint",
    "aiStallTicks",
    "aiLastGunCount",
    "aiShellAttempts",
    "aiStrategy",
    "aiThink",
    "aiFireDecisionTimer",
    "battlefield",
    "doorMode",
    "doorsForcedOpen",
    "hits",
    "fwMatchTime",
    "camX",
    "camY",
    "zoom",
  ];
  function readVar(n) {
    try {
      return (0, eval)(n);
    } catch (e) {
      return undefined;
    }
  }
  function writeVar(n, v) {
    try {
      window.__fwTmp = v;
      (0, eval)(n + "=window.__fwTmp");
      delete window.__fwTmp;
    } catch (e) {}
  }
  function clearSave() {
    store.del(SAVE_KEY);
  }
  function saveMatch() {
    try {
      if (!menuHasGame || gameOver || window.FWOnlineMatch) {
        if (gameOver) clearSave();
        return;
      }
      if (cheatMode) return;
      const data = {
        v: 1,
        savedAt: Date.now(),
        unlocked: [...unlockedWeapons],
        aiUnlocked: [...aiUnlockedWeapons],
        battlefieldName: battlefield && battlefield.name,
        missionId: window.fwMission ? window.fwMission.id : null,
        suddenDeath: !!window.fwSuddenDeath,
      };
      for (const n of SAVE_VARS) data[n] = readVar(n);
      delete data.battlefield;
      localStorage.setItem(SAVE_KEY, JSON.stringify(data));
    } catch (e) {}
  }
  window.fwSaveMatch = saveMatch;
  window.fwHasSave = function () {
    try {
      return !!localStorage.getItem(SAVE_KEY);
    } catch (e) {
      return false;
    }
  };
  function loadMatch() {
    let d = null;
    try {
      d = JSON.parse(localStorage.getItem(SAVE_KEY) || "null");
    } catch (e) {}
    if (!d || d.v !== 1) return false;
    try {
      reset();
      for (const n of SAVE_VARS) {
        if (n === "battlefield" || !(n in d)) continue;
        writeVar(n, d[n]);
      }
      const bf =
        typeof BATTLEFIELDS !== "undefined" && BATTLEFIELDS.find((b) => b.name === d.battlefieldName);
      if (bf) battlefield = bf;
      unlockedWeapons = new Set(d.unlocked || ["mg", "cannon"]);
      aiUnlockedWeapons = new Set(d.aiUnlocked || ["mg", "cannon"]);
      // Time stamps from the old session are meaningless now.
      for (const o of [...beams, ...guns, ...resources, ...aiResources, playerCore, enemyCore])
        if (o && o.repairBlockedUntil) o.repairBlockedUntil = 0;
      if (aiStrategy) aiStrategy.lastReview = 0;
      shots = [];
      particles = [];
      fwFlakRounds = [];
      fwFlakBursts = [];
      openingCamera = null;
      setDifficulty(difficulty);
      $("hits").textContent = hits;
      fwUpdateBeamCount();
      refreshResearchUI();
      updateStructuralSupport();
      hud();
      window.fwMission = (d.missionId && (window.FW_MISSIONS || []).find((m) => m.id === d.missionId)) || null;
      window.fwSuddenDeath = !!d.suddenDeath;
      menuHasGame = true;
      cheatUsedThisMatch = false;
      return true;
    } catch (e) {
      console.warn("Spielstand konnte nicht geladen werden", e);
      clearSave();
      return false;
    }
  }
  window.fwCanContinue = function () {
    return (menuHasGame && !gameOver) || fwHasSave();
  };
  setInterval(() => {
    if (!paused || $("mainOverlay")?.hidden === false) saveMatch();
  }, 5000);
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      saveMatch();
      if (menuHasGame && !gameOver && !paused && $("mainOverlay")?.hidden !== false) {
        paused = true;
        fwSetPauseOrb(true);
        const t = $("tip");
        if (t) t.textContent = "Pausiert. Tippe auf „Weiter“, um fortzufahren.";
      }
    }
  });
  window.addEventListener("pagehide", saveMatch);

  // SPIELEN: offer continue when a match is running or saved
  function startNewFlow() {
    $("mainOverlay").hidden = true;
    $("difficultyOverlay").hidden = false;
    paused = true;
  }
  function continueFlow() {
    $("fwPlayChoice").hidden = true;
    if (!menuHasGame || gameOver) {
      if (!loadMatch()) {
        startNewFlow();
        return;
      }
      $("mainOverlay").hidden = true;
      $("difficultyOverlay").hidden = true;
      paused = true;
      fwSetPauseOrb(true);
      const t = $("tip");
      if (t) t.textContent = "Spielstand geladen. Tippe auf „Weiter“, um fortzufahren.";
      return;
    }
    continueGame();
  }
  window.fwStartNewFlow = startNewFlow;
  $("mainNew").onclick = () => {
    $("fwPlayContinue").hidden = !fwCanContinue();
    $("fwPlayChoiceText").textContent = "Wähle einen Spielmodus.";
    $("fwPlayChoice").hidden = false;
    if (fwCanContinue()) {
      const s = store.get(SAVE_KEY, null);
      $("fwPlayChoiceText").textContent =
        menuHasGame && !gameOver
          ? "Du hast eine laufende Partie."
          : "Gespeicherte Partie" +
            (s && s.savedAt
              ? " vom " +
                new Date(s.savedAt).toLocaleString("de-DE", {
                  day: "2-digit",
                  month: "2-digit",
                  hour: "2-digit",
                  minute: "2-digit",
                })
              : "") +
            " · " +
            (s && s.missionId ? "Mission " + s.missionId : "KI: " + (DIFF_LABEL[s && s.difficulty] || "Normal"));
    }
  };
  $("fwPlayContinue").onclick = continueFlow;
  $("fwPlayNew").onclick = () => {
    $("fwPlayChoice").hidden = true;
    startNewFlow();
  };
  $("mainContinue").onclick = continueFlow;

  /* ---------------- sound & music buttons in the main menu ---------------- */
  function persistAudio() {
    const v = store.get("fortress_settings_v116", {}) || {};
    v.sound = soundEnabled;
    v.music = musicEnabled;
    if (v.difficulty == null) v.difficulty = difficulty;
    store.set("fortress_settings_v116", v);
  }
  window.fwSyncAudioButtons = function () {
    const s = $("fwSound"),
      m = $("fwMusic");
    if (s) {
      s.style.opacity = soundEnabled ? "1" : ".45";
      s.setAttribute("aria-pressed", String(soundEnabled));
      s.setAttribute("aria-label", soundEnabled ? "Ton ausschalten" : "Ton einschalten");
    }
    if (m) {
      m.style.opacity = musicEnabled ? "1" : ".45";
      m.setAttribute("aria-pressed", String(musicEnabled));
      m.setAttribute("aria-label", musicEnabled ? "Musik ausschalten" : "Musik einschalten");
    }
    const cs = $("settingSound"),
      cm = $("settingMusic");
    if (cs) cs.checked = soundEnabled;
    if (cm) cm.checked = musicEnabled;
  };
  window.fwToggleSound = function () {
    soundEnabled = !soundEnabled;
    persistAudio();
    fwSyncAudioButtons();
    if (soundEnabled) playBuildSound();
  };
  window.fwToggleMusic = function () {
    musicEnabled = !musicEnabled;
    persistAudio();
    fwSyncAudioButtons();
    if (musicEnabled) audioReady();
  };
  for (const id of ["settingsClose", "fwSettingsX"])
    $(id)?.addEventListener("click", () => setTimeout(fwSyncAudioButtons, 0));
  fwSyncAudioButtons();
  window.fwMusicGain = function () {
    const s = $("fwMusicVolume");
    const v = s ? Number(s.value) : 70;
    return Math.max(0, Math.min(100, isFinite(v) ? v : 70)) / 70;
  };

  /* ---------------- fire button: disabled while reloading ---------------- */
  setInterval(() => {
    const b = $("aimFire");
    if (!b || b.hidden || mode !== "shoot") return;
    const label = b.querySelector(".aimFireLabel");
    const sel = selectedGuns();
    const busy = (g) => (g.buildRemaining || 0) > 0 || (g.cooldown || 0) > 0;
    const ready = sel.filter((g) => !busy(g));
    let text = "FEUER",
      disabled = false;
    if (!sel.length || !aimTarget || gameOver) disabled = true;
    else if (!ready.length) {
      disabled = true;
      const built = sel.filter((g) => !((g.buildRemaining || 0) > 0));
      text = built.length
        ? "LÄDT " + Math.ceil(Math.min(...built.map((g) => g.cooldown || 0))) + " s"
        : "IM BAU";
    } else if (!ready.some((g) => energy >= (WEAPONS[g.type || "cannon"]?.energy || 0))) {
      disabled = true;
      text = "ENERGIE";
    }
    if (b.disabled !== disabled) b.disabled = disabled;
    b.classList.toggle("fwReloading", text !== "FEUER");
    if (label && label.textContent !== text) label.textContent = text;
  }, 150);

  /* ---------------- Android: back button & portrait lock ---------------- */
  function closeTopLayer() {
    const dialogs = [...document.querySelectorAll(".fw1441Dialog")].filter((d) => !d.hidden);
    if (dialogs.length) {
      const d = dialogs[dialogs.length - 1];
      if (d.id === "fwGuide") closeGuide();
      else d.hidden = true;
      return true;
    }
    if ($("beamMenu") && !$("beamMenu").hidden) {
      hideBeamMenu();
      return true;
    }
    if ($("settingsPanel") && !$("settingsPanel").hidden) {
      saveGameSettings();
      fwSyncAudioButtons();
      return true;
    }
    if ($("onlineOverlay") && !$("onlineOverlay").hidden) {
      $("onlineClose")?.click();
      return true;
    }
    if ($("difficultyOverlay") && !$("difficultyOverlay").hidden) {
      $("difficultyClose")?.click();
      return true;
    }
    if ($("menu") && !$("menu").hidden) {
      $("menu").hidden = true;
      return true;
    }
    if ($("mainOverlay") && $("mainOverlay").hidden) {
      openMainMenu();
      saveMatch();
      return true;
    }
    return false;
  }
  try {
    if (Cap.App && Cap.App.addListener) {
      Cap.App.addListener("backButton", () => {
        if (closeTopLayer()) return;
        saveMatch();
        if (Cap.App.minimizeApp) Cap.App.minimizeApp();
        else Cap.App.exitApp();
      });
      Cap.App.addListener("pause", () => {
        saveMatch();
      });
    }
  } catch (e) {}
  try {
    if (Cap.ScreenOrientation && Cap.ScreenOrientation.lock)
      Cap.ScreenOrientation.lock({ orientation: "portrait" }).catch(() => {});
    else if (screen.orientation && screen.orientation.lock)
      screen.orientation.lock("portrait").catch(() => {});
  } catch (e) {}
  // Landscape on a phone: pause while the rotate hint covers the game.
  (function () {
    const mq = matchMedia("(orientation:landscape) and (max-height:560px)");
    let pausedByRotate = false;
    const on = () => {
      if (mq.matches) {
        if (menuHasGame && !gameOver && !paused) {
          paused = true;
          fwSetPauseOrb(true);
          pausedByRotate = true;
        }
      } else if (pausedByRotate) {
        pausedByRotate = false;
        const dlg = [...document.querySelectorAll(".fw1441Dialog")].some((d) => !d.hidden);
        if (!gameOver && !dlg && $("mainOverlay")?.hidden !== false) {
          paused = false;
          fwSetPauseOrb(false);
        }
      }
    };
    mq.addEventListener ? mq.addEventListener("change", on) : mq.addListener(on);
  })();

  renderRecord();
})();
