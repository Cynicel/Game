window.__fwMortarCalibration = { x: 2.5, y: 1 };
try {
  const v = JSON.parse(localStorage.getItem("fw_mortar_calibration_v1551") || "null");
  if (v && Number.isFinite(v.x) && Number.isFinite(v.y)) {
    window.__fwMortarCalibration.x = Math.max(-60, Math.min(60, v.x));
    window.__fwMortarCalibration.y = Math.max(-60, Math.min(60, v.y));
  }
} catch (e) {}
