// V15.61: keep the display on while playing in a browser (the Android app does
// this natively in MainActivity). Silently does nothing where unsupported.
(function () {
  "use strict";
  let lock = null;
  async function request() {
    if (!("wakeLock" in navigator) || document.visibilityState !== "visible" || lock) return;
    try {
      lock = await navigator.wakeLock.request("screen");
      lock.addEventListener("release", () => (lock = null));
    } catch (e) {
      lock = null;
    }
  }
  document.addEventListener("pointerdown", request, { passive: true });
  document.addEventListener("visibilitychange", request);
})();
