// V14.72: Reliable horizontal touch swipe in the construction palette.
// Suppresses an accidental beam-card selection after swiping.
(() => {
  const dock = document.getElementById("buildDock");
  if (!dock) return;
  let swipe = null,
    stopClick = false;
  dock.addEventListener(
    "touchstart",
    (e) => {
      if (e.touches.length !== 1) {
        swipe = null;
        return;
      }
      stopClick = false;
      const t = e.touches[0];
      swipe = { x: t.clientX, y: t.clientY, startScroll: dock.scrollLeft, scrolling: false };
    },
    { passive: true },
  );
  dock.addEventListener(
    "touchmove",
    (e) => {
      if (!swipe || e.touches.length !== 1) return;
      const t = e.touches[0],
        dx = t.clientX - swipe.x,
        dy = t.clientY - swipe.y;
      if (!swipe.scrolling && Math.abs(dx) > 8 && Math.abs(dx) > Math.abs(dy) * 1.2) swipe.scrolling = true;
      if (swipe.scrolling) {
        e.preventDefault();
        dock.scrollLeft = swipe.startScroll - dx;
        stopClick = true;
      }
    },
    { passive: false },
  );
  dock.addEventListener(
    "touchend",
    () => {
      if (swipe?.scrolling) stopClick = true;
      swipe = null;
    },
    { passive: true },
  );
  dock.addEventListener(
    "touchcancel",
    () => {
      swipe = null;
    },
    { passive: true },
  );
  dock.addEventListener(
    "click",
    (e) => {
      if (stopClick) {
        e.preventDefault();
        e.stopImmediatePropagation();
        stopClick = false;
      }
    },
    true,
  );
})();
