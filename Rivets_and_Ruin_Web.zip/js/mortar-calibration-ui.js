(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const overlay = $("fwMortarCalOverlay");
  const stage = $("fwMortarCalStage");
  const canvas = $("fwMortarCalCanvas");
  const readout = $("fwCalReadout");
  const footer = $("fwCalFoot");
  const defaults = { x: 2.5, y: 1 };
  let committed = { ...window.__fwMortarCalibration };
  let angle = FW_MORTAR_CONFIG.restAngle;
  let active = false;
  let pointer = null;
  let view = { scale: 1, angleDelta: 0 };
  let frameToken = 0;
  const limit = (v) => Math.max(-60, Math.min(60, Math.round(v * 10) / 10));
  function setXY(x, y) {
    window.__fwMortarCalibration.x = limit(x);
    window.__fwMortarCalibration.y = limit(y);
    readout.innerHTML =
      "<strong>X " +
      window.__fwMortarCalibration.x.toFixed(1) +
      " · Y " +
      window.__fwMortarCalibration.y.toFixed(1) +
      "</strong> · Y negativ = höher";
  }
  function resizeCanvas() {
    const r = canvas.getBoundingClientRect();
    const dpr = Math.min(devicePixelRatio || 1, 2);
    const width = Math.max(1, Math.round(r.width * dpr));
    const height = Math.max(1, Math.round(r.height * dpr));
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }
    return { w: r.width, h: r.height, dpr };
  }
  function render() {
    if (!active) return;
    const { w, h, dpr } = resizeCanvas();
    const cx = canvas.getContext("2d");
    cx.setTransform(dpr, 0, 0, dpr, 0, 0);
    cx.clearRect(0, 0, w, h);
    const gr = cx.createLinearGradient(0, 0, 0, h);
    gr.addColorStop(0, "#192d3a");
    gr.addColorStop(0.65, "#31535d");
    gr.addColorStop(1, "#192c32");
    cx.fillStyle = gr;
    cx.fillRect(0, 0, w, h);
    // Visual guides behind the exact gameplay sprite.
    cx.save();
    cx.globalAlpha = 0.15;
    cx.strokeStyle = "#c7e5e7";
    cx.lineWidth = 1;
    for (let x = 0; x < w; x += 35) {
      cx.beginPath();
      cx.moveTo(x, 0);
      cx.lineTo(x, h);
      cx.stroke();
    }
    for (let y = 0; y < h; y += 35) {
      cx.beginPath();
      cx.moveTo(0, y);
      cx.lineTo(w, y);
      cx.stroke();
    }
    cx.restore();
    const zoom = Math.min(w / 116, h / 100);
    const ox = w * 0.5,
      oy = h * 0.75;
    view.scale = zoom;
    view.angleDelta = fwMortarVisualRotation(angle);
    cx.save();
    cx.translate(ox, oy);
    cx.scale(zoom, zoom);
    // A real supporting beam, for visual context.
    cx.fillStyle = "#674327";
    cx.fillRect(-50, 1, 100, 8);
    cx.strokeStyle = "#bf8751";
    cx.lineWidth = 1.3;
    cx.strokeRect(-50, 1, 100, 8);
    for (const x of [-40, 0, 40]) {
      cx.fillStyle = "#24313c";
      cx.fillRect(x - 3.5, -0.5, 7, 11);
      cx.fillStyle = "#bf874e";
      cx.beginPath();
      cx.arc(x, 5, 1.3, 0, Math.PI * 2);
      cx.fill();
    }
    try {
      if (typeof drawLayeredWeapon === "function") drawLayeredWeapon(cx, "mortar", angle, false, 0);
      else {
        cx.fillStyle = "#fff";
        cx.font = "5px system-ui";
        cx.fillText("Mörser wird geladen ...", -30, -40);
      }
    } catch (e) {
      cx.fillStyle = "#f4bf6e";
      cx.font = "5px system-ui";
      cx.fillText("Vorschau wird geladen ...", -35, -45);
    }
    cx.restore();
    frameToken = requestAnimationFrame(render);
  }
  function openEditor() {
    committed = { ...window.__fwMortarCalibration };
    angle = FW_MORTAR_CONFIG.restAngle;
    document
      .querySelectorAll("[data-fwcal-angle]")
      .forEach((b) =>
        b.classList.toggle("fwCalSelected", Math.abs(Number(b.dataset.fwcalAngle) - angle) < 0.001),
      );
    setXY(committed.x, committed.y);
    footer.textContent = "Direkt am Lauf ziehen. Speichern mit „Übernehmen“ – Schließen verwirft Änderungen.";
    overlay.hidden = false;
    overlay.setAttribute("aria-hidden", "false");
    $("menu").hidden = true;
    active = true;
    cancelAnimationFrame(frameToken);
    render();
  }
  function closeEditor(revert = true) {
    if (revert) setXY(committed.x, committed.y);
    pointer = null;
    active = false;
    cancelAnimationFrame(frameToken);
    overlay.hidden = true;
    overlay.setAttribute("aria-hidden", "true");
  }
  $("fwMortarCalOpen").addEventListener("click", openEditor);
  $("fwCalClose").addEventListener("click", () => closeEditor(true));
  overlay.addEventListener("click", (e) => {
    if (e.target === overlay) closeEditor(true);
  });
  $("fwCalApply").addEventListener("click", () => {
    committed = { ...window.__fwMortarCalibration };
    let stored = false;
    try {
      localStorage.setItem("fw_mortar_calibration_v1551", JSON.stringify(committed));
      stored = true;
    } catch (e) {
      /* content:// browsers may block persistent storage */
    }
    try {
      const tip = $("tip");
      if (tip)
        tip.textContent =
          "Mörser X " +
          committed.x +
          ", Y " +
          committed.y +
          " übernommen." +
          (stored ? "" : " Für dauerhaftes Speichern Werte kopieren.");
    } catch (e) {}
    closeEditor(false);
  });
  $("fwCalReset").addEventListener("click", () => setXY(defaults.x, defaults.y));
  for (const [id, dx, dy] of [
    ["fwCalLeft", -1, 0],
    ["fwCalRight", 1, 0],
    ["fwCalUp", 0, -1],
    ["fwCalDown", 0, 1],
  ]) {
    $(id).addEventListener("click", () =>
      setXY(window.__fwMortarCalibration.x + dx, window.__fwMortarCalibration.y + dy),
    );
  }
  document.querySelectorAll("[data-fwcal-angle]").forEach((b) =>
    b.addEventListener("click", () => {
      angle = Number(b.dataset.fwcalAngle);
      document
        .querySelectorAll("[data-fwcal-angle]")
        .forEach((x) => x.classList.toggle("fwCalSelected", x === b));
    }),
  );
  $("fwCalCopy").addEventListener("click", async () => {
    const txt =
      "Rivets & Ruin Mörser: X=" +
      window.__fwMortarCalibration.x +
      ", Y=" +
      window.__fwMortarCalibration.y;
    try {
      if (!navigator.clipboard?.writeText) throw Error("no clipboard");
      await navigator.clipboard.writeText(txt);
      footer.textContent = "Werte kopiert: " + txt;
    } catch (e) {
      footer.textContent = "Werte zum Abschreiben: " + txt;
    }
  });
  // Drag directly on the weapon preview. Convert screen-space movement to the
  // rotated local barrel coordinate system so the finger moves the tube as expected.
  stage.addEventListener("pointerdown", (e) => {
    if (!active || pointer) return;
    e.preventDefault();
    pointer = {
      id: e.pointerId,
      startX: e.clientX,
      startY: e.clientY,
      x: window.__fwMortarCalibration.x,
      y: window.__fwMortarCalibration.y,
    };
    try {
      stage.setPointerCapture(e.pointerId);
    } catch (err) {}
  });
  stage.addEventListener("pointermove", (e) => {
    if (!active || !pointer || pointer.id !== e.pointerId) return;
    e.preventDefault();
    const dx = (e.clientX - pointer.startX) / view.scale;
    const dy = (e.clientY - pointer.startY) / view.scale;
    // X/Y now offset the stationary joint in world space, not the rotated image.
    setXY(pointer.x + dx, pointer.y + dy);
  });
  for (const name of ["pointerup", "pointercancel", "lostpointercapture"]) {
    stage.addEventListener(name, (e) => {
      if (pointer?.id === e.pointerId) pointer = null;
    });
  }
  document.addEventListener("keydown", (e) => {
    if (!active) return;
    if (e.key === "Escape") {
      closeEditor(true);
      return;
    }
    const shifts = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] };
    if (shifts[e.key]) {
      e.preventDefault();
      setXY(
        window.__fwMortarCalibration.x + shifts[e.key][0],
        window.__fwMortarCalibration.y + shifts[e.key][1],
      );
    }
  });
})();
