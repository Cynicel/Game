// Online lobby + connection handling (V15.61).
// Game logic of an online match lives in online-match.js (window.FWGameNet).
(function () {
  "use strict";
  const PROTOCOL = 2; // must match between host and guest (checked by the server)
  const $ = (id) => document.getElementById(id);
  let socket = null,
    room = null,
    ready = false,
    freddySocket = null,
    role = null,
    match = false,
    sendTimer = null,
    session = null, // { code, token, role } – for reconnecting
    reconnect = null, // { tries, timer }
    wakeTimer = null,
    leaving = false;
  const setStatus = (t) => {
    $("onlineStatus").textContent = t;
  };
  const saved = localStorage.getItem("fw_online_url") || "wss://fortress-warfare-server.onrender.com";
  $("onlineServer").value = saved;
  $("onlineName").value = localStorage.getItem("fw_online_name") || "Spieler";
  // The test bot is a developer tool only (open the game with ?dev=1).
  const dev = new URLSearchParams(location.search).has("dev");
  $("onlineFreddy").hidden = !dev;

  function stopTimers() {
    if (sendTimer) clearInterval(sendTimer);
    sendTimer = null;
    if (reconnect?.timer) clearTimeout(reconnect.timer);
    reconnect = null;
    if (wakeTimer) clearTimeout(wakeTimer);
    wakeTimer = null;
  }
  function endMatch() {
    if (match) window.FWGameNet?.stop();
    match = false;
  }
  function closeSocket() {
    stopTimers();
    endMatch();
    session = null;
    if (freddySocket) {
      freddySocket.onclose = null;
      freddySocket.close();
      freddySocket = null;
    }
    $("onlineFreddyStatus").textContent = "";
    if (socket) {
      socket.onclose = null;
      try {
        if (socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify({ type: "leave" }));
      } catch (e) {}
      socket.close();
      socket = null;
    }
    room = null;
    ready = false;
    $("onlineRoom").hidden = true;
  }
  function send(obj) {
    if (socket && socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify(obj));
  }
  const serverUrl = () => $("onlineServer").value.trim();

  function startMatch() {
    if (!window.FWGameNet) {
      setStatus("Spiel-Engine noch nicht bereit.");
      return;
    }
    match = true;
    window.FWGameNet.start(role, (data) => send({ type: "build", data }));
    $("onlineOverlay").hidden = true;
    if (role === "host") startSnapshots();
  }
  function startSnapshots() {
    if (sendTimer) clearInterval(sendTimer);
    sendTimer = setInterval(() => {
      if (match && socket?.readyState === WebSocket.OPEN) send({ type: "snapshot", data: window.FWGameNet.snapshot() });
    }, window.FWGameNet.SNAP_MS || 250);
  }

  function onMessage(e) {
    let m;
    try {
      m = JSON.parse(e.data);
    } catch {
      return;
    }
    if (m.type === "snapshot") {
      if (match && role === "guest") window.FWGameNet.apply(m.data);
      return;
    }
    if (m.type === "build") {
      if (match && role === "host") window.FWGameNet.command(m.data);
      return;
    }
    if (m.type === "error") {
      if (m.code === "rejoin_failed") {
        lostForGood("Die Partie ist nicht mehr verfügbar.");
        return;
      }
      setStatus("Fehler: " + m.message + (m.code === "version_mismatch" ? " – bitte beide die neueste Version installieren." : ""));
      return;
    }
    if (m.type === "session") {
      session = { code: m.code, token: m.token, role: m.role };
      return;
    }
    if (m.type === "room") {
      room = m.code;
      role = m.role || role;
      $("onlineMatchStart").hidden = !(m.players?.length === 2 && m.players.every((p) => p.ready));
      $("onlineRoom").hidden = false;
      $("onlineRoomCode").textContent = m.code;
      $("onlineCode").value = m.code;
      ready = !!m.youReady;
      $("onlineReady").textContent = ready ? "✓ Bereit – zurücknehmen" : "✓ Bereit";
      $("onlinePlayers").textContent = (m.players || [])
        .map((p) => p.name + (p.ready ? " ✓" : " …"))
        .join("  VS  ");
      if (!match)
        setStatus(
          m.players.length < 2
            ? "Lobby erstellt. Schicke deinem Freund den Code und warte auf ihn …"
            : m.players.every((p) => p.ready)
              ? "Beide bereit – „Duell starten“ drücken."
              : "Beide Spieler verbunden. Bereit drücken!",
        );
      return;
    }
    if (m.type === "start") {
      setStatus("Beide bereit – „Duell starten“ drücken.");
      $("onlineMatchStart").hidden = false;
      return;
    }
    if (m.type === "match_start") {
      startMatch();
      return;
    }
    if (m.type === "rejoined") {
      if (reconnect?.timer) clearTimeout(reconnect.timer);
      reconnect = null;
      if (match) window.FWGameNet.peerWaiting(false);
      if (match && role === "host") startSnapshots();
      return;
    }
    if (m.type === "peer_disconnected") {
      if (match) window.FWGameNet.peerWaiting(true);
      return;
    }
    if (m.type === "peer_rejoined") {
      if (match) window.FWGameNet.peerWaiting(false);
      return;
    }
    if (m.type === "peer_left") {
      if (match) {
        window.FWGameNet.peerLeft();
        if (sendTimer) clearInterval(sendTimer);
        sendTimer = null;
      } else setStatus("Dein Mitspieler hat die Lobby verlassen.");
      return;
    }
  }

  function openSocket(onopen) {
    let ws;
    try {
      ws = new WebSocket(serverUrl());
    } catch (e) {
      setStatus("Verbindung fehlgeschlagen: " + e.message);
      return null;
    }
    socket = ws;
    // A free server sleeps when nobody plays; waking it up takes up to a minute.
    wakeTimer = setTimeout(() => {
      if (ws.readyState === WebSocket.CONNECTING)
        setStatus("Server wird gerade gestartet – das kann bis zu einer Minute dauern …");
    }, 4000);
    ws.onopen = () => {
      if (wakeTimer) clearTimeout(wakeTimer);
      onopen();
    };
    ws.onmessage = onMessage;
    ws.onerror = () => {
      if (!match && !reconnect) setStatus("Server nicht erreichbar. Prüfe Adresse und Internetverbindung.");
    };
    ws.onclose = () => {
      if (socket !== ws) return;
      socket = null;
      if (leaving) return;
      if (session && (match || room)) tryReconnect();
      else if (room) setStatus("Verbindung getrennt. Bitte erneut verbinden.");
    };
    return ws;
  }

  // After a short network loss (tunnel, Wi-Fi switch, app in background) the
  // server keeps our seat for 30 seconds – reconnect with the session token.
  function tryReconnect() {
    if (!session) return;
    if (!reconnect) reconnect = { tries: 0, timer: null };
    if (reconnect.tries >= 12) {
      lostForGood("Verbindung verloren.");
      return;
    }
    reconnect.tries++;
    if (match) window.FWGameNet.peerWaiting(true); // freeze the match while we are gone
    if (match) window.FWGameNet.showBanner("Verbindung unterbrochen – verbinde neu (" + reconnect.tries + ") …");
    else setStatus("Verbindung unterbrochen – verbinde neu …");
    reconnect.timer = setTimeout(() => {
      openSocket(() => send({ type: "rejoin", code: session.code, token: session.token }));
    }, reconnect.tries === 1 ? 300 : 2500);
  }
  function lostForGood(text) {
    const wasMatch = match;
    stopTimers();
    if (wasMatch) {
      window.FWGameNet.peerLeft();
      $("resultSubtitle").textContent = text + " Die Partie wurde beendet.";
    }
    endMatch();
    session = null;
    room = null;
    $("onlineRoom").hidden = true;
    setStatus(text + " Bitte neu verbinden.");
  }

  function connect(action) {
    closeSocket();
    const url = serverUrl();
    if (!/^wss:\/\/[^ ]+$/i.test(url)) {
      setStatus("Bitte eine gültige öffentliche wss://-Serveradresse eingeben.");
      return;
    }
    const name = ($("onlineName").value.trim() || "Spieler").slice(0, 20);
    const code = $("onlineCode")
      .value.trim()
      .toUpperCase()
      .replace(/[^A-Z0-9]/g, "");
    if (action === "join" && !code) {
      setStatus("Bitte Einladungscode eingeben.");
      return;
    }
    localStorage.setItem("fw_online_url", url);
    localStorage.setItem("fw_online_name", name);
    leaving = false;
    setStatus("Verbinde zum Server …");
    openSocket(() => send({ type: action, name, code, protocol: PROTOCOL }));
  }

  // Leave the match/lobby (result screen, menu, starting another game).
  window.fwOnlineLeave = function (silent) {
    leaving = true;
    closeSocket();
    leaving = false;
    if (!silent) {
      try {
        openMainMenu();
      } catch (e) {}
    }
  };

  $("onlineOpen").onclick = () => {
    $("onlineOverlay").hidden = false;
  };
  $("onlineClose").onclick = () => {
    $("onlineOverlay").hidden = true;
    if (!match) {
      leaving = true;
      closeSocket();
      leaving = false;
    }
  };
  $("onlineCreate").onclick = () => connect("create");
  $("onlineJoin").onclick = () => connect("join");
  $("onlineReady").onclick = () => {
    ready = !ready;
    send({ type: "ready", ready });
  };
  $("onlineMatchStart").onclick = () => send({ type: "match_start" });
  $("onlineFreddy").onclick = () => {
    if (!room || !socket || socket.readyState !== WebSocket.OPEN) {
      setStatus("Bitte zuerst eine eigene Lobby erstellen.");
      return;
    }
    if (freddySocket && freddySocket.readyState === WebSocket.OPEN) {
      $("onlineFreddyStatus").textContent = "Freddy ist bereits verbunden.";
      return;
    }
    $("onlineFreddyStatus").textContent = "Freddy verbindet sich …";
    let bot;
    try {
      bot = new WebSocket(serverUrl());
    } catch (e) {
      $("onlineFreddyStatus").textContent = "Fehler: " + e.message;
      return;
    }
    freddySocket = bot;
    bot.onopen = () => bot.send(JSON.stringify({ type: "join", code: room, name: "Freddy (Test)", protocol: PROTOCOL }));
    bot.onmessage = (e) => {
      let m;
      try {
        m = JSON.parse(e.data);
      } catch {
        return;
      }
      if (m.type === "room") {
        $("onlineFreddyStatus").textContent = "Freddy ist als zweiter Spieler online!";
        if (!m.youReady) bot.send(JSON.stringify({ type: "ready", ready: true }));
      } else if (m.type === "error") {
        $("onlineFreddyStatus").textContent = "Freddy: " + m.message;
      } else if (m.type === "start") {
        $("onlineFreddyStatus").textContent = "Verbindungstest erfolgreich (Freddy spielt nicht mit).";
      }
    };
    bot.onerror = () => {
      $("onlineFreddyStatus").textContent = "Freddy konnte sich nicht verbinden.";
    };
    bot.onclose = () => {
      if (freddySocket === bot) {
        freddySocket = null;
        $("onlineFreddyStatus").textContent = "Freddy wurde getrennt.";
      }
    };
  };

  $("onlineLeave").onclick = () => {
    leaving = true;
    closeSocket();
    leaving = false;
    setStatus("Lobby verlassen.");
  };
  $("onlineCopy").onclick = async () => {
    const url = serverUrl();
    const link =
      location.protocol === "https:" ? location.href.split("?")[0] + "?room=" + encodeURIComponent(room) : "";
    const invitation =
      "Rivets & Ruin – tritt meiner Lobby bei! Code: " +
      room +
      "\nServer: " +
      url +
      (link ? "\nSpiel: " + link : "");
    try {
      await navigator.clipboard.writeText(invitation);
      setStatus("Einladung kopiert. Jetzt per WhatsApp verschicken.");
    } catch {
      setStatus("Code: " + room + " | Server: " + url + " – bitte manuell kopieren.");
    }
  };
  // for automated tests / debugging
  window.__fwNet = {
    get socket() {
      return socket;
    },
    get match() {
      return match;
    },
  };
  const params = new URLSearchParams(location.search);
  if (params.has("room")) {
    $("onlineCode").value = (params.get("room") || "").slice(0, 8).toUpperCase();
    $("onlineOverlay").hidden = false;
    setStatus("Einladung erkannt. Serveradresse prüfen und „Lobby beitreten“ drücken.");
  }
})();
