(function () {
  const pairs = [
    ["settingDifficulty", "fwDifficultyDisplay"],
    ["fwSettingsScreen", "fwScreenDisplay"],
  ];
  function refresh() {
    for (const [id, displayId] of pairs) {
      const el = document.getElementById(id),
        target = document.getElementById(displayId);
      if (el && target) target.textContent = el.selectedOptions[0]?.textContent || "";
    }
  }
  for (const [id] of pairs) {
    document.getElementById(id)?.addEventListener("change", refresh);
  }
  document.getElementById("mainSettings")?.addEventListener("click", () => requestAnimationFrame(refresh));
  document.getElementById("settingDifficulty")?.addEventListener("input", refresh);
  const originalOpen = openGameSettings;
  openGameSettings = function () {
    originalOpen();
    refresh();
  };
  refresh();
})();
