// V15.61 – Online duel (host-authoritative).
//
// The HOST runs the whole simulation. The GUEST is a full player too: every
// action it takes (beams, buildings, weapons, research, repair, conversions,
// firing) is sent to the host as a command and carried out there with exactly
// the same game code a local player uses.
//
// Trick: game.js is written from the point of view of "player" (left fort) vs.
// "enemy" (right fort). fwSwapSides() flips that view – owners, cores,
// resources, research and money trade places. The guest always looks at the
// world swapped (its own fort is "player"), and the host swaps briefly while it
// executes a guest command. So no player-facing feature had to be duplicated.
//
// The host sends a compact snapshot 4x per second; the guest interpolates
// between snapshots and replays effects (debris, sparks, sounds) locally.
(function () {
  "use strict";
  const SNAP_MS = 250;
  const $ = (id) => document.getElementById(id);

  let net = null; // { role, send(obj) } – set by online-lobby.js
  let ids = { node: 0, gun: 0, shot: 0, fb: 0 };
  let feedback = []; // host -> guest messages for the guest's own actions
  let soundQueue = [];
  let incomeTimer = 0;
  let waitingForPeer = false;
  let startingMatch = false;
  // guest
  let lastApplyAt = 0;
  let lastFeedbackId = 0;
  let cmdSeq = 0;
  let guestGameOverShown = false;
  let lastUnlocked = null;

  // ------------------------------------------------------------ side swap
  const flip = (o) => (o === "enemy" ? "player" : "enemy");
  function fwSwapSides() {
    for (const b of beams) b.owner = flip(b.owner || "player");
    for (const g of guns) g.owner = flip(g.owner || "player");
    [resources, aiResources] = [aiResources, resources];
    for (const r of resources) r.owner = "player";
    for (const r of aiResources) r.owner = "enemy";
    for (const s of shots) {
      s.enemy = !s.enemy;
      if (s.owner) s.owner = flip(s.owner);
    }
    for (const r of fwFlakRounds) if (r.owner) r.owner = flip(r.owner);
    [playerCore, enemyCore] = [enemyCore, playerCore];
    if (playerCore) playerCore.owner = "player";
    if (enemyCore) enemyCore.owner = "enemy";
    [metal, aiMetal] = [aiMetal, metal];
    [energy, aiEnergy] = [aiEnergy, energy];
    [unlockedWeapons, aiUnlockedWeapons] = [aiUnlockedWeapons, unlockedWeapons];
    [researchJob, aiResearchJob] = [aiResearchJob, researchJob];
    fwSidesSwapped = !fwSidesSwapped;
  }
  window.fwSwapSides = fwSwapSides;

  // ------------------------------------------------------------ banner
  const banner = document.createElement("div");
  banner.id = "fwNetBanner";
  banner.hidden = true;
  document.body.appendChild(banner);
  function showBanner(text) {
    banner.textContent = text || "";
    banner.hidden = !text;
  }

  // ------------------------------------------------------------ host: run a guest command
  function asGuest(fn) {
    const tip = $("tip");
    const oldTip = tip.textContent;
    const save = {
      mode,
      buildKind,
      selectedWeapon,
      selectedResource,
      selectedAimGun,
      aimGuns: [...selectedAimGuns],
      aimTarget,
      selectedBeamId,
      zoom,
      preparing: playerVolleyPreparing,
    };
    const vib = window.fwVibrate,
      stat = window.fwStatAdd;
    window.fwVibrate = () => {}; // the guest's actions must not buzz, beep or count on the host's phone
    window.fwStatAdd = () => {};
    const bs = playBuildSound,
      rs = playResearchSound;
    playBuildSound = () => {};
    playResearchSound = () => {};
    fwSwapSides();
    selectedAimGuns.clear();
    selectedAimGun = null;
    aimTarget = null;
    let text = "";
    try {
      tip.textContent = "";
      fn();
      text = tip.textContent;
    } catch (e) {
      console.error(e);
      text = "Aktion fehlgeschlagen.";
    } finally {
      fwSwapSides();
      window.fwVibrate = vib;
      window.fwStatAdd = stat;
      playBuildSound = bs;
      playResearchSound = rs;
      mode = save.mode;
      buildKind = save.buildKind;
      selectedWeapon = save.selectedWeapon;
      selectedResource = save.selectedResource;
      selectedAimGuns.clear();
      for (const g of save.aimGuns) selectedAimGuns.add(g);
      selectedAimGun = save.selectedAimGun;
      aimTarget = save.aimTarget;
      selectedBeamId = save.selectedBeamId;
      zoom = save.zoom;
      playerVolleyPreparing = save.preparing;
      tip.textContent = oldTip;
      hud();
      refreshResearchUI();
      fwUpdateBeamCount();
    }
    return text;
  }

  const num = (v) => Number.isFinite(v);
  const pt = (o) => o && num(o.x) && num(o.y) && Math.abs(o.x) < 5000 && Math.abs(o.y) < 5000;

  // Same steps as the local build gesture in finishSingle().
  function hostBuild(s, p, kind, z) {
    buildKind = ["front", "back", "door", "armor"].includes(kind) ? kind : "front";
    const tip = $("tip");
    const axisTolerance = Math.max(9, 18 / (z || 1));
    const startSnap = snapBuildPoint(s.x, s.y);
    const a = getBuildNode(startSnap.x, startSnap.y);
    if (!beams.some((e) => e.owner === "player" && e.hp > 0 && (e.a === a || e.b === a))) {
      tip.textContent = "Starte am Verbindungspunkt deiner eigenen Festung.";
      cleanNodes();
      return;
    }
    const origin = nodes[a];
    let endX = p.x,
      endY = Math.min(p.y, floor());
    if (Math.abs(endX - origin.x) <= axisTolerance) endX = origin.x;
    if (Math.abs(endY - origin.y) <= axisTolerance) endY = origin.y;
    if (Math.abs(origin.y - floor()) < 2 && endY >= floor() - Math.max(22, 32 / (z || 1))) endY = floor();
    const endSnap = snapBuildPoint(endX, endY, a);
    const b = getBuildNode(endSnap.x, endSnap.y, a);
    if (Math.hypot(nodes[b].x - origin.x, nodes[b].y - origin.y) < MINLEN) {
      tip.textContent = "Balken zu kurz – etwas weiter ziehen.";
      cleanNodes();
    } else if (!beam(a, b)) {
      tip.textContent = "Balken nicht möglich: Nur an deiner Festung, mit gültiger Länge und genügend Eisen.";
      cleanNodes();
    } else {
      tip.textContent = "Balken gebaut."; // no sound here: it would play on the host's phone
    }
    updateStructuralSupport();
  }

  function hostPlace(c) {
    const kind = c.kind === "weapon" ? "weapon" : "resource";
    const type = String(c.type || "");
    if (kind === "weapon" ? !WEAPONS[type] : !RESOURCE_TYPES[type]) return;
    const b = beams.find((x) => x.id === c.beamId);
    const tip = $("tip");
    if (!b || b.owner !== "player" || b.hp <= 0 || b.armorDoor) {
      tip.textContent = "Rot: Nur auf eigenen waagerechten Balken";
      return;
    }
    const a = nodes[b.a],
      z = nodes[b.b];
    const vx = z.x - a.x,
      vy = z.y - a.y;
    if (Math.abs(vy) > Math.max(4, Math.abs(vx) * 0.08)) {
      tip.textContent = "Rot: Nur auf waagerechten Balken";
      return;
    }
    const t = Math.max(0.08, Math.min(0.92, num(c.t) ? c.t : 0.5));
    const mount = { beamId: b.id, t, x: a.x + vx * t, y: a.y + vy * t - 14 };
    if (kind === "weapon" && metal < WEAPONS[type].cost) {
      tip.textContent = "Rot: Nicht genug Eisen (" + WEAPONS[type].cost + " benötigt)";
      return;
    }
    tip.textContent = commitPlacement({ valid: true, mount, kind, type });
  }

  function hostFire(c) {
    const want = new Set((Array.isArray(c.guns) ? c.guns : []).slice(0, 3));
    for (const g of guns) if (g.owner === "player" && want.has(g.fwId) && g.type !== "flak") selectedAimGuns.add(g);
    selectedAimGun = [...selectedAimGuns][0] || null;
    if (!selectedAimGun || !pt(c.aim)) {
      $("tip").textContent = "Keine Waffe ausgewählt.";
      return;
    }
    mode = "shoot";
    aimTarget = limitAimToRange(c.aim.x, c.aim.y);
    shootSelected();
  }

  function command(c) {
    if (!c || typeof c !== "object" || gameOver) return;
    let text = "";
    switch (c.op) {
      case "beam":
        if (pt(c.s) && pt(c.p)) text = asGuest(() => hostBuild(c.s, c.p, c.kind, c.zoom));
        break;
      case "erase":
        if (pt(c)) text = asGuest(() => eraseAt(c.x, c.y));
        break;
      case "repair":
        if (pt(c)) text = asGuest(() => fwRepairAt(c.x, c.y));
        break;
      case "place":
        text = asGuest(() => hostPlace(c));
        break;
      case "kind":
        text = asGuest(() => fwSetBeamKind(beams.find((b) => b.id === c.beamId), c.kind));
        break;
      case "research":
        if (RESEARCH[c.type]) text = asGuest(() => startResearch(c.type));
        break;
      case "fire":
        text = asGuest(() => hostFire(c));
        break;
      default:
        return;
    }
    if (text) feedback.push({ id: ++ids.fb, text: String(text).slice(0, 220) });
    if (feedback.length > 6) feedback = feedback.slice(-6);
  }

  // ------------------------------------------------------------ host: guest economy
  // Offline the AI earns its own money; online the guest gets exactly the
  // player's rules: mines, windmills and the emergency supply.
  function guestIncome(dt) {
    const readyMine = aiResources.some(
      (r) =>
        r.type === "mine" &&
        (r.buildRemaining || 0) <= 0 &&
        beams.some((b) => b.id === r.beamId && b.hp > 0),
    );
    if (!gameOver && !readyMine && aiMetal < RESOURCE_TYPES.mine.cost)
      aiMetal = Math.min(RESOURCE_TYPES.mine.cost, aiMetal + dt * FW_EMERGENCY_METAL);
    incomeTimer += dt;
    if (incomeTimer < 1) return;
    incomeTimer -= 1;
    const count = (t) => aiResources.filter((r) => r.type === t && (r.buildRemaining || 0) <= 0).length;
    aiMetal = Math.min(FW_RESOURCE_CAP, aiMetal + count("mine") * RESOURCE_TYPES.mine.rate);
    aiEnergy = Math.min(FW_RESOURCE_CAP, aiEnergy + count("wind") * RESOURCE_TYPES.wind.rate);
  }

  // ------------------------------------------------------------ host: snapshot
  const SKIP = new Set([
    "fwGun", "flakTarget", "target", "visualMount", "visualAngle", "px", "py", "mass", "grace",
    "fwSent", "aiChamberHeight",
  ]);
  function replacer(key, v) {
    if (SKIP.has(key)) return undefined;
    if (key === "autoTarget") return v ? 1 : null;
    if (key === "trail" && Array.isArray(v)) return v.slice(-24);
    if (typeof v === "number") return Number.isInteger(v) ? v : Math.round(v * 1000) / 1000;
    return v;
  }
  function snapshot() {
    for (const n of nodes) if (n.fwId == null) n.fwId = ++ids.node;
    for (const g of guns) if (g.fwId == null) g.fwId = ++ids.gun;
    for (const s of shots) if (s.fwId == null) s.fwId = ++ids.shot;
    const fx = [];
    for (const p of particles) {
      if (p.fwSent) continue;
      p.fwSent = true;
      if (fx.length < 140) fx.push(p);
    }
    const snd = soundQueue.slice(-24);
    soundQueue = [];
    const data = {
      v: 2,
      bf: BATTLEFIELDS.indexOf(battlefield),
      nodes,
      beams,
      guns,
      resources,
      aiResources,
      shots,
      flak: fwFlakRounds.map((r) => ({ x: r.x, y: r.y, vx: r.vx, vy: r.vy, life: r.life, owner: r.owner })),
      bursts: typeof fwFlakBursts !== "undefined" ? fwFlakBursts : [],
      playerCore,
      enemyCore,
      metal,
      energy,
      aiMetal,
      aiEnergy,
      unlocked: [...unlockedWeapons],
      aiUnlocked: [...aiUnlockedWeapons],
      researchJob,
      aiResearchJob,
      nextBeamId,
      hits,
      guestHits: fwGuestHits,
      time: fwMatchTime,
      gameOver,
      blast: reactorBlast
        ? { x: reactorBlast.x, y: reactorBlast.y, age: performance.now() - reactorBlast.started, duration: reactorBlast.duration }
        : null,
      wait: waitingForPeer,
      fx,
      snd,
      fb: feedback,
    };
    return JSON.parse(JSON.stringify(data, replacer));
  }

  // ------------------------------------------------------------ guest: apply snapshot
  function apply(d) {
    if (!d || d.v !== 2 || !Array.isArray(d.nodes) || !Array.isArray(d.beams)) return;
    if (d.nodes.length > 1500 || d.beams.length > 1800) return;
    const now = performance.now();
    // interpolation: start from what is on screen right now
    const shown = new Map();
    for (const n of nodes) if (n.fwId != null) shown.set(n.fwId, n);
    for (const n of d.nodes) {
      const old = shown.get(n.fwId);
      n.tx = n.x;
      n.ty = n.y;
      n.sx = old ? old.x : n.x;
      n.sy = old ? old.y : n.y;
      n.x = n.sx;
      n.y = n.sy;
      n.px = n.x;
      n.py = n.y;
    }
    const oldGuns = new Map();
    for (const g of guns) if (g.fwId != null) oldGuns.set(g.fwId, g);
    for (const g of d.guns || []) {
      const old = oldGuns.get(g.fwId);
      if (old) {
        if (old.visualMount) g.visualMount = old.visualMount;
        if (Number.isFinite(old.visualAngle)) g.visualAngle = old.visualAngle;
      }
    }
    const oldShots = new Map();
    for (const s of shots) if (s.fwId != null) oldShots.set(s.fwId, s);
    for (const s of d.shots || []) {
      const old = oldShots.get(s.fwId);
      s.tx = s.x;
      s.ty = s.y;
      if (old) {
        s.sx = old.x;
        s.sy = old.y;
      } else if (Array.isArray(s.trail) && s.trail.length >= 2) {
        s.sx = s.trail[0];
        s.sy = s.trail[1];
      } else {
        s.sx = s.x;
        s.sy = s.y;
      }
      s.x = s.sx;
      s.y = s.sy;
      s.px = s.x;
      s.py = s.y;
    }
    fwSidesSwapped = false;
    nodes = d.nodes;
    beams = d.beams;
    guns = d.guns || [];
    resources = d.resources || [];
    aiResources = d.aiResources || [];
    shots = d.shots || [];
    fwFlakRounds = d.flak || [];
    if (typeof fwFlakBursts !== "undefined") fwFlakBursts = d.bursts || [];
    playerCore = d.playerCore;
    enemyCore = d.enemyCore;
    metal = d.metal;
    energy = d.energy;
    aiMetal = d.aiMetal;
    aiEnergy = d.aiEnergy;
    unlockedWeapons = new Set(d.unlocked || []);
    aiUnlockedWeapons = new Set(d.aiUnlocked || []);
    researchJob = d.researchJob || null;
    aiResearchJob = d.aiResearchJob || null;
    nextBeamId = d.nextBeamId || nextBeamId;
    hits = d.guestHits || 0; // the guest's own hits
    $("hits").textContent = hits;
    fwMatchTime = d.time || 0;
    if (d.bf >= 0 && BATTLEFIELDS[d.bf] && battlefield !== BATTLEFIELDS[d.bf]) battlefield = BATTLEFIELDS[d.bf];
    fwSwapSides(); // the guest's own fort is "player"
    lastApplyAt = now;

    // keep the guest's selections (objects were replaced)
    const byId = new Map(guns.map((g) => [g.fwId, g]));
    const sel = [...selectedAimGuns].map((g) => byId.get(g.fwId)).filter((g) => g && g.owner === "player");
    selectedAimGuns.clear();
    for (const g of sel) selectedAimGuns.add(g);
    selectedAimGun = selectedAimGun ? byId.get(selectedAimGun.fwId) || sel[0] || null : null;
    for (let i = 0; i < fwWeaponBanks.length; i++)
      fwWeaponBanks[i] = fwWeaponBanks[i].map((g) => byId.get(g.fwId)).filter(Boolean);
    if (selectedBeamId != null && !beams.some((b) => b.id === selectedBeamId && b.owner === "player")) hideBeamMenu();

    // effects
    for (const p of d.fx || []) particles.push(p);
    if (particles.length > 360) particles = particles.slice(-360);
    for (const e of d.snd || []) {
      try {
        if (e.s === "w") playWeaponSound(e.t);
        else if (e.s === "i") playImpactSound(e.d, e.r);
      } catch (err) {}
    }
    for (const f of d.fb || []) {
      if (f.id <= lastFeedbackId) continue;
      lastFeedbackId = f.id;
      $("tip").textContent = f.text;
    }
    // research finished?
    if (lastUnlocked) {
      for (const t of unlockedWeapons)
        if (!lastUnlocked.has(t)) {
          $("tip").textContent = "Forschung abgeschlossen: " + WEAPONS[t].name + " freigeschaltet!";
          try {
            playResearchSound();
          } catch (e) {}
        }
    }
    lastUnlocked = new Set(unlockedWeapons);

    if (!waitingForPeer) showBanner(d.wait ? "Verbindung zum Gegner unterbrochen – warte bis zu 30 Sekunden …" : "");

    // end of the match
    const wasOver = gameOver;
    gameOver = !!d.gameOver;
    if (d.blast && !reactorBlast)
      reactorBlast = { x: d.blast.x, y: d.blast.y, started: now - d.blast.age, duration: d.blast.duration };
    if (gameOver && !wasOver && !guestGameOverShown) {
      guestGameOverShown = true;
      const won = !!enemyCore?.dead && !playerCore?.dead;
      $("tip").textContent = won ? "Gegnerischer Reaktor zerstört! SIEG!" : "Dein Reaktor wurde zerstört! NIEDERLAGE";
      try {
        window.fwOnMatchEnd && window.fwOnMatchEnd(won);
      } catch (e) {}
      setTimeout(() => showResult(won ? "SIEG!" : "NIEDERLAGE", won ? "Gegnerischer Reaktor zerstört!" : "Dein Reaktor wurde zerstört!", won), 1450);
    }
    hud();
    fwUpdateBeamCount();
    if (now - (apply.uiAt || 0) > 500) {
      apply.uiAt = now;
      refreshResearchUI();
    }
  }

  function showResult(title, sub, good) {
    $("resultTitle").textContent = title;
    $("resultTitle").style.color = good ? "#f8d578" : "#ff837a";
    $("resultSubtitle").textContent = sub;
    $("resultRestart").textContent = "↩ Zurück zum Menü";
    $("resultOverlay").hidden = false;
  }

  // ------------------------------------------------------------ guest: per-frame visuals
  function guestStep(dt) {
    const k = Math.max(0, Math.min(1, (performance.now() - lastApplyAt) / SNAP_MS));
    for (const n of nodes) {
      if (n.tx == null) continue;
      n.x = n.sx + (n.tx - n.sx) * k;
      n.y = n.sy + (n.ty - n.sy) * k;
    }
    for (const s of shots) {
      if (s.tx == null) continue;
      s.px = s.x;
      s.py = s.y;
      s.x = s.sx + (s.tx - s.sx) * k;
      s.y = s.sy + (s.ty - s.sy) * k;
    }
    for (const r of fwFlakRounds) {
      r.x += r.vx * dt;
      r.y += r.vy * dt;
    }
    for (const g of guns) if (g.flash > 0) g.flash = Math.max(0, g.flash - dt);
    particles.forEach((p) => {
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += (p.kind === "smoke" ? -100 : p.kind === "spark" ? 150 : 300) * dt;
      p.vx *= p.kind === "smoke" ? 0.985 : 0.996;
      p.life -= dt;
    });
    particles = particles.filter((p) => p.life > 0);
    if (!gameOver && !waitingForPeer && lastApplyAt && performance.now() - lastApplyAt > 2500)
      showBanner("Keine Daten vom Host – warte auf Verbindung …");
  }

  // ------------------------------------------------------------ hooks into game.js
  const origPhysics = physics;
  physics = function (dt) {
    if (net?.role === "guest") return guestStep(dt);
    if (net?.role === "host") {
      if (waitingForPeer) return;
      guestIncome(dt);
    }
    return origPhysics(dt);
  };
  const origWeaponSound = playWeaponSound;
  playWeaponSound = function (type) {
    if (net?.role === "host") soundQueue.push({ s: "w", t: type });
    return origWeaponSound.apply(this, arguments);
  };
  const origImpactSound = playImpactSound;
  playImpactSound = function (damage, radius) {
    if (net?.role === "host") soundQueue.push({ s: "i", d: damage, r: radius });
    return origImpactSound.apply(this, arguments);
  };

  // Guest: world-changing actions go to the host instead of being done locally.
  function sendCmd(c) {
    if (!net || net.role !== "guest") return false;
    c.id = ++cmdSeq;
    net.send(c);
    return true;
  }
  const isGuest = () => net?.role === "guest";
  window.fwOnlineGuestGesture = function (m, s, p) {
    if (!isGuest()) return false;
    if (gameOver) return true;
    if (m === "build") {
      if (Math.hypot(p.x - s.x, p.y - s.y) < MINLEN) return false; // tap: local beam menu
      hideBeamMenu();
      sendCmd({ op: "beam", s: { x: s.x, y: s.y }, p: { x: p.x, y: p.y }, kind: buildKind, zoom });
      $("tip").textContent = "Balken wird gebaut …";
      return true;
    }
    if (m === "erase" || m === "repair") {
      sendCmd({ op: m, x: p.x, y: p.y });
      $("tip").textContent = m === "erase" ? "Wird entfernt …" : "Wird repariert …";
      return true;
    }
    return false;
  };
  const origCommit = commitPlacement;
  commitPlacement = function (p) {
    if (!isGuest()) return origCommit(p);
    if (!p || !p.valid || !p.mount) return "Rot: " + (p?.reason || "Hier kann nicht gebaut werden");
    sendCmd({ op: "place", kind: p.kind, type: p.type, beamId: p.mount.beamId, t: p.mount.t });
    return "Bauauftrag gesendet …";
  };
  const origKind = fwSetBeamKind;
  fwSetBeamKind = function (b, kind) {
    if (!isGuest()) return origKind(b, kind);
    if (!b) return;
    sendCmd({ op: "kind", beamId: b.id, kind });
    $("tip").textContent = "Umbau wird ausgeführt …";
  };
  const origResearch = startResearch;
  startResearch = function (type) {
    if (!isGuest()) return origResearch(type);
    if (unlockedWeapons.has(type) || researchJob) return;
    sendCmd({ op: "research", type });
    $("tip").textContent = "Forschung wird gestartet …";
  };
  $("aimFire").addEventListener(
    "click",
    (e) => {
      if (!isGuest()) return;
      e.stopImmediatePropagation();
      if (gameOver || !aimTarget) return;
      const list = selectedGuns().map((g) => g.fwId);
      if (!list.length) return;
      sendCmd({ op: "fire", guns: list, aim: { x: aimTarget.x, y: aimTarget.y } });
      for (const g of selectedGuns()) g.lastAim = { x: aimTarget.x, y: aimTarget.y };
    },
    true,
  );
  const block = (id, text) =>
    $(id)?.addEventListener(
      "click",
      (e) => {
        if (!net) return;
        e.stopImmediatePropagation();
        e.preventDefault();
        $("tip").textContent = text;
      },
      true,
    );
  block("undo", "Rückgängig ist in Online-Partien nicht verfügbar.");
  block("test", "Online-Partien laufen ohne Pause weiter.");
  block("cheatButton", "Cheats sind online deaktiviert.");
  block("enemy", "In Online-Partien spielt keine KI mit.");
  block("demo", "Im Online-Duell nicht verfügbar.");
  block("save", "Online-Partien können nicht gespeichert werden.");
  block("load", "Während eines Online-Duells nicht verfügbar.");
  $("resultRestart").addEventListener(
    "click",
    (e) => {
      if (!net) return;
      e.stopImmediatePropagation();
      $("resultOverlay").hidden = true;
      window.fwOnlineLeave && window.fwOnlineLeave();
    },
    true,
  );

  // The menu never pauses an online match (the other player keeps playing).
  const origOpenMenu = openMainMenu;
  openMainMenu = function () {
    const r = origOpenMenu.apply(this, arguments);
    if (net) {
      paused = false;
      menuWasPaused = false;
      fwSetPauseOrb(false);
    }
    return r;
  };
  // Starting any other game ends the online match.
  const origReset = reset;
  reset = function () {
    if (net && !startingMatch) window.fwOnlineLeave && window.fwOnlineLeave(true);
    return origReset.apply(this, arguments);
  };

  // ------------------------------------------------------------ API for online-lobby.js
  window.FWGameNet = {
    SNAP_MS,
    start(role, send) {
      startingMatch = true;
      try {
        reset();
      } finally {
        startingMatch = false;
      }
      net = { role, send };
      window.FWOnlineMatch = { role };
      ids = { node: 0, gun: 0, shot: 0, fb: 0 };
      feedback = [];
      soundQueue = [];
      incomeTimer = 0;
      waitingForPeer = false;
      lastApplyAt = 0;
      lastFeedbackId = 0;
      cmdSeq = 0;
      guestGameOverShown = false;
      lastUnlocked = null;
      cheatMode = false;
      window.fwMission = null;
      enemyOn = false;
      enemyStarted = true;
      aiMetal = metal;
      aiEnergy = energy;
      aiUnlockedWeapons = new Set(["mg", "cannon"]);
      aiResearchJob = null;
      paused = false;
      fwSetPauseOrb(false);
      $("difficultyOverlay").hidden = true;
      mainOverlay.hidden = true;
      $("resultOverlay").hidden = true;
      menuHasGame = true;
      menuWasPaused = false;
      openingCamera = null;
      zoom = 0.62;
      camX = W * 0.5 - (role === "guest" ? 1920 : 320) * zoom;
      camY = H * 0.72 - floor() * zoom;
      $("zoomlevel").textContent = Math.round(zoom * 100) + "%";
      if (role === "guest") {
        fwSwapSides();
        nodes = [];
        beams = [];
        guns = [];
        shots = [];
      }
      $("tip").textContent =
        role === "host"
          ? "ONLINE-DUELL: Deine Festung ist links. Zerstöre den Reaktor rechts!"
          : "ONLINE-DUELL: Deine Festung ist rechts. Zerstöre den Reaktor links!";
      showBanner("");
      $("resultRestart").textContent = "↩ Zurück zum Menü";
      hud();
    },
    stop() {
      net = null;
      window.FWOnlineMatch = null;
      waitingForPeer = false;
      fwSidesSwapped = false;
      showBanner("");
      $("resultRestart").textContent = "↻ Neue Runde";
    },
    snapshot,
    apply,
    command,
    peerWaiting(on) {
      waitingForPeer = !!on;
      showBanner(on ? "Verbindung zum Gegner unterbrochen – warte bis zu 30 Sekunden …" : "");
    },
    peerLeft() {
      if (!net) return;
      waitingForPeer = false;
      if (!gameOver) {
        gameOver = true;
        showResult("PARTIE BEENDET", "Dein Gegner hat die Partie verlassen.", true);
      }
      showBanner("");
    },
    showBanner,
  };
})();
