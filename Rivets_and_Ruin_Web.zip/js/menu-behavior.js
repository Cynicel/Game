(function () {
  const $ = (id) => document.getElementById(id);
  function bind(id, fn) {
    const e = $(id);
    if (e) e.addEventListener("click", fn);
  }
  bind("fwStats", () => {
    const c = document.getElementById("fwStatsDialog");
    if (c) c.hidden = false;
  });
  bind("fwRecord", () => {
    const c = document.getElementById("fwStatsDialog");
    if (c) c.hidden = false;
  });
  bind("fwMore", () => {
    const c = document.getElementById("fwMoreDialog");
    if (c) c.hidden = false;
  });
  bind("fwProfile", () => {
    const c = document.getElementById("fwProfileDialog");
    if (c) c.hidden = false;
  });
  let muted = false,
    musicMuted = false;
  bind("fwSound", () => {
    if (window.fwToggleSound) fwToggleSound();
  });
  bind("fwMusic", () => {
    if (window.fwToggleMusic) fwToggleMusic();
  });
})();
