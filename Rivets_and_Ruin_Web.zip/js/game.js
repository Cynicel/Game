// V15.12: Preserve the circular Pause/Weiter button even when the game switches state.
function fwSetPauseOrb(isPaused) {
  const btn = document.getElementById("test");
  if (!btn) return;
  const label = isPaused ? "Weiter" : "Pause",
    symbol = isPaused ? "▶" : "⏸";
  btn.innerHTML =
    '<span class="fwOrbIcon" aria-hidden="true">' +
    symbol +
    '</span><span class="fwOrbLabel">' +
    label +
    "</span>";
  btn.setAttribute("aria-label", label);
  btn.title = label;
}
const c = document.getElementById("c"),
  ctx = c.getContext("2d"),
  buttons = ["build", "erase", "test", "shoot", "repair"];
let W,
  H,
  dpr,
  mode = "build",
  nodes = [],
  beams = [],
  shots = [],
  particles = [],
  drag = null,
  hits = 0,
  last = performance.now(),
  acc = 0;
const GRAV = 900,
  MAXLEN = 175,
  MINLEN = 14,
  WORLD_W = 2400,
  WORLD_H = 1100;
let metal = 105,
  energy = 35,
  enemyOn = false,
  enemyTimer = 0,
  resourceTimer = 0,
  aim = null,
  enemyCore = null,
  playerCore = null,
  gameOver = false,
  enemyPlan = [],
  enemyBuildTimer = 0,
  enemyReady = false,
  enemyStarted = false;
let fxClock = 0;
let reactorBlast = null;
let resultTimeout = null;
let buildingEnemy = false;
let initializingFort = false;
let guns = [];
let resources = [],
  aiResources = [];
let doorMode = "auto",
  doorsForcedOpen = false;
let nextBeamId = 1;
let buildKind = "front";
let selectedWeapon = "cannon";
const WEAPONS = {
  mg: {
    name: "Leichtes MG",
    cost: 35,
    damage: 6,
    speed: 1100,
    radius: 15,
    energy: 3,
    cooldown: 1.8,
    ball: 4,
    magazine: 8,
    shotDelay: 0.23,
    reload: 5.88,
  },
  cannon: {
    name: "Leichte Kanone",
    cost: 60,
    damage: 30,
    speed: 1100,
    radius: 62,
    energy: 12,
    cooldown: 5.5,
    ball: 8,
    reload: 9.5,
  },
  rocket: {
    name: "Rakete",
    cost: 95,
    damage: 75,
    speed: 1100,
    radius: 100,
    energy: 28,
    cooldown: 9,
    ball: 11,
    reload: 12.6,
  },
  autocannon: {
    name: "Autokanone",
    cost: 110,
    damage: 18,
    speed: 1100,
    radius: 34,
    energy: 8,
    cooldown: 2.8,
    ball: 6,
    reload: 3.92,
  },
  heavy: {
    name: "Schwere Kanone",
    cost: 160,
    damage: 120,
    speed: 1100,
    radius: 125,
    energy: 38,
    cooldown: 12,
    ball: 13,
    reload: 19.5,
  },
  sniper: {
    name: "Präzisionsgeschütz",
    cost: 125,
    damage: 65,
    speed: 1100,
    radius: 20,
    energy: 24,
    cooldown: 8,
    ball: 5,
    reload: 11.2,
  },
  mortar: {
    name: "Mörser",
    cost: 135,
    damage: 88,
    speed: 1100,
    radius: 140,
    energy: 26,
    cooldown: 10,
    ball: 11,
    reload: 14,
  },
  flak: {
    name: "Flak-Abwehr",
    cost: 125,
    damage: 0,
    speed: 1100,
    radius: 0,
    energy: 5,
    cooldown: 0.85,
    ball: 3,
    reload: 0.85,
    pointDefense: true,
  },
};
const RESEARCH = {
  autocannon: { metal: 75, energy: 35, time: 20 },
  rocket: { metal: 85, energy: 55, time: 25 },
  sniper: { metal: 105, energy: 60, time: 30 },
  mortar: { metal: 115, energy: 70, time: 35 },
  heavy: { metal: 145, energy: 95, time: 45 },
  flak: { metal: 95, energy: 55, time: 28 },
};
let cheatMode = false;
const CHEAT_SUPPLY = 999999;
let unlockedWeapons = new Set(["mg", "cannon"]),
  researchJob = null;
let aiUnlockedWeapons = new Set(["mg", "cannon"]),
  aiResearchJob = null;
// Online (V15.61): the guest sees and controls its own fort as "player". While the
// two sides are swapped, the right-hand fort is the "player" one, so the direction
// a weapon faces must not be derived from its owner alone.
let fwSidesSwapped = false,
  fwGuestHits = 0;
const fwFacesLeft = (owner) => (owner === "enemy") !== fwSidesSwapped;
// Left-facing art is drawn mirrored; this converts a world angle into that mirrored frame.
const fwMirrorAngle = (a) => Math.atan2(Math.sin(Math.PI - a), Math.cos(Math.PI - a));
function refreshArsenalLocks() {
  const workshopReady =
    cheatMode ||
    resources.some(
      (r) =>
        r.owner === "player" &&
        r.type === "workshop" &&
        (r.buildRemaining || 0) <= 0 &&
        beams.some((b) => b.id === r.beamId),
    );
  for (const card of document.querySelectorAll("#weaponDock .weaponCard[data-weapon]")) {
    const researched = unlockedWeapons.has(card.dataset.weapon);
    const missionBlocked = !!window.fwMission?.allowed && !window.fwMission.allowed.includes(card.dataset.weapon);
    card.classList.toggle("missionBlocked", missionBlocked);
    const locked = !researched || !workshopReady || missionBlocked;
    card.classList.toggle("locked", locked);
    card.classList.toggle("needsWorkshop", researched && !workshopReady);
    card.setAttribute("aria-disabled", String(locked));
  }
}
function refreshResearchUI() {
  const status = document.getElementById("researchStatus"),
    cards = document.getElementById("researchCards");
  if (!status || !cards) return;
  status.textContent = researchJob
    ? "Forschung: " +
      WEAPONS[researchJob.type].name +
      " · " +
      Math.ceil(researchJob.remaining) +
      " s verbleibend"
    : "Forschung bereit – wähle deine nächste Waffe";
  cards.innerHTML = Object.entries(RESEARCH)
    .map(([type, r]) => {
      const ready = unlockedWeapons.has(type),
        active = researchJob?.type === type;
      const label = ready
        ? "✓ ERFORSCHT"
        : active
          ? "⌛ " + Math.ceil(researchJob.remaining) + " s"
          : "⚙ " + r.metal + " · ⚡ " + r.energy + " · " + r.time + " s";
      return (
        '<button type="button" class="researchCard ' +
        (ready ? "ready" : active ? "busy" : "") +
        '" data-research="' +
        type +
        '" ' +
        (ready || researchJob || metal < r.metal || energy < r.energy ? "disabled" : "") +
        "><strong>" +
        WEAPONS[type].name +
        "</strong><span>" +
        label +
        "</span></button>"
      );
    })
    .join("");
  refreshArsenalLocks();
}
function startResearch(type) {
  const r = RESEARCH[type];
  if (!r || unlockedWeapons.has(type) || researchJob || paused || gameOver) return;
  if (window.fwMission?.allowed && !window.fwMission.allowed.includes(type)) {
    document.getElementById("tip").textContent = "Diese Waffe ist in dieser Mission nicht erlaubt.";
    return;
  }
  if (metal < r.metal || energy < r.energy) {
    document.getElementById("tip").textContent = "Nicht genug Ressourcen für diese Forschung.";
    return;
  }
  metal -= r.metal;
  energy -= r.energy;
  researchJob = { type, remaining: r.time };
  document.getElementById("tip").textContent = "Forschung gestartet: " + WEAPONS[type].name;
  hud();
  refreshResearchUI();
}
document.getElementById("researchCards").addEventListener("click", (e) => {
  const card = e.target.closest("[data-research]");
  if (card) startResearch(card.dataset.research);
});
let researchUiClock = 0;
function updateResearch(dt) {
  if (researchJob) {
    researchJob.remaining -= dt;
    if (researchJob.remaining <= 0) {
      unlockedWeapons.add(researchJob.type);
      document.getElementById("tip").textContent =
        "Forschung abgeschlossen: " + WEAPONS[researchJob.type].name + " freigeschaltet!";
      playResearchSound();
      researchJob = null;
    }
  }
  if (aiResearchJob) {
    aiResearchJob.remaining -= dt;
    if (aiResearchJob.remaining <= 0) {
      aiUnlockedWeapons.add(aiResearchJob.type);
      aiResearchJob = null;
    }
  }
  researchUiClock += dt;
  if (researchUiClock > 0.5) {
    researchUiClock = 0;
    refreshResearchUI();
  }
}
function aiPlanResearch() {
  if (aiResearchJob || !enemyOn || gameOver) return;
  const liveBuildings = aiResources.filter(
    (r) =>
      r.hp > 0 &&
      beams.some((b) => b.id === r.beamId && b.owner === "enemy" && b.hp > 0 && (b.buildRemaining || 0) <= 0),
  );
  const readyType = (t) => liveBuildings.some((r) => r.type === t && (r.buildRemaining || 0) <= 0);
  // V15.58: Never buy upgrades instead of replacing the only mine, windmill or workshop.
  if (!readyType("mine") || !readyType("wind") || !readyType("workshop")) return;
  const combatGuns = guns.filter((g) => g.owner === "enemy" && g.hp > 0 && g.type !== "flak");
  if (!combatGuns.length) return;
  const threatenedByMissiles =
    guns.some(
      (g) =>
        g.owner === "player" &&
        g.hp > 0 &&
        ["rocket", "mortar"].includes(g.type) &&
        (g.buildRemaining || 0) <= 0,
    ) || shots.some((s) => !s.enemy && ["rocket", "mortar"].includes(s.weaponType) && s.life > 0);
  const flakPending =
    threatenedByMissiles && !guns.some((g) => g.owner === "enemy" && g.hp > 0 && g.type === "flak");
  // Once AA technology is available, spend saved metal on the actual battery.
  if (flakPending && aiUnlockedWeapons.has("flak")) return;
  const priority = flakPending
    ? ["flak", "autocannon", "rocket", "sniper", "mortar", "heavy"]
    : ["autocannon", "rocket", "sniper", "mortar", "heavy", "flak"];
  // Upgrade after first gun, but save enough to also field a real weapon afterwards.
  const available = priority.filter(
    (t) => !aiUnlockedWeapons.has(t) && aiMetal >= RESEARCH[t].metal && aiEnergy >= RESEARCH[t].energy,
  );
  for (const type of available) {
    if (flakPending && type !== "flak") continue;
    const r = RESEARCH[type];
    const reserve =
      flakPending && type === "flak" ? 20 : combatGuns.length < 2 ? WEAPONS.cannon.cost : WEAPONS.mg.cost;
    if (aiMetal - r.metal < reserve) continue;
    aiMetal -= r.metal;
    aiEnergy -= r.energy;
    aiResearchJob = { type, remaining: r.time };
    aiLastAction = "Erforscht " + WEAPONS[type].name;
    break;
  }
}
const FW_RESOURCE_CAP = 999,
  FW_EMERGENCY_METAL = 1.8;
const RESOURCE_TYPES = {
  mine: { cost: 80, rate: 4 },
  wind: { cost: 65, rate: 3 },
  workshop: { cost: 95, rate: 0 },
  repair: { cost: 90, rate: 0 },
};
const BUILD_TIMES = {
  mg: 9,
  cannon: 16,
  rocket: 23,
  autocannon: 19,
  heavy: 30,
  sniper: 24,
  mortar: 26,
  flak: 22,
  mine: 10,
  wind: 12,
  workshop: 18,
  repair: 14,
  wood: 1.8,
  door: 4,
  armor: 4,
};
const REPAIR_STATS = { radius: 150, beamRate: 13, structureRate: 9 }; // reactor: no repair
const cost = 12;
const FW_ARMOR_UPGRADE_COST = 48;
let fwMatchTime = 0;
let zoom = 1,
  camX = 0,
  camY = 0,
  panStart = null,
  material = "wood",
  paused = false;
const screenToWorld = (x, y) => ({ x: (x - camX) / zoom, y: (y - camY) / zoom });
function setZoom(z) {
  openingCamera = null;
  let old = zoom;
  zoom = Math.max(0.16, Math.min(2.6, z));
  camX = W / 2 - ((W / 2 - camX) * zoom) / old;
  camY = H / 2 - ((H / 2 - camY) * zoom) / old;
  document.getElementById("zoomlevel").textContent = Math.round(zoom * 100) + "%";
}
function hud() {
  refreshArsenalLocks();
  document.getElementById("metal").textContent = Math.floor(metal);
  document.getElementById("energy").textContent = Math.floor(energy);
  document.getElementById("status").textContent = gameOver
    ? playerCore?.dead
      ? "NIEDERLAGE!"
      : "SIEG!"
    : paused
      ? "Pausiert"
      : "Schwerkraft aktiv";
}
function resize() {
  dpr = Math.min(devicePixelRatio || 1, 2);
  W = innerWidth;
  H = innerHeight - 48;
  c.width = W * dpr;
  c.height = H * dpr;
  c.style.width = W + "px";
  c.style.height = H + "px";
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}
addEventListener("resize", resize);
resize();
const floor = () => WORLD_H - 55;
function node(x, y, fixed = false) {
  y = Math.min(y, floor());
  fixed = fixed || y >= floor() - 9;
  if (fixed) y = floor();
  let n = {
    x,
    y,
    px: x,
    py: y,
    homeX: x,
    homeY: y,
    fixed,
    temporary: !fixed,
    provisional: !fixed,
    mass: 1,
    grace: 0,
  };
  nodes.push(n);
  return nodes.length - 1;
}
function nearest(x, y, r = 23) {
  let best = -1,
    dist = r;
  nodes.forEach((n, i) => {
    let d = Math.hypot(n.x - x, n.y - y);
    if (d < dist) {
      dist = d;
      best = i;
    }
  });
  return best;
}
function getNode(x, y) {
  y = Math.min(y, floor());
  let i = nearest(x, y);
  return i >= 0 ? i : node(x, y, y >= floor() - 9);
}
function connectedBuildJoint(a, b, owner) {
  // A new beam must touch an existing joint belonging to the builder's fort.
  // Ground contact alone does not count as a connection.
  return beams.some(
    (e) => e.owner === owner && e.hp > 0 && (e.a === a || e.b === a || e.a === b || e.b === b),
  );
}
function beam(a, b, free = false) {
  if (!initializingFort && !connectedBuildJoint(a, b, buildingEnemy ? "enemy" : "player")) return false;
  if (nodes[a]?.y > floor() + 0.01 || nodes[b]?.y > floor() + 0.01) return false;
  if (a === b || beams.some((e) => (e.a === a && e.b === b) || (e.a === b && e.b === a))) return;
  let A = nodes[a],
    B = nodes[b],
    len = Math.hypot(A.x - B.x, A.y - B.y);
  const fwPrice =
    !buildingEnemy && ["door", "armor"].includes(buildKind) ? cost + FW_ARMOR_UPGRADE_COST : cost;
  if (len < MINLEN || len > MAXLEN || (!free && metal < fwPrice)) return false;
  if (!free) metal -= fwPrice;
  const maxHp = buildingEnemy ? 100 : buildKind === "door" ? 220 : buildKind === "armor" ? 256 : 100;
  beams.push({
    id: nextBeamId++,
    a,
    b,
    len,
    hp: maxHp,
    maxHp,
    kind: "wood",
    background: !buildingEnemy && buildKind === "back",
    armorDoor: !buildingEnemy && buildKind === "door",
    armorWall: !buildingEnemy && buildKind === "armor",
    doorTimer: 0,
    doorProgress: 0,
    owner: buildingEnemy ? "enemy" : "player",
    paid: free || buildingEnemy ? 0 : fwPrice,
    buildRemaining: free
      ? 0
      : ["door", "armor"].includes(buildKind)
        ? BUILD_TIMES[buildKind]
        : BUILD_TIMES.wood,
    buildTotal: free ? 0 : ["door", "armor"].includes(buildKind) ? BUILD_TIMES[buildKind] : BUILD_TIMES.wood,
  });
  hud();
  fwUpdateBeamCount();
  return true;
}
function cleanNodes() {
  const used = new Set();
  for (const b of beams) {
    used.add(b.a);
    used.add(b.b);
  }
  const mapping = new Map(),
    kept = [];
  nodes.forEach((n, i) => {
    if (used.has(i)) {
      mapping.set(i, kept.length);
      kept.push(n);
    }
  });
  nodes = kept;
  for (const b of beams) {
    b.a = mapping.get(b.a);
    b.b = mapping.get(b.b);
  }
  resources = resources.filter((r) => beams.some((b) => b.id === r.beamId));
  aiResources = aiResources.filter((r) => beams.some((b) => b.id === r.beamId));
  guns = guns.filter((g) => (g.beamId != null ? beams.some((b) => b.id === g.beamId) : mapping.has(g.node)));
  for (const g of guns) if (g.beamId == null) g.node = mapping.get(g.node);
}
function fwPlayerBeamCount() {
  return beams.filter((b) => b.owner === "player" && b.hp > 0).length;
}
function fwUpdateBeamCount() {
  const el = document.getElementById("count");
  if (el) el.textContent = fwPlayerBeamCount();
}
function undo() {
  for (let i = beams.length - 1; i >= 0; i--) {
    const b = beams[i];
    if (b.owner !== "player" || !b.paid) continue;
    beams.splice(i, 1);
    metal += b.paid;
    hud();
    cleanNodes();
    fwUpdateBeamCount();
    updateStructuralSupport();
    return;
  }
  document.getElementById("tip").textContent = "Nichts zum Rückgängigmachen.";
}
function eraseAt(x, y) {
  const own = (b) => b.owner === "player";
  let selected = nearest(x, y, 20);
  if (selected >= 0 && beams.some((b) => own(b) && (b.a === selected || b.b === selected))) {
    beams = beams.filter((b) => !(own(b) && (b.a === selected || b.b === selected)));
    cleanNodes();
    fwUpdateBeamCount();
    updateStructuralSupport();
    return;
  }
  let idx = -1,
    best = 19;
  beams.forEach((b, i) => {
    if (!own(b)) return;
    let a = nodes[b.a],
      d = nodes[b.b],
      vx = d.x - a.x,
      vy = d.y - a.y,
      t = Math.max(0, Math.min(1, ((x - a.x) * vx + (y - a.y) * vy) / (vx * vx + vy * vy || 1))),
      dist = Math.hypot(x - (a.x + vx * t), y - (a.y + vy * t));
    if (dist < best) {
      best = dist;
      idx = i;
    }
  });
  if (idx >= 0) {
    beams.splice(idx, 1);
    cleanNodes();
    fwUpdateBeamCount();
    updateStructuralSupport();
  } else if (closestBeam(x, y, 19) || nearest(x, y, 20) >= 0) {
    document.getElementById("tip").textContent = "Du kannst nur Balken deiner eigenen Festung löschen.";
  }
}
function reactor(x, y, owner) {
  return { x, y, owner, hp: 500, maxHp: 500, dead: false };
}
function finishRound(core) {
  if (gameOver) return;
  core.dead = true;
  gameOver = true;
  enemyOn = false;
  paused = true;
  try {
    fwOnMatchEnd(core.owner === "enemy");
  } catch (e) {}
  reactorBlast = { x: core.x, y: core.y, started: performance.now(), duration: 2200 };
  // The reactor explosion also damages the surrounding fort, without recursively
  // triggering the already destroyed core.
  explode(core.x, core.y, 260, 195);
  for (let i = 0; i < 175; i++) {
    const a = Math.random() * Math.PI * 2,
      v = 80 + Math.random() * 650;
    particles.push({
      x: core.x,
      y: core.y,
      vx: Math.cos(a) * v,
      vy: Math.sin(a) * v,
      life: 0.7 + Math.random() * 1.4,
      blast: true,
    });
  }
  document.getElementById("tip").textContent =
    core.owner === "enemy" ? "Reaktor zerstört! SIEG!" : "Dein Reaktor wurde zerstört!";
  if (resultTimeout) clearTimeout(resultTimeout);
  resultTimeout = setTimeout(() => {
    if (!gameOver) return;
    document.getElementById("resultTitle").textContent = core.owner === "enemy" ? "SIEG!" : "NIEDERLAGE";
    document.getElementById("resultTitle").style.color = core.owner === "enemy" ? "#f8d578" : "#ff837a";
    document.getElementById("resultSubtitle").textContent =
      core.owner === "enemy" ? "Gegnerischer Reaktor zerstört!" : "Dein Reaktor wurde zerstört!";
    document.getElementById("resultOverlay").hidden = false;
  }, 1450);
}
function drawReactorBlast() {
  if (!reactorBlast) return;
  const elapsed = performance.now() - reactorBlast.started;
  if (elapsed > reactorBlast.duration) {
    reactorBlast = null;
    return;
  }
  const t = elapsed / 1000,
    x = reactorBlast.x,
    y = reactorBlast.y;
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  const radius = Math.min(210, 18 + t * 210),
    opacity = Math.max(0, 1 - t / 1.7);
  const g = ctx.createRadialGradient(x, y, 0, x, y, radius);
  g.addColorStop(0, "rgba(255,255,235," + 0.8 * opacity + ")");
  g.addColorStop(0.22, "rgba(255,211,55," + 0.8 * opacity + ")");
  g.addColorStop(0.58, "rgba(255,76,13," + 0.48 * opacity + ")");
  g.addColorStop(1, "rgba(255,50,10,0)");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "rgba(255,215,118," + opacity + ")";
  ctx.lineWidth = 9 + t * 9;
  ctx.beginPath();
  ctx.arc(x, y, Math.min(260, 25 + t * 245), 0, Math.PI * 2);
  ctx.stroke();
  for (let i = 0; i < 24; i++) {
    const a = (i * Math.PI) / 12 + i * 0.04,
      dist = t * (160 + (i % 5) * 34);
    ctx.fillStyle = i % 3 === 0 ? "#fff3aa" : "#ff7c27";
    ctx.beginPath();
    ctx.arc(x + Math.cos(a) * dist, y + Math.sin(a) * dist, Math.max(0, 8 - t * 3), 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}
function coreDamage(x, y, damage, radius) {
  for (const core of [playerCore, enemyCore]) {
    if (!core || core.dead) continue;
    const distance = Math.hypot(x - core.x, y - core.y);
    if (distance > radius + 23) continue;
    const amount = damage * Math.max(0.12, 1 - distance / (radius + 28));
    core.repairBlockedUntil = performance.now() + 4000;
    core.hp = Math.max(0, core.hp - amount);
    if (core.hp <= 0) {
      finishRound(core);
    }
  }
  hud();
}
function getBeamMaxHp(b) {
  return b.maxHp ?? (b.armorWall ? 256 : b.armorDoor ? 220 : 100);
}
function getGunMaxHp(g) {
  return g.maxHp || 130;
}
function getResourceMaxHp(r) {
  return r.maxHp || { mine: 110, wind: 105, workshop: 140, repair: 125 }[r.type] || 120;
}
function getResourceWorldPos(r) {
  const beam = beams.find((b) => b.id === r.beamId && b.hp > 0);
  if (!beam) return null;
  const a = nodes[beam.a],
    d = nodes[beam.b];
  if (!a || !d) return null;
  const t = r.t ?? 0.5;
  return { x: a.x + (d.x - a.x) * t, y: a.y + (d.y - a.y) * t - 18 };
}
function pointSegmentDistance(px, py, ax, ay, bx, by) {
  const dx = bx - ax,
    dy = by - ay;
  const t = Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy || 1)));
  const x = ax + dx * t,
    y = ay + dy * t;
  return Math.hypot(px - x, py - y);
}
function damageResource(r, amount) {
  r.repairBlockedUntil = performance.now() + 4000;
  r.maxHp = getResourceMaxHp(r);
  r.hp = (r.hp ?? r.maxHp) - amount;
  if (r.hp <= 0) r.destroyed = true;
}
function damageGun(g, amount) {
  g.repairBlockedUntil = performance.now() + 4000;
  g.maxHp = getGunMaxHp(g);
  g.hp = (g.hp ?? g.maxHp) - amount;
  if (g.hp <= 0) g.destroyed = true;
}
function healObject(o, amount, getter) {
  o.maxHp = getter(o);
  o.hp = Math.min(o.maxHp, (o.hp ?? o.maxHp) + amount);
}
function drawStructureWear(r) {
  const max = getResourceMaxHp(r),
    hp = r.hp ?? max,
    dmg = Math.max(0, 1 - hp / max);
  if (dmg < 0.18) return;
  ctx.save();
  ctx.globalAlpha = Math.min(0.82, 0.35 + dmg * 0.5);
  ctx.fillStyle = "rgba(36,21,13,.22)";
  ctx.beginPath();
  ctx.ellipse(-2, 2, 24, 14, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "rgba(38,23,18," + (0.25 + dmg * 0.65) + ")";
  ctx.lineWidth = 1.7;
  for (let i = 0; i < 3 + Math.round(dmg * 3); i++) {
    const sx = -16 + i * 10,
      sy = -8 + (i % 2) * 8;
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.lineTo(sx + 5, -2 + (i % 3) * 5);
    ctx.lineTo(sx + 1, 7 + (i % 2) * 5);
    ctx.stroke();
  }
  if (dmg > 0.55) {
    const t = performance.now() / 900;
    for (let i = 0; i < 2; i++) {
      const phase = (t * 0.25 + i * 0.45) % 1;
      ctx.fillStyle = "rgba(70,70,70," + (1 - phase) * 0.25 + ")";
      ctx.beginPath();
      ctx.arc(-8 + i * 12, -20 - phase * 14, 3.5 + phase * 3, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.restore();
}
function updateRepairDevices(dt) {
  const allDevices = [...resources, ...aiResources].filter(
    (r) => r.type === "repair" && (r.buildRemaining || 0) <= 0 && !r.destroyed,
  );
  for (const device of allDevices) {
    const pos = getResourceWorldPos(device);
    if (!pos) continue;
    const owner = device.owner || "player";
    for (const b of beams) {
      if (
        b.owner !== owner ||
        (b.buildRemaining || 0) > 0 ||
        b.hp <= 0 ||
        performance.now() < (b.repairBlockedUntil || 0)
      )
        continue;
      const a = nodes[b.a],
        d = nodes[b.b];
      if (!a || !d) continue;
      const dist = pointSegmentDistance(pos.x, pos.y, a.x, a.y, d.x, d.y);
      if (dist > REPAIR_STATS.radius) continue;
      const factor = 0.2 + 0.8 * (1 - dist / REPAIR_STATS.radius);
      b.maxHp = getBeamMaxHp(b);
      b.hp = Math.min(b.maxHp, b.hp + REPAIR_STATS.beamRate * dt * factor);
    }
    for (const r of [...resources, ...aiResources]) {
      if (
        r.owner !== owner ||
        r.destroyed ||
        (r.buildRemaining || 0) > 0 ||
        performance.now() < (r.repairBlockedUntil || 0)
      )
        continue;
      const p = getResourceWorldPos(r);
      if (!p) continue;
      const dist = Math.hypot(pos.x - p.x, pos.y - p.y);
      if (dist > REPAIR_STATS.radius) continue;
      healObject(
        r,
        REPAIR_STATS.structureRate * dt * (0.25 + 0.75 * (1 - dist / REPAIR_STATS.radius)),
        getResourceMaxHp,
      );
    }
    for (const g of guns) {
      if (
        g.owner !== owner ||
        g.destroyed ||
        (g.buildRemaining || 0) > 0 ||
        performance.now() < (g.repairBlockedUntil || 0)
      )
        continue;
      const gp = weaponPosition(g);
      if (!gp) continue;
      const dist = Math.hypot(pos.x - gp.x, pos.y - gp.y);
      if (dist > REPAIR_STATS.radius) continue;
      healObject(
        g,
        REPAIR_STATS.structureRate * dt * (0.25 + 0.75 * (1 - dist / REPAIR_STATS.radius)),
        getGunMaxHp,
      );
    }
    // V15.60: the reactor is the only thing that can NOT be repaired (player and AI alike).
  }
}
const reactorSprite = new Image();
reactorSprite.src = "assets/img/reactorsprite.webp";
function drawReactor(core) {
  if (!core) return;
  const x = core.x,
    y = core.y,
    health = Math.max(0, core.hp / core.maxHp);
  const t = performance.now() / 1000;
  ctx.save();
  ctx.translate(x, y);
  // Heavy wooden/steel housing is centered on the original hitbox and joints.
  if (reactorSprite.complete && reactorSprite.naturalWidth) {
    ctx.drawImage(reactorSprite, -43, -39, 86, 78);
  } else {
    ctx.fillStyle = "#25313b";
    ctx.fillRect(-32, -35, 64, 70);
  }
  // Energy remains clearly visible, and its color identifies each faction.
  const pulse = 1 + 0.075 * Math.sin(t * 2.8);
  const glowColor = core.dead ? "#ff572b" : core.owner === "enemy" ? "#ff6459" : "#42e9ff";
  ctx.save();
  ctx.globalCompositeOperation = "screen";
  ctx.shadowColor = glowColor;
  ctx.shadowBlur = core.dead ? 4 : 9 + 5 * Math.sin(t * 2.8) ** 2;
  ctx.globalAlpha = core.dead ? 0.13 : 0.16 + 0.1 * Math.sin(t * 2.8) ** 2;
  ctx.fillStyle = glowColor;
  ctx.beginPath();
  ctx.arc(0, 0, 13 * pulse, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  // Thin electrical arcs stay within the central reactor window.
  if (!core.dead) {
    ctx.save();
    ctx.strokeStyle = glowColor;
    ctx.lineWidth = 0.85;
    ctx.globalAlpha = 0.25;
    for (let i = 0; i < 2; i++) {
      const phase = t * 2.5 + i * 3.1;
      const sx = Math.cos(phase) * 7,
        sy = Math.sin(phase) * 7;
      ctx.beginPath();
      ctx.moveTo(sx, sy);
      ctx.lineTo(sx + Math.sin(phase * 2) * 3, sy - 3);
      ctx.lineTo(sx + Math.cos(phase * 3) * 5, sy - 6);
      ctx.stroke();
    }
    ctx.restore();
  }
  // Preserve readable reactor health bar above the new housing.
  ctx.fillStyle = "#101c24";
  ctx.fillRect(-32, -46, 64, 7);
  ctx.fillStyle = health > 0.5 ? "#50e2a0" : health > 0.25 ? "#ffc15b" : "#ff5757";
  ctx.fillRect(-31, -45, 62 * health, 5);
  ctx.restore();
}
function starterFortAt(x, owner) {
  // Identical symmetrical blueprint for both players, including reactor.
  const f = floor();
  // All above-ground joints sit on the same 40-unit world grid used for building.
  // Foundation anchors must remain on the actual ground, which is not a grid row.
  const pts = [
    [x - 160, f],
    [x - 80, f],
    [x, f],
    [x + 80, f],
    [x + 160, f],
    [x - 160, 960],
    [x - 80, 960],
    [x, 960],
    [x + 80, 960],
    [x + 160, 960],
    [x - 80, 880],
    [x, 800],
    [x + 80, 880],
    [x, 880],
  ];
  const ids = pts.map(([px, py]) => node(px, py, py >= f - 1));
  const mirror = [4, 3, 2, 1, 0, 9, 8, 7, 6, 5, 12, 11, 10, 13];
  const half = [
    [0, 1],
    [1, 2],
    [0, 5],
    [5, 6],
    [6, 7],
    [0, 6],
    [1, 6],
    [1, 7],
    [2, 7],
    [5, 10],
    [6, 10],
    [7, 13],
    [13, 11],
    [10, 11],
    [6, 11],
  ];
  const seen = new Set(),
    edges = [];
  const add = (a, b) => {
    const k = [Math.min(a, b), Math.max(a, b)].join("-");
    if (!seen.has(k)) {
      seen.add(k);
      edges.push([a, b]);
    }
  };
  half.forEach(([a, b]) => {
    add(a, b);
    add(mirror[a], mirror[b]);
  });
  const oldKind = buildKind,
    oldEnemy = buildingEnemy;
  buildKind = "front";
  buildingEnemy = owner === "enemy";
  initializingFort = true;
  try {
    edges.forEach(([a, b]) => beam(ids[a], ids[b], true));
  } finally {
    initializingFort = false;
    buildingEnemy = oldEnemy;
    buildKind = oldKind;
  }
  const core = reactor(x, f - 100, owner);
  if (owner === "enemy") enemyCore = core;
  else playerCore = core;
  return core;
}
function starterFort() {
  starterFortAt(320, "player");
  updateStructuralSupport();
  document.getElementById("count").textContent = beams.length;
}
function reset() {
  fwMatchTime = 0;
  fwLastShots = [];
  fwFlakRounds = [];
  fwFlakBursts = [];
  chooseBattlefield();
  unlockedWeapons = new Set(cheatMode ? Object.keys(WEAPONS) : ["mg", "cannon"]);
  researchJob = null;
  aiUnlockedWeapons = new Set(["mg", "cannon"]);
  aiResearchJob = null;
  refreshResearchUI();
  selectedAimGun = null;
  selectedAimGuns.clear();
  fwWeaponBanks.forEach((bank) => (bank.length = 0));
  fwActiveWeaponBank = -1;
  aimTarget = null;
  if (resultTimeout) clearTimeout(resultTimeout);
  resultTimeout = null;
  reactorBlast = null;
  document.getElementById("resultOverlay").hidden = true;
  hideBeamMenu();
  zoom = 1;
  camX = Math.round(W * 0.5 - 320);
  camY = Math.round(H * 0.78 - floor());
  document.getElementById("zoomlevel").textContent = "100%";
  metal = cheatMode ? CHEAT_SUPPLY : 105;
  energy = cheatMode ? CHEAT_SUPPLY : 35;
  resources = [];
  aiResources = [];
  enemyOn = false;
  enemyTimer = 0;
  resourceTimer = 0;
  enemyCore = null;
  playerCore = null;
  gameOver = false;
  enemyPlan = [];
  enemyBuildTimer = 0;
  enemyReady = false;
  enemyStarted = false;
  paused = false;
  fwSetPauseOrb(false);
  hud();
  nodes = [];
  beams = [];
  guns = [];
  nextBeamId = 1;
  shots = [];
  particles = [];
  hits = 0;
  drag = null;
  fwGuestHits = 0;
  document.getElementById("hits").textContent = 0;
  document.getElementById("count").textContent = 0;
  setMode("build");
  starterFort();
  startEnemy();
}
document.getElementById("resultRestart").addEventListener("click", () => {
  reset();
  paused = true;
  document.getElementById("difficultyOverlay").hidden = false;
});
function demo() {
  reset();
  document.getElementById("tip").textContent =
    "Startfestung: Fundament, Dreiecksverstrebungen und geschützter Innenraum. Baue von hier aus weiter.";
}
function restoreBuildPositions() {
  for (const n of nodes) {
    n.x = n.homeX;
    n.y = Math.min(n.homeY, floor());
    n.px = n.homeX;
    n.py = n.y;
  }
  shots = [];
  particles = [];
  acc = 0;
  drag = null;
}
function setMode(m) {
  hideBeamMenu();
  placementCursor = null;
  mode = m;
  document.getElementById("aimFire").hidden = m !== "shoot";
  fwRefreshWeaponBanks();
  buttons.forEach((id) => document.getElementById(id).classList.toggle("active", id === m));
  document.getElementById("tip").textContent =
    m === "build"
      ? "Bauen: Ziehe von einem Verbindungspunkt deiner Festung aus. Freie Balken sind nicht erlaubt."
      : m === "erase"
        ? "Radierer: Tippe auf einen Punkt oder Balken, um ihn zu löschen."
        : m === "repair"
          ? "Reparieren: Tippe beschädigte eigene Balken an (8 Eisen)."
          : m === "pan"
            ? "Kamera: Ein Finger verschiebt. Zwei Finger verschieben und zoomen."
            : m === "test"
              ? "Physik läuft immer. Unfertige Streben bleiben bis zur Verstrebung stabil."
              : m === "placegun"
                ? "Waffe: Auf waagerechten Balken bauen; Vorderwände blockieren Waffen. Ausgewählt: " +
                  WEAPONS[selectedWeapon].name
                : m === "placeresource"
                  ? "Gebäude: Auf waagerechten Balken bauen; Vorderwände blockieren Waffen."
                  : "Feuer: Mehrere Waffen antippen (erneut tippen = abwählen), Ziel ziehen und FEUER drücken.";
}
buttons.forEach((id) => (document.getElementById(id).onclick = () => setMode(id)));
document.getElementById("test").onclick = () => {
  paused = !paused;
  fwSetPauseOrb(paused);
  document.getElementById("test").classList.toggle("active", paused);
  hud();
};
document.getElementById("cheatButton").onclick = () => {
  cheatMode = !cheatMode;
  document.getElementById("cheatButton").classList.toggle("active", cheatMode);
  document.getElementById("cheatButton").setAttribute("aria-pressed", String(cheatMode));
  if (cheatMode) {
    metal = CHEAT_SUPPLY;
    energy = CHEAT_SUPPLY;
    unlockedWeapons = new Set(Object.keys(WEAPONS));
    researchJob = null;
    document.getElementById("tip").textContent =
      "⚡ TESTMODUS AKTIV: Alle Waffen erforscht, Werkstatt nicht nötig, Eisen & Energie unbegrenzt.";
  } else {
    metal = Math.min(999, metal);
    energy = Math.min(999, energy);
    document.getElementById("tip").textContent =
      "Testmodus aus. Bereits erforschte Waffen bleiben verfügbar.";
  }
  refreshResearchUI();
  hud();
};
document.getElementById("zoomout").onclick = () => setZoom(zoom / 1.25);
document.getElementById("zoomin").onclick = () => setZoom(zoom * 1.25);
document.getElementById("pan").onclick = () => setMode("pan");
document.getElementById("menutoggle").onclick = () => {
  const m = document.getElementById("menu");
  m.hidden = !m.hidden;
};
document.querySelectorAll("#menu button").forEach((b) =>
  b.addEventListener("click", () => {
    document.getElementById("menu").hidden = true;
  }),
);
document.getElementById("undo").onclick = undo;
document.getElementById("reset").onclick = reset;
document.getElementById("demo").onclick = demo;
document.getElementById("enemy").onclick = () => {
  if (!enemyOn) {
    startEnemy();
  } else {
    enemyOn = false;
    document.getElementById("enemy").classList.remove("active");
    document.getElementById("tip").textContent = "Gegner pausiert.";
  }
};
document.getElementById("doorMode").onclick = () => {
  doorMode = doorMode === "auto" ? "manual" : "auto";
  document.getElementById("doorMode").textContent =
    "🛡 Türen: " + (doorMode === "auto" ? "Automatik" : "Manuell");
  document.getElementById("tip").textContent =
    doorMode === "auto"
      ? "Türen öffnen automatisch beim Schießen."
      : "Türen jetzt über das Menü öffnen und schließen.";
};
document.getElementById("doorToggle").onclick = () => {
  doorsForcedOpen = !doorsForcedOpen;
  document.getElementById("doorToggle").textContent = doorsForcedOpen
    ? "🚪 Türen schließen"
    : "🚪 Türen öffnen";
};
document.getElementById("save").onclick = () => {
  localStorage.setItem(
    "fortress_v39",
    JSON.stringify({
      nodes,
      beams,
      guns,
      resources,
      metal,
      energy,
      unlockedWeapons: [...unlockedWeapons],
      researchJob,
    }),
  );
  document.getElementById("tip").textContent = "Bauplan mit Waffen und Türen lokal gespeichert.";
};
document.getElementById("load").onclick = () => {
  try {
    let d = JSON.parse(localStorage.getItem("fortress_v39"));
    if (!d) throw Error();
    reset();
    nodes = d.nodes;
    beams = d.beams;
    beams.forEach((b) => {
      if (b.id == null) b.id = nextBeamId++;
    });
    nextBeamId = Math.max(nextBeamId, ...beams.map((b) => b.id + 1), 1);
    beams.forEach((b) => {
      b.maxHp = getBeamMaxHp(b);
      if (b.hp == null) b.hp = b.maxHp;
    });
    resources = (d.resources || [])
      .filter((r) => beams.some((b) => b.id === r.beamId))
      .map((r) => {
        r.maxHp = getResourceMaxHp(r);
        if (r.hp == null) r.hp = r.maxHp;
        return r;
      });
    guns = (d.guns || []).filter((g) => g.beamId != null || nodes[g.node]);
    guns.forEach((g) => {
      g.maxHp = getGunMaxHp(g);
      if (g.hp == null) g.hp = g.maxHp;
    });
    for (const n of nodes) {
      n.y = Math.min(n.y, floor());
      n.py = Math.min(n.py ?? n.y, floor());
      n.homeY = Math.min(n.homeY ?? n.y, floor());
      if (n.fixed || n.homeY >= floor() - 9) {
        n.fixed = true;
        n.y = floor();
        n.py = floor();
        n.homeY = floor();
      }
      if (n.homeX === undefined) n.homeX = n.x;
      if (n.homeY === undefined) n.homeY = n.y;
      if (n.provisional === undefined) n.provisional = !n.fixed && !n.supported;
    }
    metal = d.metal;
    energy = d.energy;
    unlockedWeapons = new Set([
      "mg",
      "cannon",
      ...(d.unlockedWeapons || []),
      ...guns.filter((g) => g.owner === "player").map((g) => g.type),
    ]);
    researchJob = d.researchJob || null;
    refreshResearchUI();
    setMode("build");
    hud();
    fwUpdateBeamCount();
  } catch (e) {
    document.getElementById("tip").textContent = "Noch kein gespeicherter Bauplan vorhanden.";
  }
};
function point(e) {
  let r = c.getBoundingClientRect();
  return screenToWorld(e.clientX - r.left, e.clientY - r.top);
}
function rawPoint(e) {
  let r = c.getBoundingClientRect();
  return { x: e.clientX - r.left, y: e.clientY - r.top };
} // Zwei Finger steuern die Kamera in jedem Werkzeugmodus; ein Finger bedient das Werkzeug.
let selectedBeamId = null;
const beamMenu = document.getElementById("beamMenu");
// V15.55: Opening this menu from a canvas pointer-up must NOT activate a
// component under that same finger. Require a *fresh pointer-down* on a menu
// choice (or a focused keyboard activation) before accepting its click.
let fwBeamChoicePress = null;
beamMenu.addEventListener(
  "pointerdown",
  (event) => {
    const button = event.target.closest(".fwBeamChoice");
    if (!button || beamMenu.hidden || selectedBeamId == null) return;
    fwBeamChoicePress = { buttonId: button.id, beamId: selectedBeamId, at: performance.now() };
  },
  true,
);
beamMenu.addEventListener(
  "pointercancel",
  () => {
    fwBeamChoicePress = null;
  },
  true,
);
beamMenu.addEventListener(
  "click",
  (event) => {
    const button = event.target.closest(".fwBeamChoice");
    if (!button) return;
    const press = fwBeamChoicePress;
    const freshPress =
      !!press &&
      press.buttonId === button.id &&
      press.beamId === selectedBeamId &&
      performance.now() - press.at < 1800;
    const keyboard = event.detail === 0 && document.activeElement === button;
    fwBeamChoicePress = null;
    if (beamMenu.hidden || selectedBeamId == null || (!freshPress && !keyboard)) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  },
  true,
);
function hideBeamMenu() {
  beamMenu.hidden = true;
  selectedBeamId = null;
  fwBeamChoicePress = null;
}
function showBeamMenu(b, screen) {
  fwBeamChoicePress = null; // any earlier canvas press is never a menu selection
  selectedBeamId = b.id;
  beamMenu.hidden = false;
  const back = !!b.background,
    door = !!b.armorDoor,
    armor = !!b.armorWall;
  const states = { beamBack: back, beamFront: !back && !door && !armor, beamDoor: door, beamArmor: armor };
  for (const [id, enabled] of Object.entries(states)) {
    const button = document.getElementById(id);
    button.classList.toggle("active", enabled);
    button.setAttribute("aria-pressed", String(enabled));
    // V15.60: show what this conversion costs right in the menu
    const price = id === "beamDoor" || id === "beamArmor" ? FW_ARMOR_UPGRADE_COST : 0;
    let costEl = button.querySelector(".fwBeamChoiceCost");
    if (!costEl) {
      costEl = document.createElement("span");
      costEl.className = "fwBeamChoiceCost";
      button.querySelector(".fwBeamChoiceText")?.appendChild(costEl);
    }
    const cantAfford = !enabled && price > 0 && metal < price;
    costEl.textContent = enabled ? "✓ aktiv" : price ? "⚙ " + price + " Eisen" : "kostenlos";
    button.classList.toggle("fwCantAfford", cantAfford);
    button.setAttribute(
      "aria-label",
      button.querySelector(".fwBeamChoiceName").textContent + ", " + costEl.textContent + (cantAfford ? ", zu wenig Eisen" : ""),
    );
  }
  // Position the real, measured popup (not an obsolete fixed 205px guess).
  const gap = 8;
  const rect = beamMenu.getBoundingClientRect();
  const popupW = rect.width,
    popupH = rect.height;
  const vw = window.innerWidth,
    vh = window.innerHeight;
  const hudBottom = document.getElementById("hud")?.getBoundingClientRect().bottom || 0;
  const pauseRect = document.getElementById("test")?.getBoundingClientRect();
  // On narrow screens the menu must remain below the pause orb.
  const safeTop = Math.max(8, hudBottom + gap, vw <= 650 && pauseRect ? pauseRect.bottom + gap : 0);
  const dockTop = document.getElementById("inventoryTabs")?.getBoundingClientRect().top || vh;
  const safeBottom = Math.min(vh - gap, dockTop - gap);
  const maxTop = Math.max(safeTop, safeBottom - popupH);
  const left = Math.max(gap, Math.min(vw - popupW - gap, screen.x - popupW / 2));
  const top = Math.max(safeTop, Math.min(maxTop, screen.y - popupH / 2));
  beamMenu.style.left = Math.round(left) + "px";
  beamMenu.style.top = Math.round(top) + "px";
}
document.getElementById("beamClose").onclick = hideBeamMenu;
// V15.59: Conversions are no longer free and never heal the beam.
// Upgrading to door/armor costs the same as for the AI (48 Eisen + build time);
// the damage ratio is preserved when the maximum HP changes.
function fwSetBeamKind(b, kind) {
  const tip = document.getElementById("tip");
  if (!b || b.owner !== "player") return;
  const cur = b.armorDoor ? "door" : b.armorWall ? "armor" : b.background ? "back" : "front";
  if (cur === kind) {
    tip.textContent = "Dieser Balken ist bereits so eingestellt.";
    return;
  }
  const upgrade = kind === "door" || kind === "armor";
  if (upgrade && metal < FW_ARMOR_UPGRADE_COST) {
    tip.textContent = "Zu wenig Eisen: Umbau kostet " + FW_ARMOR_UPGRADE_COST + ".";
    return;
  }
  const oldMax = getBeamMaxHp(b),
    ratio = Math.max(0, Math.min(1, b.hp / oldMax));
  const newMax = kind === "door" ? 220 : kind === "armor" ? 256 : 100;
  b.background = kind === "back";
  b.armorDoor = kind === "door";
  b.armorWall = kind === "armor";
  b.doorTimer = 0;
  b.doorProgress = 0;
  b.maxHp = newMax;
  b.hp = Math.max(1, ratio * newMax);
  if (upgrade) {
    metal -= FW_ARMOR_UPGRADE_COST;
    b.paid = (b.paid || 0) + FW_ARMOR_UPGRADE_COST;
    b.buildRemaining = BUILD_TIMES[kind];
    b.buildTotal = BUILD_TIMES[kind];
    hud();
  }
  tip.textContent =
    kind === "door"
      ? "Panzertür im Bau (−" +
        FW_ARMOR_UPGRADE_COST +
        " Eisen): öffnet automatisch beim Schuss einer nahen eigenen Waffe."
      : kind === "armor"
        ? "Panzerwand im Bau (−" +
          FW_ARMOR_UPGRADE_COST +
          " Eisen): robuste, dauerhaft geschlossene Stahlpanzerung."
        : kind === "back"
          ? "Hintergrundstrebe: Geschosse fliegen hindurch."
          : "Vordergrundstrebe: Geschosse treffen wieder.";
}
for (const [id, kind] of [
  ["beamBack", "back"],
  ["beamFront", "front"],
  ["beamDoor", "door"],
  ["beamArmor", "armor"],
])
  document.getElementById(id).onclick = () => {
    fwSetBeamKind(
      beams.find((b) => b.id === selectedBeamId),
      kind,
    );
    hideBeamMenu();
  };
const touches = new Map();
let gesture = null,
  single = null;
function touchMetrics() {
  const a = [...touches.values()];
  const x = (a[0].x + a[1].x) / 2,
    y = (a[0].y + a[1].y) / 2;
  return { x, y, dist: Math.max(1, Math.hypot(a[1].x - a[0].x, a[1].y - a[0].y)) };
}
function beginGesture() {
  hideBeamMenu();
  const m = touchMetrics();
  gesture = { dist: m.dist, zoom, worldX: (m.x - camX) / zoom, worldY: (m.y - camY) / zoom };
  drag = null;
  panStart = null;
  single = null;
}
for (const card of document.querySelectorAll(".buildCard"))
  card.addEventListener("click", () => {
    buildKind = card.dataset.build;
    document.querySelectorAll(".buildCard").forEach((x) => x.classList.toggle("active", x === card));
    setMode("build");
    document.getElementById("tip").textContent =
      buildKind === "door"
        ? "Panzertür (60 Eisen): Balken ziehen – oder eine vorhandene Wand antippen und umbauen (48). Öffnet beim Schuss einer nahen eigenen Waffe."
        : buildKind === "armor"
          ? "Panzerwand (60 Eisen): Balken ziehen – oder eine vorhandene Wand antippen und umbauen (48). Hält mehr Schaden aus."
          : buildKind === "back"
            ? "Hintergrundstrebe: Geschosse passieren sie."
            : "Vordergrundstrebe: blockiert Geschosse.";
  });

function showInventoryTab(which) {
  const building = which === "build";
  document.getElementById("buildDock").hidden = !building;
  document.getElementById("weaponDock").hidden = which !== "weapons";
  document.getElementById("resourceDock").hidden = which !== "resources";
  document.getElementById("researchDock").hidden = which !== "research";
  document.querySelectorAll("#inventoryTabs button").forEach((btn) => {
    const active = btn.dataset.tab === which;
    btn.classList.toggle("active", active);
    btn.setAttribute("aria-selected", String(active));
  });
  // Switching back to construction restores one-finger building mode.
  if (building) {
    setMode("build");
  } else {
    hideBeamMenu();
    document.getElementById("tip").textContent =
      which === "research"
        ? "Wähle eine Waffe zur Erforschung. Immer nur eine Forschung gleichzeitig."
        : which === "resources"
          ? "Mine oder Windrad auf einen eigenen Balken ziehen. Nur Gebäude erzeugen Eisen und Energie."
          : "Waffe aus dem Arsenal auf einen eigenen Balken ziehen.";
  }
}
document
  .querySelectorAll("#inventoryTabs button")
  .forEach((btn) => btn.addEventListener("click", () => showInventoryTab(btn.dataset.tab)));
// Magnetic 40-unit grid: existing joints win, otherwise snap to nearby grid lines.
const BUILD_GRID = 40;
function snapBuildPoint(x, y, exclude = -1) {
  y = Math.min(y, floor());
  // Keep ground-level drags on the actual ground, even if the finger is slightly above it.
  const groundIntent = y >= floor() - Math.max(13, Math.min(26, 20 / zoom));
  if (groundIntent) y = floor();
  const jointRadius = Math.max(14, Math.min(29, 23 / zoom));
  let best = null,
    dist = jointRadius;
  nodes.forEach((n, i) => {
    if (i === exclude) return;
    if (groundIntent && Math.abs(n.y - floor()) > 2) return;
    const d = Math.hypot(n.x - x, n.y - y);
    if (d < dist) {
      best = { x: n.x, y: n.y, index: i };
      dist = d;
    }
  });
  if (best) return best;
  const threshold = Math.max(5, Math.min(13, 11 / zoom));
  const gx = Math.round(x / BUILD_GRID) * BUILD_GRID,
    gy = Math.round(y / BUILD_GRID) * BUILD_GRID;
  if (Math.abs(x - gx) <= threshold) x = gx;
  if (Math.abs(y - gy) <= threshold) y = gy;
  if (y >= floor() - 7) y = floor();
  return { x, y, index: -1 };
}
function getBuildNode(x, y, exclude = -1) {
  y = Math.min(y, floor());
  const onGround = y >= floor() - Math.max(13, Math.min(26, 20 / zoom));
  if (onGround) y = floor();
  // Reconnect to existing joints, including those on moving beams.
  // Keep a small inner radius to prevent accidental zero-length beams.
  const radius = Math.max(16, Math.min(29, 23 / zoom));
  let best = -1,
    dist = radius;
  nodes.forEach((n, i) => {
    if (i === exclude) return;
    if (onGround && Math.abs(n.y - floor()) > 2) return;
    const d = Math.hypot(n.x - x, n.y - y);
    if (d < dist) {
      best = i;
      dist = d;
    }
  });
  return best >= 0 ? best : node(x, y, onGround);
}
let selectedAimGun = null,
  aimTarget = null,
  selectedAimGuns = new Set();
let selectedResource = "mine";
function chosenGun() {
  return guns.find((g) => g === selectedAimGun && g.owner === "player" && weaponPosition(g)) || null;
}
function selectedGuns() {
  return [...selectedAimGuns].filter(
    (g) => guns.includes(g) && g.owner === "player" && g.type !== "flak" && weaponPosition(g),
  );
}
function selectAimGun(wx, wy) {
  let found = null,
    dist = Math.max(42, 55 / zoom);
  for (const g of guns) {
    if (g.owner !== "player" || g.type === "flak") continue;
    const p = weaponPosition(g);
    if (!p) continue;
    const d = Math.hypot(p.x - wx, p.y - wy);
    if (d < dist) {
      dist = d;
      found = g;
    }
  }
  if (!found) return false;
  fwActiveWeaponBank = -1;
  fwRefreshWeaponBanks();
  if (selectedAimGuns.has(found)) {
    selectedAimGuns.delete(found);
    if (selectedAimGun === found) selectedAimGun = selectedGuns()[0] || null;
  } else {
    if (selectedGuns().length >= 3) {
      document.getElementById("tip").textContent =
        "Maximal 3 Waffen gleichzeitig auswählbar. Erst eine andere Waffe abwählen.";
      return true;
    }
    selectedAimGuns.add(found);
    selectedAimGun = found;
  }
  const p = weaponPosition(found);
  // V15.60: each weapon remembers where it last aimed.
  if (found.lastAim && selectedAimGuns.has(found)) aimTarget = limitAimToRange(found.lastAim.x, found.lastAim.y);
  else if (!aimTarget) aimTarget = limitAimToRange(p.x + 500, p.y);
  document.getElementById("tip").textContent =
    (selectedGuns().length === 1 ? "1 Waffe" : selectedGuns().length + " Waffen") +
    " ausgewählt. Weitere antippen oder Ziel ziehen und FEUER drücken.";
  return true;
}

// V15.03: Three quick-select banks of up to three existing player weapons.
// The banks store object references; destroyed weapons are never restored.
const fwWeaponBanks = [[], [], []];
let fwActiveWeaponBank = -1;
function fwValidBankWeapons(bank) {
  return bank.filter(
    (g) => guns.includes(g) && g.owner === "player" && g.type !== "flak" && weaponPosition(g) && !g.dead,
  );
}
function fwRefreshWeaponBanks() {
  const bar = document.getElementById("fwWeaponShortcuts");
  if (!bar) return;
  bar.classList.toggle("visible", mode === "shoot");
  for (let i = 0; i < 3; i++) {
    const valid = fwValidBankWeapons(fwWeaponBanks[i]);
    const btn = bar.querySelector('.fwQuickRecall[data-slot="' + i + '"]');
    if (btn) {
      btn.textContent = i + 1 + " · " + (valid.length || "–");
      btn.classList.toggle("current", i === fwActiveWeaponBank);
    }
  }
}
function fwSaveWeaponBank(i) {
  const group = selectedGuns().slice(0, 3);
  if (!group.length) {
    document.getElementById("tip").textContent = "Erst 1–3 eigene Waffen auswählen, dann auf 💾 tippen.";
    return;
  }
  fwWeaponBanks[i] = group.slice();
  fwActiveWeaponBank = i;
  fwRefreshWeaponBanks();
  document.getElementById("tip").textContent =
    "Waffengruppe " + (i + 1) + " gespeichert: " + group.length + " Waffen.";
}
function fwRecallWeaponBank(i) {
  const group = fwValidBankWeapons(fwWeaponBanks[i]);
  if (!group.length) {
    document.getElementById("tip").textContent =
      "Gruppe " + (i + 1) + " ist leer oder ihre Waffen wurden zerstört.";
    fwRefreshWeaponBanks();
    return;
  }
  selectedAimGuns.clear();
  for (const gun of group.slice(0, 3)) selectedAimGuns.add(gun);
  selectedAimGun = group[0];
  fwActiveWeaponBank = i;
  if (aimTarget) updateAimTarget(aimTarget.x, aimTarget.y);
  fwRefreshWeaponBanks();
  document.getElementById("tip").textContent =
    "Gruppe " + (i + 1) + " aktiv: " + group.length + " Waffen. Ziel setzen und FEUER drücken.";
}
document
  .querySelectorAll("#fwWeaponShortcuts .fwQuickSave")
  .forEach((btn) => btn.addEventListener("click", () => fwSaveWeaponBank(Number(btn.dataset.slot))));
document
  .querySelectorAll("#fwWeaponShortcuts .fwQuickRecall")
  .forEach((btn) => btn.addEventListener("click", () => fwRecallWeaponBank(Number(btn.dataset.slot))));
// The projectile, smoke and trajectory preview share the muzzle of the
// articulated weapon sprite. Coordinates are in the 384px transparent art.
const WEAPON_MUZZLE_PIXELS = {
  cannon: [378, 58],
  mg: [363, 68],
  rocket: [371, 113],
  autocannon: [383, 66],
  heavy: [383, 57],
  sniper: [380, 39],
  mortar: [340, 99],
};
// V15.53: Full-size calibrated upper mortar, with a greater upward aim range.
// Canvas angles are negative when pointing upward; the LOWER angle bound
// is the upper physical aiming limit, not maxAngle.
// Image-space pivot and muzzle were measured on the complete user-supplied PNG.
// Base pivot is an anchor ABOVE the fixed carriage wheel, corresponding to
// the movable upper screw indicated in the user's drawing.
const FW_MORTAR_CONFIG = Object.freeze({
  basePivotX: 190,
  basePivotY: 0,
  spritePivotX: 594,
  spritePivotY: 714,
  muzzleX: 1320,
  muzzleY: 155,
  minAngle: -1.43,
  maxAngle: 0.9,
  restAngle: (-27 * Math.PI) / 180,
  artScale: 0.215,
  baseX: -41,
  baseY: -47,
});
function fwMortarVisualRotation(angle) {
  const c = FW_MORTAR_CONFIG;
  const a = Math.max(c.minAngle, Math.min(c.maxAngle, Number.isFinite(angle) ? angle : c.restAngle));
  const nativeAngle = Math.atan2(c.muzzleY - c.spritePivotY, c.muzzleX - c.spritePivotX);
  return a - nativeAngle;
}
// All mortar transforms (drawing, muzzle position, editor dragging) use the
// same stationary screw point and the same barrel rotation.
// V14.28: Der Geschossursprung benutzt exakt dieselben Zeichen-Transforms
// wie drawLayeredWeapon: Maßstab, 8-Einheiten-Absenkung und Laufrotation.
function weaponMuzzle(g, angle) {
  const n = g.visualMount || weaponPosition(g);
  if (!n) return null;
  const type = g.type || "cannon";
  const tip = WEAPON_MUZZLE_PIXELS[type] || WEAPON_MUZZLE_PIXELS.cannon;
  if (type === "mortar") {
    // V15.53: Muzzle and barrel use the same fixed pivot and angle; updated upward limit.
    const c = FW_MORTAR_CONFIG;
    const left = fwFacesLeft(g.owner);
    const visualAngle = !Number.isFinite(angle)
      ? c.restAngle
      : !left
        ? angle
        : window.FWOnlineMatch
          ? fwMirrorAngle(angle)
          : c.restAngle;
    const delta = fwMortarVisualRotation(visualAngle);
    const barrelScale = (384 * c.artScale) / 1536;
    const pivotX = c.baseX + c.basePivotX * c.artScale + (window.__fwMortarCalibration?.x ?? 2.5);
    const pivotY = c.baseY + c.basePivotY * c.artScale + (window.__fwMortarCalibration?.y ?? 1);
    const mx = (c.muzzleX - c.spritePivotX) * barrelScale;
    const my = (c.muzzleY - c.spritePivotY) * barrelScale;
    const facing = left ? -1 : 1;
    const rx = mx * Math.cos(delta) - my * Math.sin(delta);
    const ry = mx * Math.sin(delta) + my * Math.cos(delta);
    return { x: n.x + facing * (pivotX + rx) * 0.8075, y: n.y + (pivotY + ry + 8) * 0.8075 };
  }
  const artScale = 0.215,
    pivotX = 121,
    pivotY = 150,
    tx = -26,
    ty = -67;
  const px = tx + pivotX * artScale,
    py = ty + pivotY * artScale;
  const enemy = fwFacesLeft(g.owner);
  const rawAngle = Number.isFinite(angle) ? angle : 0;
  // AI guns keep their barrel parked; human players (also online) aim theirs.
  const target = !enemy ? rawAngle : window.FWOnlineMatch ? fwMirrorAngle(rawAngle) : 0;
  const delta = Math.max(-0.72, Math.min(0.22, target)) - -0.42;
  const dx = (tip[0] - pivotX) * artScale,
    dy = (tip[1] - pivotY) * artScale;
  const rx = dx * Math.cos(delta) - dy * Math.sin(delta);
  const ry = dx * Math.sin(delta) + dy * Math.cos(delta);
  const visualScale = ["cannon", "heavy", "autocannon", "sniper", "mortar"].includes(type) ? 0.8075 : 0.85;
  const facing = enemy ? -1 : 1;
  return { x: n.x + facing * (px + rx) * visualScale, y: n.y + (py + ry + 8) * visualScale };
}
function calculateLaunchAngle(g, tx, ty) {
  const n = weaponPosition(g),
    spec = WEAPONS[g.type || "cannon"];
  if (!n || !spec) return 0;
  const speed = spec.speed,
    grav = GRAV * 0.45;
  // Solve against this weapon's real, angle-dependent muzzle position.
  // This is the same continuous parabola used by the projectile update.
  let angle = Math.atan2(ty - n.y, tx - n.x);
  for (let i = 0; i < 24; i++) {
    const m = weaponMuzzle(g, angle);
    if (!m) break;
    const dx = tx - m.x,
      dy = ty - m.y;
    const cos = Math.cos(angle);
    const time = Math.abs(cos) > 1e-5 ? dx / (speed * cos) : -1;
    if (time <= 0 || !Number.isFinite(time)) break;
    const predicted = m.y + speed * Math.sin(angle) * time + 0.5 * grav * time * time;
    const error = predicted - ty;
    if (Math.abs(error) < 0.001) break;
    // Numerical derivative includes the muzzle rotation/clamp behavior.
    const delta = 0.0001,
      m2 = weaponMuzzle(g, angle + delta);
    const cs = Math.cos(angle + delta);
    const t2 = m2 && Math.abs(cs) > 1e-5 ? (tx - m2.x) / (speed * cs) : -1;
    if (t2 <= 0 || !Number.isFinite(t2)) break;
    const predicted2 = m2.y + speed * Math.sin(angle + delta) * t2 + 0.5 * grav * t2 * t2;
    const slope = (predicted2 - predicted) / delta;
    if (!Number.isFinite(slope) || Math.abs(slope) < 0.001) break;
    angle -= Math.max(-0.15, Math.min(0.15, error / slope));
  }
  return angle;
}
// V15.05: One compact, consistent targeting circle for every weapon.
// Match the existing small circle of the light cannon, regardless of projectile speed.
// Both the drawn marker and touch aim limiter use this same radius.
const AIM_RANGE_SCALE = 0.3;
const AIM_UNIFORM_RADIUS = ((780 * 780) / (GRAV * 0.45)) * AIM_RANGE_SCALE; // Keep the compact aiming display from V15.05
function firingRangeRadius(g) {
  return g && WEAPONS[g.type || "cannon"] ? AIM_UNIFORM_RADIUS : 0;
}
function limitAimToRange(wx, wy) {
  const chosen = chosenGun() || selectedGuns()[0];
  if (!chosen) return { x: wx, y: wy };
  const p = weaponPosition(chosen),
    radius = firingRangeRadius(chosen);
  if (!p || !(radius > 0)) return { x: wx, y: wy };
  const dx = wx - p.x,
    dy = wy - p.y,
    d = Math.hypot(dx, dy);
  return d > radius ? { x: p.x + (dx / d) * radius, y: p.y + (dy / d) * radius } : { x: wx, y: wy };
}
// V15.11: The dashed range circle is an aiming guide, never a collider.
// Pointing at a physical surface targets that surface directly. Pointing at
// empty air uses the reference gun's natural ballistic ground intersection as
// a shared impact position for ALL selected guns (each has its own muzzle).
function fwReticleOnSolidSurface(target) {
  if (target.y >= floor() - 10) return true;
  for (const b of beams) {
    if (b.hp <= 0 || b.background || (b.buildRemaining || 0) > 0) continue;
    const a = nodes[b.a],
      d = nodes[b.b];
    if (!a || !d) continue;
    const vx = d.x - a.x,
      vy = d.y - a.y;
    const u = Math.max(
      0,
      Math.min(1, ((target.x - a.x) * vx + (target.y - a.y) * vy) / (vx * vx + vy * vy || 1)),
    );
    if (Math.hypot(target.x - (a.x + u * vx), target.y - (a.y + u * vy)) <= 12) return true;
  }
  for (const g of guns) {
    const p = weaponPosition(g);
    if (p && Math.abs(p.x - target.x) <= 21 && Math.abs(p.y - target.y) <= 14) return true;
  }
  for (const core of [playerCore, enemyCore]) {
    if (core && !core.dead && Math.abs(core.x - target.x) <= 22 && Math.abs(core.y - target.y) <= 45)
      return true;
  }
  return false;
}
function fwSharedImpactTarget() {
  if (!aimTarget) return null;
  // V15.53: With a mortar selected, the yellow crosshair is the real target,
  // including in open sky. Do NOT silently replace it with a ground hit point.
  // Multiple selected guns share this same point for synchronized fire.
  if (selectedGuns().some((g) => g.type === "mortar")) return { x: aimTarget.x, y: aimTarget.y };
  if (fwReticleOnSolidSurface(aimTarget)) return { x: aimTarget.x, y: aimTarget.y };
  const reference = chosenGun() || selectedGuns()[0];
  if (!reference) return { x: aimTarget.x, y: aimTarget.y };
  const angle = calculateLaunchAngle(reference, aimTarget.x, aimTarget.y);
  const muzzle = weaponMuzzle(reference, angle),
    spec = WEAPONS[reference.type || "cannon"];
  if (!muzzle || !spec) return { x: aimTarget.x, y: aimTarget.y };
  const grav = GRAV * 0.45,
    vy = Math.sin(angle) * spec.speed,
    vx = Math.cos(angle) * spec.speed;
  const disc = vy * vy + 2 * grav * (floor() - muzzle.y);
  if (disc < 0) return { x: aimTarget.x, y: aimTarget.y };
  const t = (-vy + Math.sqrt(disc)) / grav;
  if (!Number.isFinite(t) || t <= 0) return { x: aimTarget.x, y: aimTarget.y };
  return { x: Math.max(0, Math.min(WORLD_W, muzzle.x + vx * t)), y: floor() };
}
function updateAimTarget(wx, wy) {
  if (!selectedGuns().length) return;
  aimTarget = limitAimToRange(wx, wy);
  const target = fwSharedImpactTarget();
  if (target) for (const g of selectedGuns()) g.angle = calculateLaunchAngle(g, target.x, target.y);
}
let playerVolleySerial = 0,
  playerVolleyPreparing = false;
// V14.32: Collect every gun's own armor doors BEFORE committing any shot.
// The old code only opened doors of shots that fireGun had already accepted.
function volleyDoorPlan(g, tx, ty) {
  const spec = WEAPONS[g.type || "cannon"];
  const angle = calculateLaunchAngle(g, tx, ty),
    m = weaponMuzzle(g, angle);
  if (!m) return null;
  const vx = Math.cos(angle) * spec.speed,
    vy = Math.sin(angle) * spec.speed;
  const candidate = { x: m.x, y: m.y, vx, vy, r: spec.ball };
  const doors = [];
  for (const door of beams) {
    if (!door.armorDoor || door.owner !== "player" || door.hp <= 0 || (door.buildRemaining || 0) > 0)
      continue;
    const a = nodes[door.a],
      b = nodes[door.b];
    if (!a || !b) continue;
    let hit = false;
    for (let t = 0; t < 2; t += 0.025) {
      const u = t + 0.025,
        grav = GRAV * 0.45;
      if (
        segmentHit(
          m.x + vx * t,
          m.y + vy * t + (grav * t * t) / 2,
          m.x + vx * u,
          m.y + vy * u + (grav * u * u) / 2,
          a.x,
          a.y,
          b.x,
          b.y,
          spec.ball + 7,
        )
      ) {
        hit = true;
        break;
      }
    }
    if (hit) doors.push(door);
  }
  return {
    g,
    spec,
    angle,
    m,
    vx,
    vy,
    candidate,
    doors,
    safe: doors.every((d) => safeDoorArc(candidate, d, true)),
  };
}
function shootSelected() {
  if (!aimTarget || gameOver) return;
  const target = fwSharedImpactTarget();
  if (!target) return;
  const selected = selectedGuns(),
    plans = [];
  let loading = 0,
    building = 0,
    insufficient = 0,
    unsafe = 0;
  let availableEnergy = energy;
  for (const g of selected) {
    const spec = WEAPONS[g.type || "cannon"];
    if (
      (g.buildRemaining || 0) > 0 ||
      !beams.some((b) => b.id === g.beamId && (b.buildRemaining || 0) <= 0)
    ) {
      building++;
      continue;
    }
    if ((g.cooldown || 0) > 0 || shots.some((s) => s.life > 0 && s.waitGunId === g.id)) {
      loading++;
      continue;
    }
    if (availableEnergy < spec.energy) {
      insufficient++;
      continue;
    }
    const plan = volleyDoorPlan(g, target.x, target.y);
    if (!plan || !plan.safe) {
      unsafe++;
      continue;
    }
    plans.push(plan);
    availableEnergy -= spec.energy;
  }
  if (!plans.length) {
    document.getElementById("tip").textContent =
      "Kein Schuss möglich: " +
      (unsafe ? "Türöffnung zu eng. " : "") +
      (loading ? "Waffen laden. " : "") +
      (insufficient ? "Zu wenig Energie." : "");
    return;
  }
  // All associated doors are commanded in one operation, even if another
  // gun has no door. Preserve already-open doors instead of snapping them shut.
  const doorIds = new Set(plans.flatMap((p) => p.doors.map((d) => d.id)));
  for (const id of doorIds) {
    const door = beams.find((b) => b.id === id);
    if (door) door.doorTimer = Math.max(door.doorTimer || 0, 2.5);
  }
  const volleyId = ++playerVolleySerial;
  for (const p of plans) {
    const { g, spec, angle, m, vx, vy, doors } = p;
    g.angle = angle;
    if (aimTarget) g.lastAim = { x: aimTarget.x, y: aimTarget.y };
    if (spec.magazine) {
      g.ammo = (g.ammo ?? spec.magazine) - 1;
      if (g.ammo <= 0) {
        g.cooldown = spec.reload;
        g.reloadTotal = spec.reload;
        g.ammo = spec.magazine;
      } else {
        g.cooldown = spec.shotDelay;
        g.reloadTotal = 0;
      }
    } else {
      g.cooldown = spec.reload || spec.cooldown;
      g.reloadTotal = g.cooldown;
    }
    energy -= spec.energy;
    shots.push({
      x: m.x,
      y: m.y,
      px: m.x,
      py: m.y,
      vx,
      vy,
      r: spec.ball,
      damage: spec.damage,
      radius: spec.radius,
      life: 9,
      launchDelay: 0,
      waitDoorIds: doors.map((d) => d.id),
      waitGunId: g.id,
      waitGunType: g.type || "cannon",
      enemy: false,
      weaponType: g.type,
      sourceGunIndex: guns.indexOf(g),
      fwGun: g,
      trail: [m.x, m.y],
      mountBeamId: g.beamId,
      targetX: target.x,
      targetY: target.y,
      volleyId,
      volleyReadyTime: 0,
    });
  }
  hud();
  try {
    fwStatAdd("shots", plans.length);
    fwVibrate(12);
  } catch (e) {}
  document.getElementById("tip").textContent =
    (plans.length === 1
      ? "1 Waffe bereitet den Schuss vor."
      : plans.length + " Waffen bereiten gemeinsamen Schuss vor.") +
    (unsafe ? " " + unsafe + " wegen blockierter Tür ausgelassen." : "");
}
document.getElementById("aimFire").addEventListener("click", shootSelected);
function drawAimTrajectory() {
  if (mode !== "shoot" || !aimTarget) return;
  const target = fwSharedImpactTarget();
  if (!target) return;
  const selected = selectedGuns();
  ctx.save();
  ctx.lineWidth = 2 / zoom;
  ctx.setLineDash([5 / zoom, 7 / zoom]);
  for (const g of selected) {
    const p = weaponPosition(g),
      spec = WEAPONS[g.type || "cannon"];
    if (!p || !spec) continue;
    const angle = calculateLaunchAngle(g, target.x, target.y);
    const muzzle = weaponMuzzle(g, angle);
    const x = muzzle.x,
      y = muzzle.y;
    const vx = Math.cos(angle) * spec.speed,
      vy = Math.sin(angle) * spec.speed;
    // V15.53: For mortar-targeted volleys, follow the real gravity-affected
    // projectile arc to the selected crosshair instead of stopping at 0.34 s.
    // Keep the original short preview for the other aiming modes.
    const mortarAiming = selected.some((w) => w.type === "mortar");
    const targetTime = (target.x - x) / vx;
    const fullArc = mortarAiming && Number.isFinite(targetTime) && targetTime > 0 && targetTime < 8;
    const maxTime = fullArc ? targetTime : 0.34;
    const segments = fullArc ? Math.max(16, Math.min(96, Math.ceil(maxTime * 55))) : 16;
    for (let i = 0; i < segments; i++) {
      const t0 = (maxTime * i) / segments,
        t1 = (maxTime * (i + 1)) / segments;
      const x0 = x + vx * t0,
        y0 = y + vy * t0 + (GRAV * 0.45 * t0 * t0) / 2;
      const x1 = x + vx * t1,
        y1 = y + vy * t1 + (GRAV * 0.45 * t1 * t1) / 2;
      if (y0 > floor() || x0 < 0 || x0 > WORLD_W) break;
      // The final segment ends precisely at the crosshair only if the
      // predicted ballistic endpoint actually matches the target.
      const nearTarget = fullArc && i === segments - 1 && Math.hypot(x1 - target.x, y1 - target.y) < 5;
      ctx.strokeStyle =
        "rgba(159,243,214," +
        ((fullArc ? 0.88 : 0.85) * (fullArc ? 1 : (1 - i / segments) ** 1.5)).toFixed(3) +
        ")";
      ctx.beginPath();
      ctx.moveTo(x0, y0);
      if (nearTarget) ctx.lineTo(target.x, target.y);
      else ctx.lineTo(x1, y1);
      ctx.stroke();
    }
  }
  // Shooting range indicator belongs to the selected weapon, NOT to the reticle.
  // Maximum ideal ballistic horizontal range (same gravity and muzzle speed as firing).
  ctx.setLineDash([7 / zoom, 7 / zoom]);
  ctx.lineWidth = 1.8 / zoom;
  for (const g of selected) {
    const p = weaponPosition(g),
      spec = WEAPONS[g.type || "cannon"];
    if (!p || !spec) continue;
    const range = firingRangeRadius(g);
    ctx.strokeStyle = "rgba(112,228,202,.72)";
    ctx.beginPath();
    ctx.arc(p.x, p.y, range, 0, Math.PI * 2);
    ctx.stroke();
  }
  // Keep the reticle inside the current weapon range even after selection changes.
  aimTarget = limitAimToRange(aimTarget.x, aimTarget.y);
  // Show the actual predicted landing on ground when the reticle is in the air.
  if (Math.hypot(target.x - aimTarget.x, target.y - aimTarget.y) > 15) {
    ctx.setLineDash([]);
    ctx.strokeStyle = "rgba(255,193,89,.80)";
    ctx.lineWidth = 2 / zoom;
    const size = 8 / zoom;
    ctx.beginPath();
    ctx.moveTo(target.x - size, target.y - 2 / zoom);
    ctx.lineTo(target.x + size, target.y - 2 / zoom);
    ctx.stroke();
  }
  // Truly compact crosshair, without a surrounding decorative circle.
  ctx.setLineDash([]);
  ctx.strokeStyle = "#ffdf73";
  ctx.lineWidth = 2 / zoom;
  const arm = 4.75 / zoom;
  ctx.beginPath();
  ctx.moveTo(aimTarget.x - arm, aimTarget.y);
  ctx.lineTo(aimTarget.x + arm, aimTarget.y);
  ctx.moveTo(aimTarget.x, aimTarget.y - arm);
  ctx.lineTo(aimTarget.x, aimTarget.y + arm);
  ctx.stroke();
  ctx.restore();
}
function fwRepairAt(x, y) {
  let b = closestBeam(x, y, 18, "player");
  const tipEl = document.getElementById("tip");
  if (!b) {
    if (closestBeam(x, y, 18)) tipEl.textContent = "Du kannst nur eigene Balken reparieren.";
  } else {
    const mx = getBeamMaxHp(b);
    if (b.hp >= mx) tipEl.textContent = "Dieser Balken ist unbeschädigt.";
    else if (metal < 8) tipEl.textContent = "Zu wenig Eisen: Reparatur kostet 8.";
    else {
      b.hp = Math.min(mx, b.hp + 45);
      metal -= 8;
      hud();
      tipEl.textContent = "Balken repariert: " + Math.round(b.hp) + " / " + mx + " HP.";
    }
  }
}
function finishSingle() {
  if (!single || single.cancelled) return;
  const p = screenToWorld(single.end.x, single.end.y),
    s = screenToWorld(single.start.x, single.start.y);
  // Online guest: world-changing gestures are carried out by the host (online-match.js).
  if (window.fwOnlineGuestGesture && window.fwOnlineGuestGesture(mode, s, p)) return;
  if (mode === "placegun") {
    const snap = placementCandidate(
      single.end.x + c.getBoundingClientRect().left,
      single.end.y + c.getBoundingClientRect().top,
      selectedWeapon,
      "weapon",
    );
    const msg = commitPlacement(snap);
    document.getElementById("tip").textContent = msg;
    if (msg.includes("im Bau")) setMode("shoot");
  } else if (mode === "placeresource") {
    const snap = placementCandidate(
      single.end.x + c.getBoundingClientRect().left,
      single.end.y + c.getBoundingClientRect().top,
      selectedResource,
      "resource",
    );
    const msg = commitPlacement(snap);
    document.getElementById("tip").textContent = msg;
    if (msg.includes("im Bau")) setMode("build");
  } else if (mode === "build") {
    if (Math.hypot(p.x - s.x, p.y - s.y) < MINLEN) {
      const b = closestBeam(p.x, p.y, Math.max(13, 19 / zoom));
      if (b && b.owner === "player") showBeamMenu(b, single.end);
      else hideBeamMenu();
    } else if (Math.hypot(p.x - s.x, p.y - s.y) >= MINLEN) {
      hideBeamMenu(); // Axis-aligned construction: snap near-horizontal/vertical drags precisely.
      const axisTolerance = Math.max(9, 18 / zoom);
      const startSnap = snapBuildPoint(s.x, s.y);
      const a = getBuildNode(startSnap.x, startSnap.y);
      if (!beams.some((e) => e.owner === "player" && e.hp > 0 && (e.a === a || e.b === a))) {
        document.getElementById("tip").textContent = "Starte am Verbindungspunkt deiner eigenen Festung.";
        return;
      }
      const origin = nodes[a];
      let endX = p.x,
        endY = Math.min(p.y, floor());
      if (Math.abs(endX - origin.x) <= axisTolerance) endX = origin.x;
      if (Math.abs(endY - origin.y) <= axisTolerance) endY = origin.y;
      // Horizontal ground beams should not need pixel-perfect dragging along the soil.
      if (Math.abs(origin.y - floor()) < 2 && endY >= floor() - Math.max(22, 32 / zoom)) endY = floor();
      const endSnap = snapBuildPoint(endX, endY, a);
      const b = getBuildNode(endSnap.x, endSnap.y, a);
      if (Math.hypot(nodes[b].x - origin.x, nodes[b].y - origin.y) < MINLEN) {
        document.getElementById("tip").textContent = "Balken zu kurz – etwas weiter ziehen.";
      } else if (!beam(a, b)) {
        document.getElementById("tip").textContent =
          "Balken nicht möglich: Nur an deiner Festung, mit gültiger Länge und genügend Eisen.";
        cleanNodes();
      }
      updateStructuralSupport();
    }
  } else if (mode === "erase") {
    eraseAt(p.x, p.y);
  } else if (mode === "repair") {
    fwRepairAt(p.x, p.y);
  } else if (mode === "shoot") {
    if (!selectAimGun(s.x, s.y)) updateAimTarget(p.x, p.y);
  }
}
// Arsenal: echte Touch-Drag-and-Drop-Montage mit Bildschirm-zu-Welt-Umrechnung.
// Weapons attach to the beam surface, not to its end joints.
function weaponPosition(g) {
  if (g.beamId != null) {
    const b = beams.find((b) => b.id === g.beamId);
    if (!b) return null;
    const a = nodes[b.a],
      z = nodes[b.b];
    if (!a || !z) return null;
    const t = g.t ?? 0.5;
    return { x: a.x + (z.x - a.x) * t, y: a.y + (z.y - a.y) * t - 14 };
  }
  const n = nodes[g.node];
  return n ? { x: n.x, y: n.y - 14 } : null;
}
function nearestMount(wx, wy, owner = "player", range = 48 / zoom) {
  let choice = null,
    best = Infinity;
  const maxDist = Math.min(38, Math.max(12, range));
  for (const b of beams) {
    if (b.owner !== owner || b.hp <= 0 || b.armorDoor) continue;
    const a = nodes[b.a],
      z = nodes[b.b];
    if (!a || !z) continue;
    const vx = z.x - a.x,
      vy = z.y - a.y,
      L2 = vx * vx + vy * vy;
    if (L2 < 100) continue;
    // Only horizontal beams may carry weapons or production buildings.
    if (Math.abs(vy) > Math.max(4, Math.abs(vx) * 0.08)) continue;
    const raw = ((wx - a.x) * vx + (wy - a.y) * vy) / L2;
    const t = Math.max(0.08, Math.min(0.92, raw));
    const x = a.x + vx * t,
      y = a.y + vy * t;
    const dist = Math.hypot(wx - x, wy - y);
    // Only near-horizontal beams are eligible.
    if (dist < best) {
      best = dist;
      choice = { beamId: b.id, t, x, y: y - 14 };
    }
  }
  return best <= maxDist ? choice : null;
}

// A valid building bay is a closed, axis-aligned four-sided frame.
// Sides can consist of several connected beams, but gaps are not allowed.
function beamCoversSide(owner, x1, y1, x2, y2) {
  const horizontal = Math.abs(y1 - y2) < 3;
  const lo = horizontal ? Math.min(x1, x2) : Math.min(y1, y2);
  const hi = horizontal ? Math.max(x1, x2) : Math.max(y1, y2);
  const intervals = [];
  for (const b of beams) {
    if (b.owner !== owner || b.hp <= 0 || b.armorDoor || (b.buildRemaining || 0) > 0) continue;
    const a = nodes[b.a],
      z = nodes[b.b];
    if (!a || !z) continue;
    if (horizontal) {
      if (Math.abs(a.y - y1) > 5 || Math.abs(z.y - y1) > 5 || Math.abs(a.y - z.y) > 5) continue;
      intervals.push([Math.min(a.x, z.x), Math.max(a.x, z.x)]);
    } else {
      if (Math.abs(a.x - x1) > 5 || Math.abs(z.x - x1) > 5 || Math.abs(a.x - z.x) > 5) continue;
      intervals.push([Math.min(a.y, z.y), Math.max(a.y, z.y)]);
    }
  }
  intervals.sort((a, b) => a[0] - b[0]);
  let covered = lo;
  for (const [a, b] of intervals) {
    if (a > covered + 5) break;
    if (b > covered) covered = b;
    if (covered >= hi - 5) return true;
  }
  return false;
}
function closedBuildingBay(mount, owner = "player") {
  const base = beams.find((b) => b.id === mount.beamId);
  if (!base) return false;
  const a = nodes[base.a],
    z = nodes[base.b];
  if (!a || !z) return false;
  const bottom = (a.y + z.y) / 2;
  const xs = new Set(),
    ys = new Set();
  for (const b of beams) {
    if (b.owner !== owner || b.hp <= 0 || (b.buildRemaining || 0) > 0) continue;
    const n = nodes[b.a],
      m = nodes[b.b];
    if (!n || !m) continue;
    if (Math.abs(n.x - m.x) < 5) {
      xs.add(Math.round(n.x));
      xs.add(Math.round(m.x));
    }
    if (Math.abs(n.y - m.y) < 5) {
      ys.add(Math.round(n.y));
      ys.add(Math.round(m.y));
    }
  }
  const lefts = [...xs].filter((x) => x < mount.x - 9).sort((a, b) => b - a);
  const rights = [...xs].filter((x) => x > mount.x + 9).sort((a, b) => a - b);
  const tops = [...ys].filter((y) => y < bottom - 35).sort((a, b) => b - a);
  for (const top of tops) {
    if (bottom - top > 350) continue;
    for (const left of lefts) {
      if (mount.x - left > 230) continue;
      for (const right of rights) {
        if (right - mount.x > 230 || right - left < 55) continue;
        if (
          beamCoversSide(owner, left, top, right, top) &&
          beamCoversSide(owner, left, bottom, right, bottom) &&
          beamCoversSide(owner, left, top, left, bottom) &&
          beamCoversSide(owner, right, top, right, bottom)
        )
          return true;
      }
    }
  }
  return false;
}
// A gun may sit on a roof or an open platform, but its barrel must not
// project through a solid foreground wall. Background beams and armored
// firing doors are intentional exceptions.
function weaponBarrelBlocked(place, owner = "player") {
  const direction = fwFacesLeft(owner) ? -1 : 1;
  const startX = place.x,
    startY = place.y;
  const endX = startX + direction * 65;
  for (const b of beams) {
    if (b.owner !== owner || b.id === place.beamId || b.background || b.armorDoor || b.hp <= 0) continue;
    const a = nodes[b.a],
      z = nodes[b.b];
    if (!a || !z) continue;
    const hit = segmentHit(startX, startY, endX, startY, a.x, a.y, z.x, z.y, 9);
    if (hit) return true;
  }
  return false;
}
// Identical checks for preview and final placement, without changing game state.
function canPlaceWeapon(type, wx, wy) {
  if (!unlockedWeapons.has(type)) return false;
  const spec = WEAPONS[type],
    place = nearestMount(wx, wy);
  if (!spec || !place || weaponBarrelBlocked(place)) return false;
  if (
    guns.some((g) => {
      const pos = weaponPosition(g);
      return pos && Math.hypot(pos.x - place.x, pos.y - place.y) < 112;
    })
  )
    return false;
  if (
    !cheatMode &&
    !resources.some(
      (r) => r.type === "workshop" && (r.buildRemaining || 0) <= 0 && beams.some((b) => b.id === r.beamId),
    )
  )
    return false;
  return metal >= spec.cost;
}
function canPlaceResource(type, wx, wy) {
  const spec = RESOURCE_TYPES[type],
    place = nearestMount(wx, wy, "player", 70 / zoom);
  if (!spec || !place) return false;
  if (type === "mine" && !mineGroundMount(place)) return false;
  if (
    resources.some((r) => {
      const b = beams.find((b) => b.id === r.beamId);
      if (!b) return false;
      const a = nodes[b.a],
        z = nodes[b.b];
      return Math.hypot(a.x + (z.x - a.x) * r.t - place.x, a.y + (z.y - a.y) * r.t - 14 - place.y) < 65;
    })
  )
    return false;
  return metal >= spec.cost;
}
const PLACEMENT_GRID = 20;
let placementCursor = null;
function placementCandidate(clientX, clientY, type, kind) {
  const rect = c.getBoundingClientRect();
  const inside =
    clientX >= rect.left && clientX <= rect.right && clientY >= rect.top && clientY <= rect.bottom;
  const w = screenToWorld(clientX - rect.left, clientY - rect.top);
  const gridX = Math.round(w.x / PLACEMENT_GRID) * PLACEMENT_GRID;
  const gridY = Math.round(w.y / PLACEMENT_GRID) * PLACEMENT_GRID;
  // Finger may be slightly above the beam: snap to the beam itself, not to the floor.
  const mount = inside ? nearestMount(w.x, w.y, "player", 34) : null;
  const x = mount ? mount.x : gridX,
    y = mount ? mount.y : gridY;
  const reason = !inside
    ? "Außerhalb des Schlachtfelds"
    : !mount
      ? "Kein tragender Balken in der Nähe"
      : kind === "weapon"
        ? weaponPlacementReason(type, mount)
        : resourcePlacementReason(type, mount);
  return { x, y, valid: !reason, reason, inside, type, kind, mount };
}
// Keep full-size structures away from exposed beam ends and the outside edges
// of the player's fortress. This is checked by both the preview and placement.
const EDGE_MARGIN = 28;
const JOINT_MARGIN = 12;
function placementEdgeReason(place) {
  if (!place) return "Kein tragender Balken";
  const beam = beams.find((b) => b.id === place.beamId);
  if (!beam) return "Balken nicht gefunden";
  const a = nodes[beam.a],
    z = nodes[beam.b];
  if (!a || !z) return "Balken nicht gefunden";
  const length = Math.hypot(z.x - a.x, z.y - a.y);
  if (length * place.t < JOINT_MARGIN || length * (1 - place.t) < JOINT_MARGIN) return "Zu nah am Balkenende";
  // Check outer boundary from the player's structural nodes, not buildings.
  const xs = [];
  for (const b of beams) {
    if (b.owner !== "player" || b.hp <= 0) continue;
    const n = nodes[b.a],
      m = nodes[b.b];
    if (n && m) {
      xs.push(n.x, m.x);
    }
  }
  if (xs.length > 1) {
    const left = Math.min(...xs),
      right = Math.max(...xs);
    if (place.x - left < EDGE_MARGIN || right - place.x < EDGE_MARGIN)
      return "Zu nah am äußeren Festungsrand";
  }
  return "";
}
// Automatically move foreground braces behind a newly mounted weapon or building.
// Keep the horizontal supporting beam, armored doors and the rest of the fort unchanged.
function overlappingForegroundBeams(place, kind) {
  if (!place) return [];
  // Only the actual central body of the placed item, not a broad
  // bounding box that reaches into neighbouring bays or touches joints.
  const halfWidth = kind === "weapon" ? 30 : 29;
  const height = kind === "weapon" ? 39 : 44;
  const left = place.x - halfWidth + 3,
    right = place.x + halfWidth - 3;
  const top = place.y - height,
    bottom = place.y - 7;
  function crossesBody(ax, ay, bx, by) {
    // Clip the beam to the interior of the body rectangle (Liang-Barsky).
    // Touching an edge or corner alone is not an obstruction.
    const dx = bx - ax,
      dy = by - ay;
    let lo = 0,
      hi = 1;
    const p = [-dx, dx, -dy, dy],
      q = [ax - left, right - ax, ay - top, bottom - ay];
    for (let i = 0; i < 4; i++) {
      if (Math.abs(p[i]) < 1e-8) {
        if (q[i] <= 0) return false;
        continue;
      }
      const t = q[i] / p[i];
      if (p[i] < 0) lo = Math.max(lo, t);
      else hi = Math.min(hi, t);
      if (lo >= hi) return false;
    }
    return hi - lo > 0.025;
  }
  return beams.filter((b) => {
    if (b.owner !== "player" || b.hp <= 0 || b.background || b.armorDoor || b.id === place.beamId)
      return false;
    const a = nodes[b.a],
      z = nodes[b.b];
    if (!a || !z) return false;
    // Keep horizontal supporting platform beams unchanged.
    if (Math.abs(a.y - z.y) < 5 && Math.abs((a.y + z.y) / 2 - (place.y + 14)) < 16) return false;
    return crossesBody(a.x, a.y, z.x, z.y);
  });
}
function moveObstructingBeamsBehind(place, kind) {
  const overlapping = overlappingForegroundBeams(place, kind);
  for (const beam of overlapping) beam.background = true;
  return overlapping.length;
}
// A gun's barrel and carriage need more clearance than a production building.
// Check only the exterior edges; interior walls can be converted to back beams.
function weaponExteriorClearance(place) {
  if (!place) return "Kein Bauplatz";
  const xs = [];
  for (const b of beams) {
    if (b.owner !== "player" || b.hp <= 0) continue;
    const a = nodes[b.a],
      z = nodes[b.b];
    if (a && z) xs.push(a.x, z.x);
  }
  if (xs.length < 2) return "";
  const left = Math.min(...xs),
    right = Math.max(...xs);
  // Includes the visible barrel, not just the weapon's mounting point.
  // The barrel points towards the enemy: right for the left fort, left for the
  // right fort (online guest, sides swapped).
  const facesLeft = fwFacesLeft("player");
  const leftClearance = facesLeft ? 51 : 25,
    rightClearance = facesLeft ? 25 : 51;
  if (place.x - left < leftClearance || right - place.x < rightClearance)
    return "Waffe ragt über die Außenwand – weiter innen platzieren";
  return "";
}
// Prevent a weapon from occupying the visible body of an existing
// production building. Compare actual world positions, not beam IDs.
function weaponOverlapsBuilding(place) {
  const facesLeft = fwFacesLeft("player");
  const gunLeft = place.x - (facesLeft ? 48 : 33),
    gunRight = place.x + (facesLeft ? 33 : 48);
  const gunTop = place.y - 42,
    gunBottom = place.y + 6;
  for (const r of resources) {
    const b = beams.find((b) => b.id === r.beamId);
    if (!b) continue;
    const a = nodes[b.a],
      z = nodes[b.b];
    if (!a || !z) continue;
    const x = a.x + (z.x - a.x) * (r.t ?? 0.5);
    const y = a.y + (z.y - a.y) * (r.t ?? 0.5) - 14;
    const w = r.type === "wind" ? 33 : 43;
    const h = r.type === "wind" ? 80 : 57;
    // Slight safety padding keeps sprites visually separated.
    if (gunLeft < x + w + 5 && gunRight > x - w - 5 && gunTop < y + 8 && gunBottom > y - h - 5) return true;
  }
  return false;
}
function weaponPlacementReason(type, place) {
  const spec = WEAPONS[type];
  if (!spec) return "Unbekannte Waffe";
  if (window.fwMission?.allowed && !window.fwMission.allowed.includes(type)) return "In dieser Mission nicht erlaubt";
  if (!unlockedWeapons.has(type)) return "Waffe noch nicht erforscht";
  if (!place) return "Nur auf waagerechten Balken";
  if (type === "mine" && !mineGroundMount(place))
    return "Minen dürfen nur unten auf dem Erdboden gebaut werden";
  const edgeReason = placementEdgeReason(place);
  if (edgeReason) return edgeReason;
  const exteriorReason = weaponExteriorClearance(place);
  if (exteriorReason) return exteriorReason;
  if (weaponOverlapsBuilding(place)) return "Waffe überlappt ein Wirtschaftsgebäude";
  // Foreground braces overlapping the weapon will be moved to the background automatically.
  if (
    guns.some((g) => {
      const pos = weaponPosition(g);
      return pos && Math.hypot(pos.x - place.x, pos.y - place.y) < 64;
    })
  )
    return "Zu nah an einer anderen Waffe";
  if (
    !cheatMode &&
    !resources.some(
      (r) => r.type === "workshop" && (r.buildRemaining || 0) <= 0 && beams.some((b) => b.id === r.beamId),
    )
  )
    return "Zuerst Waffenwerkstatt fertigstellen";
  if (metal < spec.cost) return "Nicht genug Eisen (" + spec.cost + " benötigt)";
  return "";
}
// V14.59: Mines require a horizontal foundation resting on the actual terrain.
// Both ends are checked so a sloping or suspended beam cannot carry a mine.
function mineGroundMount(place) {
  if (!place) return false;
  const b = beams.find((b) => b.id === place.beamId);
  if (!b || b.hp <= 0) return false;
  const a = nodes[b.a],
    z = nodes[b.b];
  return !!(a && z && Math.abs(a.y - floor()) <= 12 && Math.abs(z.y - floor()) <= 12);
}
function resourcePlacementReason(type, place) {
  const spec = RESOURCE_TYPES[type];
  if (!spec) return "Unbekanntes Gebäude";
  if (!place) return "Nur auf waagerechten Balken";
  if (type === "mine" && !mineGroundMount(place))
    return "Minen dürfen ausschließlich auf dem Erdboden gebaut werden";
  const edgeReason = placementEdgeReason(place);
  if (edgeReason) return edgeReason;
  if (
    resources.some((r) => {
      const b = beams.find((b) => b.id === r.beamId);
      if (!b) return false;
      const a = nodes[b.a],
        z = nodes[b.b];
      return Math.hypot(a.x + (z.x - a.x) * r.t - place.x, a.y + (z.y - a.y) * r.t - 14 - place.y) < 65;
    })
  )
    return "Zu nah an einem anderen Gebäude";
  if (metal < spec.cost) return "Nicht genug Eisen (" + spec.cost + " benötigt)";
  return "";
}
function commitPlacement(p) {
  if (!p || !p.valid || !p.mount) return "Rot: " + (p?.reason || "Hier kann nicht gebaut werden");
  const place = p.mount;
  if (p.kind === "weapon") {
    const reason = weaponPlacementReason(p.type, place);
    if (reason) return "Rot: " + reason;
    const spec = WEAPONS[p.type];
    moveObstructingBeamsBehind(place, "weapon");
    const fwBlocked = p.type !== "flak" && fwSpotLineBlocked(place, place.beamId);
    guns.push({
      beamId: place.beamId,
      t: place.t,
      owner: "player",
      type: p.type,
      hp: 130,
      maxHp: 130,
      angle: fwFacesLeft("player") ? Math.PI + 0.25 : -0.25,
      flash: 0,
      cooldown: 0,
      doorTimer: 0,
      buildRemaining: BUILD_TIMES[p.type],
      buildTotal: BUILD_TIMES[p.type],
    });
    metal -= spec.cost;
    hud();
    return (
      spec.name +
      " im Bau (" +
      BUILD_TIMES[p.type] +
      " Sekunden)." +
      (p.type === "flak" ? " Fängt Raketen und Mörsergranaten automatisch ab." : "") +
      (fwBlocked ? " Achtung: Eine eigene Wand steht im Schussfeld – baue davor eine Panzertür." : "")
    );
  }
  const reason = resourcePlacementReason(p.type, place);
  if (reason) return "Rot: " + reason;
  const spec = RESOURCE_TYPES[p.type];
  moveObstructingBeamsBehind(place, "resource");
  metal -= spec.cost;
  const maxHp = getResourceMaxHp({ type: p.type });
  resources.push({
    type: p.type,
    beamId: place.beamId,
    t: place.t,
    owner: "player",
    hp: maxHp,
    maxHp,
    buildRemaining: BUILD_TIMES[p.type],
    buildTotal: BUILD_TIMES[p.type],
  });
  hud();
  return (
    ({ mine: "Eisenmine", wind: "Windrad", workshop: "Waffenwerkstatt", repair: "Reparaturturm" }[p.type] ||
      "Gebäude") +
    " im Bau (" +
    BUILD_TIMES[p.type] +
    " Sekunden)."
  );
}
// V15.59: While a weapon or building is dragged, every valid mounting spot on
// the player's horizontal beams is highlighted (cached, recomputed 4x/s).
let fwSpotCache = { key: "", at: 0, segs: [] };
function fwValidSpotSegments(type, kind) {
  const now = performance.now(),
    key = kind + ":" + type;
  if (fwSpotCache.key === key && now - fwSpotCache.at < 250) return fwSpotCache.segs;
  const segs = [];
  for (const b of beams) {
    if (b.owner !== "player" || b.hp <= 0 || b.armorDoor || (b.buildRemaining || 0) > 0) continue;
    const a = nodes[b.a],
      z = nodes[b.b];
    if (!a || !z) continue;
    const vx = z.x - a.x,
      vy = z.y - a.y,
      len = Math.hypot(vx, vy);
    if (len < 10 || Math.abs(vy) > Math.max(4, Math.abs(vx) * 0.08)) continue;
    const steps = Math.max(4, Math.round(len / 7));
    let run = null;
    for (let i = 0; i <= steps; i++) {
      const t = 0.08 + (0.84 * i) / steps,
        place = { beamId: b.id, t, x: a.x + vx * t, y: a.y + vy * t - 14 };
      let ok = false;
      try {
        ok = !(kind === "weapon" ? weaponPlacementReason(type, place) : resourcePlacementReason(type, place));
      } catch (e) {
        ok = false;
      }
      const state = !ok ? null : kind === "weapon" && fwSpotLineBlocked(place, b.id) ? "warn" : "ok";
      if (state && run && run.state === state) run.t1 = t;
      else {
        if (run) segs.push(run);
        run = state ? { b, t0: t, t1: t, state } : null;
      }
    }
    if (run) segs.push(run);
  }
  fwSpotCache = { key, at: now, segs };
  return segs;
}
// V15.60: Would a weapon at this spot fire into the player's own wall?
// Checks three typical launch angles; armored doors count as open.
function fwSpotLineBlocked(place, mountBeamId) {
  const dir = fwFacesLeft("player") ? -1 : 1; // towards the enemy
  const ox = place.x + 18 * dir,
    oy = place.y - 12;
  let clear = 0;
  for (const ang of [-0.3, -0.55, -0.8]) {
    const ex = ox + Math.cos(ang) * 260 * dir,
      ey = oy + Math.sin(ang) * 260;
    let hit = false;
    for (const w of beams) {
      if (w.owner !== "player" || w.hp <= 0 || w.background || w.armorDoor || w.id === mountBeamId) continue;
      const a = nodes[w.a],
        z = nodes[w.b];
      if (!a || !z) continue;
      if (fwSegmentsCross(ox, oy, ex, ey, a.x, a.y, z.x, z.y)) {
        hit = true;
        break;
      }
    }
    if (!hit) clear++;
  }
  return clear === 0;
}
function fwSegmentsCross(ax, ay, bx, by, cx, cy, dx, dy) {
  const rx = bx - ax,
    ry = by - ay,
    sx = dx - cx,
    sy = dy - cy;
  const den = rx * sy - ry * sx;
  if (Math.abs(den) < 1e-9) return false;
  const t = ((cx - ax) * sy - (cy - ay) * sx) / den,
    u = ((cx - ax) * ry - (cy - ay) * rx) / den;
  return t >= 0 && t <= 1 && u >= -0.02 && u <= 1.02;
}
// V15.60: The flight path and impact of each weapon's LAST shot stay visible
// (fading after 6 s, always faintly visible in fire mode). Aiming stays a guess,
// but the player can learn from the previous shot.
let fwLastShots = [];
function fwRememberShot(s) {
  const pts = s.trail.slice();
  pts.push(s.x, s.y);
  fwLastShots = fwLastShots.filter((r) => r.gun !== s.fwGun && guns.includes(r.gun));
  fwLastShots.push({ gun: s.fwGun, pts, x: s.x, y: s.y, at: performance.now() });
  if (fwLastShots.length > 12) fwLastShots.shift();
}
function fwDrawLastShots() {
  if (!fwLastShots.length) return;
  const now = performance.now();
  ctx.save();
  ctx.lineCap = "round";
  for (const r of fwLastShots) {
    if (!guns.includes(r.gun)) continue;
    const age = (now - r.at) / 1000;
    const selected = mode === "shoot" && selectedAimGuns.has(r.gun);
    let alpha = selected ? 0.6 : age < 6 ? 0.5 * (1 - age / 6) : 0;
    if (mode === "shoot") alpha = Math.max(alpha, 0.16);
    if (alpha <= 0.01) continue;
    ctx.globalAlpha = alpha;
    ctx.strokeStyle = "#ffd27a";
    ctx.lineWidth = 2.5 / zoom;
    ctx.setLineDash([7 / zoom, 7 / zoom]);
    ctx.beginPath();
    ctx.moveTo(r.pts[0], r.pts[1]);
    for (let i = 2; i < r.pts.length; i += 2) ctx.lineTo(r.pts[i], r.pts[i + 1]);
    ctx.stroke();
    ctx.setLineDash([]);
    const k = 9 / zoom;
    ctx.strokeStyle = "#ff8a5c";
    ctx.lineWidth = 3 / zoom;
    ctx.beginPath();
    ctx.moveTo(r.x - k, r.y - k);
    ctx.lineTo(r.x + k, r.y + k);
    ctx.moveTo(r.x + k, r.y - k);
    ctx.lineTo(r.x - k, r.y + k);
    ctx.stroke();
  }
  ctx.restore();
}
function fwDrawOwnHitMarker() {
  const m = window.__fwOwnHitBeam;
  if (!m || performance.now() > m.until) return;
  const b = beams.find((x) => x.id === m.id);
  if (!b) return;
  const a = nodes[b.a],
    z = nodes[b.b];
  if (!a || !z) return;
  const on = Math.floor(performance.now() / 250) % 2 === 0;
  ctx.save();
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.lineCap = "round";
  ctx.strokeStyle = on ? "rgba(255,70,60,.95)" : "rgba(255,190,90,.75)";
  ctx.lineWidth = 8;
  ctx.beginPath();
  ctx.moveTo(camX + a.x * zoom, camY + a.y * zoom);
  ctx.lineTo(camX + z.x * zoom, camY + z.y * zoom);
  ctx.stroke();
  ctx.restore();
}
function fwDrawValidSpots() {
  const p = placementCursor;
  if (!p || !p.type || !p.kind) return;
  const segs = fwValidSpotSegments(p.type, p.kind);
  if (!segs.length) return;
  const pulse = 0.55 + 0.25 * Math.sin(performance.now() / 180);
  ctx.save();
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.lineCap = "round";
  for (const s of segs) {
    const a = nodes[s.b.a],
      z = nodes[s.b.b];
    if (!a || !z) continue;
    const x0 = camX + (a.x + (z.x - a.x) * s.t0) * zoom,
      y0 = camY + (a.y + (z.y - a.y) * s.t0) * zoom;
    const x1 = camX + (a.x + (z.x - a.x) * s.t1) * zoom,
      y1 = camY + (a.y + (z.y - a.y) * s.t1) * zoom;
    ctx.setLineDash([]);
    ctx.strokeStyle = "rgba(20,60,30,.65)";
    ctx.lineWidth = 9;
    ctx.beginPath();
    ctx.moveTo(x0, y0);
    ctx.lineTo(x1 + 0.01, y1);
    ctx.stroke();
    ctx.strokeStyle = s.state === "warn" ? "rgba(255,196,64," + pulse + ")" : "rgba(91,255,156," + pulse + ")";
    ctx.lineWidth = 5;
    // shape, not only colour: blocked spots are dashed
    ctx.setLineDash(s.state === "warn" ? [5, 5] : []);
    ctx.beginPath();
    ctx.moveTo(x0, y0);
    ctx.lineTo(x1 + 0.01, y1);
    ctx.stroke();
  }
  ctx.restore();
}
function drawPlacementCursor() {
  fwDrawOwnHitMarker();
  fwDrawValidSpots();
  if (!placementCursor || !placementCursor.inside) return;
  const p = placementCursor;
  // Draw in SCREEN coordinates, independent of camera zoom and world transformations.
  const x = camX + p.x * zoom,
    y = camY + p.y * zoom;
  // Preview represents a fixed WORLD size: small when zoomed out, larger when zoomed in.
  const previewScale = zoom / 2;
  const width = 90 * previewScale,
    height = 66 * previewScale;
  ctx.save();
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.strokeStyle = p.valid ? "#5bff9c" : "#ff626b";
  ctx.fillStyle = p.valid ? "rgba(30,175,99,.22)" : "rgba(220,42,55,.25)";
  ctx.lineWidth = Math.max(0.8, 3 * previewScale);
  ctx.setLineDash([7 * previewScale, 4 * previewScale]);
  ctx.fillRect(x - width / 2, y - height, width, height);
  ctx.strokeRect(x - width / 2, y - height, width, height);
  ctx.setLineDash([]);
  ctx.beginPath();
  ctx.arc(x, y - 30 * previewScale, 13 * previewScale, 0, Math.PI * 2);
  ctx.fillStyle = p.valid ? "#4eff96" : "#ff525e";
  ctx.fill();
  ctx.strokeStyle = "#092336";
  ctx.lineWidth = Math.max(0.8, 2 * previewScale);
  ctx.stroke();
  ctx.fillStyle = "#082334";
  ctx.font = "bold " + Math.max(6, 15 * previewScale) + "px system-ui";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(p.valid ? "✓" : "×", x, y - 30 * previewScale);
  ctx.restore();
}
function updatePlacementGhost(clientX, clientY, type, kind) {
  placementCursor = placementCandidate(clientX, clientY, type, kind);
  const p = placementCursor;
  weaponGhost.classList.toggle("placement-valid", p.valid);
  weaponGhost.classList.toggle("placement-invalid", !p.valid);
  weaponGhost.setAttribute("aria-label", p.valid ? "Hier kann gebaut werden" : p.reason);
  // Preview follows the actual snapped position, not the finger or ground.
  if (p.inside) {
    weaponGhost.style.left = c.getBoundingClientRect().left + camX + p.x * zoom + "px";
    weaponGhost.style.top = c.getBoundingClientRect().top + camY + p.y * zoom - 32 * (zoom / 2) + "px";
    weaponGhost.style.transform = "translate(-50%,-50%) scale(" + zoom / 2 + ")";
  }
}
function clearPlacementGhost() {
  placementCursor = null;
  weaponGhost.style.transform = "translate(-50%,-50%)";
  weaponGhost.classList.remove("placement-valid", "placement-invalid");
}
function mountWeapon(type, wx, wy) {
  if (!unlockedWeapons.has(type)) return "Diese Waffe muss zuerst erforscht werden!";
  const spec = WEAPONS[type],
    place = nearestMount(wx, wy);
  if (!place) return "Nur auf waagerechten eigenen Balken platzierbar.";
  if (type === "mine" && !mineGroundMount(place))
    return "Minen dürfen nur unten auf dem Erdboden gebaut werden.";
  const edgeReason = placementEdgeReason(place);
  if (edgeReason) return edgeReason;
  const exteriorReason = weaponExteriorClearance(place);
  if (exteriorReason) return exteriorReason;
  if (weaponOverlapsBuilding(place)) return "Waffe überlappt ein Wirtschaftsgebäude";
  // Overlapping front beams are converted to background beams when placed.
  if (
    guns.some((g) => {
      const pos = weaponPosition(g);
      return pos && Math.hypot(pos.x - place.x, pos.y - place.y) < 64;
    })
  )
    return "Zu nah an einer anderen Waffe.";
  if (
    !cheatMode &&
    !resources.some(
      (r) => r.type === "workshop" && (r.buildRemaining || 0) <= 0 && beams.some((b) => b.id === r.beamId),
    )
  )
    return "Zuerst eine Waffenwerkstatt errichten!";
  if (metal < spec.cost) return "Nicht genug Eisen für " + spec.name + ".";
  moveObstructingBeamsBehind(place, "weapon");
  guns.push({
    beamId: place.beamId,
    t: place.t,
    owner: "player",
    type,
    hp: 130,
    maxHp: 130,
    angle: -0.25,
    flash: 0,
    cooldown: 0,
    doorTimer: 0,
    buildRemaining: BUILD_TIMES[type],
    buildTotal: BUILD_TIMES[type],
  });
  metal -= spec.cost;
  hud();
  return spec.name + " im Bau (" + BUILD_TIMES[type] + " Sekunden).";
}
function placeResource(type, wx, wy) {
  const spec = RESOURCE_TYPES[type],
    place = nearestMount(wx, wy, "player", 70 / zoom);
  if (!place) return "Nur auf waagerechten eigenen Balken platzierbar.";
  if (type === "mine" && !mineGroundMount(place))
    return "Minen dürfen ausschließlich auf dem Erdboden gebaut werden.";
  const edgeReason = placementEdgeReason(place);
  if (edgeReason) return edgeReason;
  if (
    resources.some((r) => {
      const b = beams.find((b) => b.id === r.beamId);
      if (!b) return false;
      const a = nodes[b.a],
        z = nodes[b.b];
      return Math.hypot(a.x + (z.x - a.x) * r.t - place.x, a.y + (z.y - a.y) * r.t - 14 - place.y) < 65;
    })
  )
    return "Hier steht bereits ein Gebäude.";
  if (metal < spec.cost) return "Zu wenig Eisen: " + spec.cost + " benötigt.";
  moveObstructingBeamsBehind(place, "resource");
  metal -= spec.cost;
  const maxHp = getResourceMaxHp({ type });
  resources.push({
    type,
    beamId: place.beamId,
    t: place.t,
    owner: "player",
    hp: maxHp,
    maxHp,
    buildRemaining: BUILD_TIMES[type],
    buildTotal: BUILD_TIMES[type],
  });
  hud();
  return (
    ({ mine: "Eisenmine", wind: "Windrad", workshop: "Waffenwerkstatt", repair: "Reparaturturm" }[type] ||
      "Gebäude") +
    " im Bau (" +
    BUILD_TIMES[type] +
    " Sekunden)."
  );
}
const weaponGhost = document.getElementById("weaponGhost");
let weaponDrag = null;
// Reliable drag-and-drop: capture the gesture on the weapon card, never turn a
// weapon drag into inventory scrolling. Tapping also selects placement mode.
for (const card of document.querySelectorAll(".weaponCard")) {
  let gesture = null;
  card.style.touchAction = "none";
  card.addEventListener("pointerdown", (e) => {
    if (e.pointerType === "mouse" && e.button !== 0) return;
    e.preventDefault();
    e.stopPropagation();
    const type = card.dataset.weapon;
    gesture = {
      id: e.pointerId,
      type,
      x: e.clientX,
      y: e.clientY,
      lastX: e.clientX,
      moved: false,
      scrolling: false,
      placing: false,
      locked: !unlockedWeapons.has(type),
    };
    weaponDrag = gesture.locked ? null : gesture;
    card.setPointerCapture(e.pointerId);
    if (gesture.locked) return;
    weaponGhost.innerHTML = "";
    const art = card.querySelector(".illustration");
    if (art) {
      const preview = art.cloneNode(true);
      preview.style.cssText =
        "display:block!important;position:relative!important;inset:auto!important;width:86px!important;height:66px!important;min-height:66px!important;max-height:none!important;flex:none!important;margin:0!important;transform:none!important;background-position:center!important;background-repeat:no-repeat!important;background-size:contain!important;pointer-events:none!important;";
      // Preserve the runtime-generated weapon skin rather than using only the text label.
      const bg = getComputedStyle(art).backgroundImage;
      if (bg && bg !== "none") preview.style.setProperty("background-image", bg, "important");
      weaponGhost.appendChild(preview);
    } else {
      weaponGhost.textContent = "⚙";
    }
    weaponGhost.style.fontSize = "0";
    weaponGhost.style.padding = "4px";
    weaponGhost.style.width = "100px";
    weaponGhost.style.height = "82px";
    weaponGhost.style.display = "block";
    weaponGhost.style.left = e.clientX + "px";
    weaponGhost.style.top = e.clientY + "px";
    updatePlacementGhost(e.clientX, e.clientY, type, "weapon");
  });
  card.addEventListener("pointermove", (e) => {
    if (!gesture || gesture.id !== e.pointerId) return;
    e.preventDefault();
    e.stopPropagation();
    const dx = e.clientX - gesture.x,
      dy = e.clientY - gesture.y;
    // Decide once whether this gesture scrolls the arsenal or places a weapon.
    // After leaving the dock, never reclassify a placement drag as a scroll.
    if (!gesture.scrolling && !gesture.placing && Math.hypot(dx, dy) > 9) {
      const dockRect = document.getElementById("weaponDock").getBoundingClientRect();
      const insideDock = e.clientY >= dockRect.top && e.clientY <= dockRect.bottom;
      if (insideDock && Math.abs(dx) > Math.abs(dy) * 1.35) {
        gesture.scrolling = true;
        weaponDrag = null;
        weaponGhost.style.display = "none";
        clearPlacementGhost();
      } else {
        gesture.placing = true;
      }
    }
    if (gesture.scrolling) {
      document.getElementById("weaponDock").scrollLeft -= e.clientX - gesture.lastX;
    } else if (!gesture.locked) {
      if (Math.hypot(dx, dy) > 8) gesture.moved = true;
      weaponGhost.style.left = e.clientX + "px";
      weaponGhost.style.top = e.clientY + "px";
      updatePlacementGhost(e.clientX, e.clientY, gesture.type, "weapon");
    }
    gesture.lastX = e.clientX;
  });
  const finish = (e) => {
    if (!gesture || gesture.id !== e.pointerId) return;
    e.preventDefault();
    e.stopPropagation();
    const g = gesture;
    gesture = null;
    weaponDrag = null;
    weaponGhost.style.display = "none";
    clearPlacementGhost();
    if (e.type === "pointercancel" || g.scrolling) return;
    if (g.locked) {
      document.getElementById("tip").textContent = "Waffe noch gesperrt: zuerst erforschen.";
      return;
    }
    const r = c.getBoundingClientRect();
    if (
      g.moved &&
      e.clientX >= r.left &&
      e.clientX <= r.right &&
      e.clientY >= r.top &&
      e.clientY <= r.bottom
    ) {
      document.getElementById("tip").textContent = commitPlacement(
        placementCandidate(e.clientX, e.clientY, g.type, "weapon"),
      );
    } else {
      selectedWeapon = g.type;
      setMode("placegun");
      document.getElementById("tip").textContent = "Waffe ausgewählt: jetzt auf einen eigenen Balken tippen.";
    }
  };
  card.addEventListener("pointerup", finish);
  card.addEventListener("pointercancel", finish);
}
// V15.59: Same gesture logic as the arsenal: a horizontal swipe inside the dock
// scrolls the Wirtschaft bar, any other movement drags the building.
for (const card of document.querySelectorAll(".resourceCard")) {
  let gesture = null;
  card.style.touchAction = "none";
  const dock = document.getElementById("resourceDock");
  card.addEventListener("pointerdown", (e) => {
    if (e.pointerType === "mouse" && e.button !== 0) return;
    e.preventDefault();
    e.stopPropagation();
    gesture = {
      id: e.pointerId,
      type: card.dataset.resource,
      x: e.clientX,
      y: e.clientY,
      lastX: e.clientX,
      moved: false,
      scrolling: false,
      placing: false,
    };
    card.setPointerCapture(e.pointerId);
    weaponGhost.innerHTML = card.querySelector(".illustration")?.outerHTML || "⚙";
    weaponGhost.style.display = "none";
    weaponGhost.style.left = e.clientX + "px";
    weaponGhost.style.top = e.clientY + "px";
  });
  card.addEventListener("pointermove", (e) => {
    if (!gesture || gesture.id !== e.pointerId) return;
    e.preventDefault();
    e.stopPropagation();
    const dx = e.clientX - gesture.x,
      dy = e.clientY - gesture.y;
    if (!gesture.scrolling && !gesture.placing && Math.hypot(dx, dy) > 9) {
      const rect = dock.getBoundingClientRect();
      const insideDock = e.clientY >= rect.top && e.clientY <= rect.bottom;
      if (insideDock && Math.abs(dx) > Math.abs(dy) * 1.35) {
        gesture.scrolling = true;
        weaponGhost.style.display = "none";
        clearPlacementGhost();
      } else {
        gesture.placing = true;
        weaponGhost.style.display = "block";
      }
    }
    if (gesture.scrolling) {
      dock.scrollLeft -= e.clientX - gesture.lastX;
    } else if (gesture.placing) {
      gesture.moved = true;
      weaponGhost.style.left = e.clientX + "px";
      weaponGhost.style.top = e.clientY + "px";
      updatePlacementGhost(e.clientX, e.clientY, gesture.type, "resource");
    }
    gesture.lastX = e.clientX;
  });
  const finish = (e) => {
    if (!gesture || gesture.id !== e.pointerId) return;
    e.preventDefault();
    e.stopPropagation();
    const g = gesture;
    gesture = null;
    weaponGhost.style.display = "none";
    clearPlacementGhost();
    if (e.type === "pointercancel" || g.scrolling) return;
    const r = c.getBoundingClientRect();
    if (
      g.moved &&
      e.clientX >= r.left &&
      e.clientX <= r.right &&
      e.clientY >= r.top &&
      e.clientY <= r.bottom
    ) {
      document.getElementById("tip").textContent = commitPlacement(
        placementCandidate(e.clientX, e.clientY, g.type, "resource"),
      );
    } else {
      selectedResource = g.type;
      setMode("placeresource");
      document.getElementById("tip").textContent =
        ({ mine: "Mine", wind: "Windrad", workshop: "Werkstatt", repair: "Reparaturturm" }[g.type] ||
          "Gebäude") + " ausgewählt: jetzt auf einen eigenen Balken tippen.";
    }
  };
  card.addEventListener("pointerup", finish);
  card.addEventListener("pointercancel", finish);
}
c.addEventListener("pointerdown", (e) => {
  e.preventDefault();
  c.setPointerCapture(e.pointerId);
  touches.set(e.pointerId, rawPoint(e));
  if (touches.size === 2) {
    beginGesture();
    return;
  }
  if (touches.size > 2) {
    single = null;
    drag = null;
    return;
  }
  if (touches.size === 1 && !gesture) {
    const q = rawPoint(e);
    single = { start: q, end: q, cancelled: false };
    if (mode === "build") {
      const p = point(e);
      drag = { start: p, end: p };
    } else if (mode === "pan") panStart = q;
  }
});
c.addEventListener("pointermove", (e) => {
  if (!touches.has(e.pointerId)) return;
  e.preventDefault();
  touches.set(e.pointerId, rawPoint(e));
  if (touches.size >= 2) {
    if (!gesture) beginGesture();
    const m = touchMetrics();
    zoom = Math.max(0.16, Math.min(2.6, (gesture.zoom * m.dist) / gesture.dist));
    camX = m.x - gesture.worldX * zoom;
    camY = m.y - gesture.worldY * zoom;
    document.getElementById("zoomlevel").textContent = Math.round(zoom * 100) + "%";
    return;
  }
  if (gesture) return;
  const q = rawPoint(e);
  if (single) single.end = q;
  if (mode === "placegun")
    placementCursor = placementCandidate(e.clientX, e.clientY, selectedWeapon, "weapon");
  else if (mode === "placeresource")
    placementCursor = placementCandidate(e.clientX, e.clientY, selectedResource, "resource");
  if (
    mode === "shoot" &&
    single &&
    selectedGuns().length &&
    Math.hypot(q.x - single.start.x, q.y - single.start.y) > 15
  ) {
    const w = screenToWorld(q.x, q.y);
    updateAimTarget(w.x, w.y);
  }
  if (mode === "pan" && panStart) {
    camX += q.x - panStart.x;
    camY += q.y - panStart.y;
    panStart = q;
  } else if (drag) {
    drag.end = point(e);
    drag.end.y = Math.min(drag.end.y, floor());
  }
});
function endPointer(e) {
  if (!touches.has(e.pointerId)) return;
  e.preventDefault();
  if (!gesture && touches.size === 1) {
    if (single) single.end = rawPoint(e);
    finishSingle();
  }
  touches.delete(e.pointerId);
  if (touches.size < 2 && gesture) {
    gesture = null;
    single = null;
    drag = null;
    panStart = null;
  }
  if (touches.size === 0) {
    drag = null;
    panStart = null;
    single = null;
  }
}
c.addEventListener("pointerup", endPointer);
c.addEventListener("pointercancel", (e) => {
  touches.delete(e.pointerId);
  gesture = null;
  single = null;
  drag = null;
  panStart = null;
});
// Unfertige freie Baugruppen bleiben vorübergehend fixiert.
// Sobald eine geschlossene Bauform (Zyklus) oder Bodenverbindung entsteht, greift die Schwerkraft.
// Einmal aktivierte Baugruppen bleiben auch nach späterem Strebenbruch physikalisch aktiv.
function updateStructuralSupport() {
  // Construction assistance applies to new, unfinished joints only.
  // A joint becomes physical when it belongs to a closed brace loop or was
  // previously released. Existing physical joints never re-freeze after damage.
  const adjacency = nodes.map(() => []);
  beams.forEach((b, id) => {
    if (b.hp <= 0) return;
    adjacency[b.a]?.push({ to: b.b, id });
    adjacency[b.b]?.push({ to: b.a, id });
  });
  const disc = Array(nodes.length).fill(-1),
    low = Array(nodes.length).fill(0),
    bridges = new Set();
  let clock = 0;
  function dfs(v, parentEdge) {
    disc[v] = low[v] = clock++;
    for (const { to, id } of adjacency[v]) {
      if (id === parentEdge) continue;
      if (disc[to] < 0) {
        dfs(to, id);
        low[v] = Math.min(low[v], low[to]);
        if (low[to] > disc[v]) bridges.add(id);
      } else low[v] = Math.min(low[v], disc[to]);
    }
  }
  for (let i = 0; i < nodes.length; i++) if (disc[i] < 0) dfs(i, -1);
  const braced = new Set();
  beams.forEach((b, id) => {
    if (b.hp > 0 && !bridges.has(id)) {
      braced.add(b.a);
      braced.add(b.b);
    }
  });
  // A newly attached loose endpoint remains held while the player finishes
  // bracing it. Existing parts of the fort continue simulating throughout.
  nodes.forEach((n, i) => {
    if (n.fixed) {
      n.temporary = false;
      n.provisional = false;
      return;
    }
    if (braced.has(i) || n.everAnchored === true || n.provisional === false) {
      n.temporary = false;
      n.provisional = false;
      n.everAnchored = true;
    } else {
      n.temporary = true;
      n.px = n.x;
      n.py = n.y;
    }
  });
}
function playerTarget() {
  const own = beams.filter((b) => (b.owner || "player") === "player");
  if (own.length) {
    const b = own[Math.floor(Math.random() * own.length)];
    const a = nodes[b.a],
      d = nodes[b.b];
    return { x: (a.x + d.x) / 2, y: (a.y + d.y) / 2 };
  }
  return { x: 330, y: floor() - 100 };
}
// Corner braces preserve right angles without requiring visible diagonal beams.
// The braces are implicit and vanish when either supporting beam is destroyed.
function rigidCorners() {
  const attached = new Map();
  for (const b of beams) {
    if (b.hp <= 0 || (b.buildRemaining || 0) > 0) continue;
    for (const joint of [b.a, b.b]) {
      if (!attached.has(joint)) attached.set(joint, []);
      attached.get(joint).push({ beam: b, outer: joint === b.a ? b.b : b.a });
    }
  }
  const result = [];
  for (const [joint, arms] of attached) {
    for (let i = 0; i < arms.length; i++)
      for (let j = i + 1; j < arms.length; j++) {
        const p = nodes[arms[i].outer],
          q = nodes[arms[j].outer],
          c = nodes[joint];
        if (!p || !q || !c || arms[i].beam.owner !== arms[j].beam.owner) continue;
        const ax = p.homeX - c.homeX,
          ay = p.homeY - c.homeY,
          bx = q.homeX - c.homeX,
          by = q.homeY - c.homeY;
        const al = Math.hypot(ax, ay),
          bl = Math.hypot(bx, by);
        if (al < 1 || bl < 1 || Math.abs(ax * bx + ay * by) / (al * bl) > 0.18) continue;
        result.push({ a: arms[i].outer, b: arms[j].outer, len: Math.hypot(ax - bx, ay - by) });
      }
  }
  return result;
}

// V15.60: parts that hang on ONE beam or ONE joint fall down.
// A "part" is at least two beams that would lose all ground contact if that
// single beam/joint failed. Parts under construction (unbraced, temporary
// joints) and deliberate cantilevers that already existed before the damage
// (snapshot) are left alone – only what a hit newly leaves hanging collapses.
let fwHangSnapshot = new Set(),
  fwHangSnapAt = 0;
function fwHangingParts(owner) {
  const list = beams.filter((b) => (b.owner || "player") === owner && b.hp > 0 && !b.fwFalling);
  if (list.length < 3) return [];
  const adj = new Map();
  for (const b of list)
    for (const [u, v] of [
      [b.a, b.b],
      [b.b, b.a],
    ]) {
      if (!adj.has(u)) adj.set(u, []);
      adj.get(u).push({ to: v, beam: b });
    }
  const fixed = [...adj.keys()].filter((i) => nodes[i] && nodes[i].fixed);
  if (!fixed.length) return [];
  function reach(skipBeam, skipNode) {
    const seen = new Set(fixed.filter((i) => i !== skipNode)),
      stack = [...seen];
    while (stack.length) {
      const u = stack.pop();
      for (const { to, beam } of adj.get(u) || []) {
        if (beam === skipBeam || to === skipNode || seen.has(to)) continue;
        seen.add(to);
        stack.push(to);
      }
    }
    return seen;
  }
  const base = reach(null, -1);
  const parts = [],
    keys = new Set();
  function consider(cutNodes, links) {
    if (!cutNodes.size) return;
    for (const i of cutNodes) {
      const n = nodes[i];
      if (!n || n.temporary || n.provisional) return; // still under construction
    }
    const far = list.filter((b) => cutNodes.has(b.a) && cutNodes.has(b.b));
    if (far.length < 1) return;
    const all = [...far, ...links];
    const key = all
      .map((b) => b.id)
      .sort((x, y) => x - y)
      .join(",");
    if (keys.has(key)) return;
    keys.add(key);
    parts.push({ beams: all, links });
  }
  for (const e of list) {
    const r = reach(e, -1);
    const cut = new Set([...base].filter((i) => !r.has(i)));
    consider(cut, [e]);
  }
  for (const v of adj.keys()) {
    if (nodes[v] && nodes[v].fixed) continue;
    const r = reach(null, v);
    const cut = new Set([...base].filter((i) => i !== v && !r.has(i)));
    consider(cut, list.filter((b) => (b.a === v && cut.has(b.b)) || (b.b === v && cut.has(b.a))));
  }
  return parts;
}
// Set by explode() whenever a hit destroys beams. explode() removes dead beams
// immediately, so physics() would otherwise never notice the damage.
let fwPendingCollapse = false;
const fwPartKey = (part) =>
  part.beams
    .map((b) => b.id)
    .sort((x, y) => x - y)
    .join(",");
// Beams that end in a free joint (nothing else attached there).
function fwDanglingBeams(owner) {
  const list = beams.filter((b) => (b.owner || "player") === owner && b.hp > 0 && !b.fwFalling);
  const deg = new Map();
  for (const b of list) for (const i of [b.a, b.b]) deg.set(i, (deg.get(i) || 0) + 1);
  const out = [];
  for (const b of list) {
    const na = nodes[b.a],
      nb = nodes[b.b];
    if (!na || !nb) continue;
    const freeA = deg.get(b.a) === 1 && !na.fixed,
      freeB = deg.get(b.b) === 1 && !nb.fixed;
    if (freeA === freeB) continue; // attached at both ends, or a loose stick (handled elsewhere)
    const free = freeA ? b.a : b.b,
      held = freeA ? b.b : b.a;
    if (nodes[free].temporary || nodes[free].provisional) continue; // still being built
    out.push({ beam: b, held });
  }
  return out;
}
function fwRefreshHangSnapshot() {
  // Remember the shapes that exist WITHOUT damage (deliberate cantilevers, arms).
  // Only exact shapes are protected: once a hit changes a part, it falls.
  fwHangSnapshot = new Set();
  for (const owner of ["player", "enemy"]) {
    for (const part of fwHangingParts(owner)) fwHangSnapshot.add(fwPartKey(part));
    for (const d of fwDanglingBeams(owner)) fwHangSnapshot.add("d" + d.beam.id);
  }
  fwHangSnapAt = performance.now();
}
function fwCollapseHangingParts() {
  let broke = 0;
  for (const owner of ["player", "enemy"]) {
    for (const part of fwHangingParts(owner)) {
      if (fwHangSnapshot.has(fwPartKey(part))) continue; // existed exactly like this before the hit
      for (const link of part.links) {
        if (link.hp <= 0) continue;
        link.hp = 0;
        broke++;
        const a = nodes[link.a],
          d = nodes[link.b];
        if (!a || !d) continue;
        for (let i = 0; i < 10; i++) {
          const ang = Math.random() * Math.PI * 2,
            sp = 50 + Math.random() * 120;
          particles.push({
            x: (a.x + d.x) / 2,
            y: (a.y + d.y) / 2,
            vx: Math.cos(ang) * sp,
            vy: Math.sin(ang) * sp - 30,
            life: 0.35 + Math.random() * 0.45,
            maxLife: 0.9,
            kind: link.armorDoor || link.armorWall ? "spark" : "debris",
            size: 4 + Math.random() * 5,
          });
        }
      }
    }
    // A single beam that a hit left swinging from one joint breaks off there
    // (its end is given its own joint, so it falls and shatters like any loose piece).
    for (const { beam: b, held } of fwDanglingBeams(owner)) {
      if (fwHangSnapshot.has("d" + b.id)) continue;
      const h = nodes[held];
      const copy = { ...h, fixed: false, temporary: false, provisional: false, everAnchored: true };
      delete copy.fwId;
      nodes.push(copy);
      if (b.a === held) b.a = nodes.length - 1;
      else b.b = nodes.length - 1;
      broke++;
    }
  }
  return broke;
}
function destroyDetachedFortPieces() {
  // Any structural component no longer connected to a fixed/grounded node of its
  // own fort is considered lost and is destroyed as a whole.
  const aliveBeams = beams.filter((b) => b.hp > 0);
  if (!aliveBeams.length) return;
  for (const owner of ["player", "enemy"]) {
    const ownerBeams = aliveBeams.filter((b) => (b.owner || "player") === owner);
    if (!ownerBeams.length) continue;
    const nodeToBeams = new Map();
    for (const b of ownerBeams) {
      if (!nodeToBeams.has(b.a)) nodeToBeams.set(b.a, []);
      if (!nodeToBeams.has(b.b)) nodeToBeams.set(b.b, []);
      nodeToBeams.get(b.a).push(b);
      nodeToBeams.get(b.b).push(b);
    }
    const visited = new Set();
    for (const root of ownerBeams) {
      if (visited.has(root.id)) continue;
      const stack = [root],
        component = [];
      let anchored = false;
      while (stack.length) {
        const beam = stack.pop();
        if (visited.has(beam.id)) continue;
        visited.add(beam.id);
        component.push(beam);
        for (const ni of [beam.a, beam.b]) {
          const n = nodes[ni];
          if (n && n.fixed) anchored = true;
          for (const next of nodeToBeams.get(ni) || []) if (!visited.has(next.id)) stack.push(next);
        }
      }
      if (anchored) continue;
      // V15.60: a detached piece first FALLS (visible), then breaks apart on
      // impact with the ground or after 2.5 s at the latest.
      const now = performance.now();
      if (!component.every((b) => b.fwFalling)) {
        for (const b of component) {
          b.fwFalling = b.fwFalling || now;
          for (const ni of [b.a, b.b]) {
            const n = nodes[ni];
            if (n && !n.fixed) {
              n.temporary = false;
              n.provisional = false;
              n.everAnchored = true;
            }
          }
        }
        continue;
      }
      const started = Math.min(...component.map((b) => b.fwFalling));
      // lands on the ground – or on standing parts of a fort (no falling through walls)
      const comp = new Set(component);
      const solid = aliveBeams.filter((b) => !comp.has(b) && !b.fwFalling);
      const hitsSolid = (n) =>
        n.y - n.py > 0.4 &&
        solid.some((s) => {
          const p = nodes[s.a],
            q = nodes[s.b];
          if (!p || !q) return false;
          const vx = q.x - p.x,
            vy = q.y - p.y,
            t = Math.max(0, Math.min(1, ((n.x - p.x) * vx + (n.y - p.y) * vy) / (vx * vx + vy * vy || 1)));
          return Math.hypot(n.x - (p.x + vx * t), n.y - (p.y + vy * t)) < 7;
        });
      const landed = component.some((b) =>
        [nodes[b.a], nodes[b.b]].some((n) => n && (n.y >= floor() - 3 || (now - started > 300 && hitsSolid(n)))),
      );
      if (!landed && now - started < 2500) continue;
      if (landed) {
        const n0 = nodes[component[0].a];
        if (n0) {
          playImpactSound(component.length > 6 ? 90 : 50, component.length > 6 ? 120 : 80);
          fwImpactShake = Math.max(fwImpactShake || 0, Math.min(10, 2 + component.length * 0.5));
        }
      }
      for (const b of component) {
        const a = nodes[b.a],
          d = nodes[b.b],
          cx = ((a?.x || 0) + (d?.x || 0)) / 2,
          cy = ((a?.y || 0) + (d?.y || 0)) / 2;
        for (let i = 0; i < 9; i++) {
          const ang = Math.random() * Math.PI * 2,
            sp = 40 + Math.random() * 120;
          particles.push({
            x: cx,
            y: cy,
            vx: Math.cos(ang) * sp,
            vy: Math.sin(ang) * sp - 20,
            life: 0.35 + Math.random() * 0.45,
            maxLife: 0.9,
            kind: b.armorDoor || b.armorWall ? "spark" : "debris",
            size: b.armorDoor || b.armorWall ? 4 + Math.random() * 4 : 5 + Math.random() * 5,
          });
        }
        b.hp = 0;
      }
      const detachedIds = new Set(component.map((b) => b.id));
      for (const r of resources) if (detachedIds.has(r.beamId)) r.destroyed = true;
      for (const r of aiResources) if (detachedIds.has(r.beamId)) r.destroyed = true;
      for (const g of guns) if (detachedIds.has(g.beamId)) g.destroyed = true;
    }
  }
}
// Normalize contact on the surface actually selected by the crosshair.
// The earlier first-hit ordering is unchanged: intervening structures still block.
function fwReticleOnImpactBeam(shot, b) {
  if (!b || b.armorDoor || !Number.isFinite(shot.targetX) || !Number.isFinite(shot.targetY)) return false;
  const a = nodes[b.a],
    c = nodes[b.b];
  if (!a || !c) return false;
  const dx = c.x - a.x,
    dy = c.y - a.y,
    denom = dx * dx + dy * dy;
  const t = Math.max(0, Math.min(1, ((shot.targetX - a.x) * dx + (shot.targetY - a.y) * dy) / (denom || 1)));
  return Math.hypot(shot.targetX - (a.x + dx * t), shot.targetY - (a.y + dy * t)) <= Math.max(7, shot.r + 3);
}

// V15.16: Point defense is a separate layer of automatic fire. It does not
// alter existing offensive projectile arcs, explosion damage, or the target ring.
const FW_FLAK_RANGE = 385,
  FW_FLAK_SPEED = 1700,
  FW_FLAK_HIT_RADIUS = 15;
let fwFlakRounds = [],
  fwFlakBursts = [];
function fwFlakShotIsThreat(s, owner) {
  return (
    !!s &&
    s.life > 0 &&
    ["rocket", "mortar"].includes(s.weaponType) &&
    (s.enemy ? "enemy" : "player") !== owner &&
    !s.waitDoorIds?.length &&
    !s.volleyId &&
    !(s.launchDelay > 0)
  );
}
function fwMovingProjectilesTouch(a, s, r) {
  // Minimum distance of two MOVING points over a single simulation frame.
  const dx = a.px - s.px,
    dy = a.py - s.py;
  const vx = a.x - a.px - (s.x - s.px),
    vy = a.y - a.py - (s.y - s.py);
  const den = vx * vx + vy * vy;
  const t = den > 1e-8 ? Math.max(0, Math.min(1, -(dx * vx + dy * vy) / den)) : 0;
  const distance = Math.hypot(dx + vx * t, dy + vy * t);
  return distance <= r ? { x: s.px + (s.x - s.px) * t, y: s.py + (s.y - s.py) * t } : null;
}
function fwPointDefenseBurst(x, y) {
  fwFlakBursts.push({ x, y, life: 0.28, maxLife: 0.28 });
  for (let i = 0; i < 15; i++) {
    const a = Math.random() * Math.PI * 2,
      v = 35 + Math.random() * 160;
    particles.push({
      x,
      y,
      vx: Math.cos(a) * v,
      vy: Math.sin(a) * v - 20,
      life: 0.25 + Math.random() * 0.45,
      maxLife: 0.8,
      kind: i % 3 ? "spark" : "smoke",
      size: 2 + Math.random() * 3,
    });
  }
}
function updatePointDefense(dt) {
  const online = !!window.FWOnlineMatch;
  for (const g of guns) {
    if (g.type !== "flak" || (g.buildRemaining || 0) > 0 || g.destroyed || g.hp <= 0) continue;
    if (g.owner === "enemy" && !enemyOn && !online) continue;
    const beam = beams.find((b) => b.id === g.beamId);
    if (!beam || beam.hp <= 0 || (beam.buildRemaining || 0) > 0) continue;
    const p = weaponPosition(g);
    if (!p) continue;
    const activeShots = shots.filter(
      (s) => fwFlakShotIsThreat(s, g.owner) && Math.hypot(s.x - p.x, s.y - p.y) < FW_FLAK_RANGE,
    );
    activeShots.sort((a, b) => {
      // Prefer incoming shells already close to our buildings / reactor.
      const va = Math.hypot(a.x - p.x, a.y - p.y) - Math.hypot(a.vx, a.vy) * 0.16;
      const vb = Math.hypot(b.x - p.x, b.y - p.y) - Math.hypot(b.vx, b.vy) * 0.16;
      return va - vb;
    });
    const target = activeShots[0];
    g.flakTarget = target || null;
    if (!target || (g.cooldown || 0) > 0) continue;
    const bank = g.owner === "enemy" ? aiEnergy : energy;
    if (bank < WEAPONS.flak.energy) continue;
    let lead = Math.hypot(target.x - p.x, target.y - p.y) / FW_FLAK_SPEED;
    let aimX = target.x,
      aimY = target.y;
    for (let i = 0; i < 4; i++) {
      aimX = target.x + target.vx * lead;
      aimY = target.y + target.vy * lead + 0.5 * GRAV * 0.45 * lead * lead;
      lead = Math.hypot(aimX - p.x, aimY - p.y) / FW_FLAK_SPEED;
    }
    // Do not waste rounds at a predicted intercept outside defense range.
    if (!Number.isFinite(lead) || lead > 0.65 || Math.hypot(aimX - p.x, aimY - p.y) > FW_FLAK_RANGE + 65)
      continue;
    const angle = Math.atan2(aimY - p.y, aimX - p.x);
    g.angle = angle;
    const fx = p.x + Math.cos(angle) * 25,
      fy = p.y + Math.sin(angle) * 25 - 8;
    fwFlakRounds.push({
      x: fx,
      y: fy,
      px: fx,
      py: fy,
      vx: Math.cos(angle) * FW_FLAK_SPEED,
      vy: Math.sin(angle) * FW_FLAK_SPEED,
      owner: g.owner,
      target,
      life: 0.75,
    });
    if (g.owner === "enemy") aiEnergy -= WEAPONS.flak.energy;
    else energy -= WEAPONS.flak.energy;
    g.cooldown = WEAPONS.flak.reload;
    g.reloadTotal = WEAPONS.flak.reload;
    g.flash = 0.14;
    playWeaponSound("flak");
  }
  for (const round of fwFlakRounds) {
    if (round.life <= 0) continue;
    round.px = round.x;
    round.py = round.y;
    round.x += round.vx * dt;
    round.y += round.vy * dt;
    round.life -= dt;
    if (round.x < -20 || round.x > WORLD_W + 20 || round.y < 0 || round.y > floor() + 20) round.life = 0;
  }
  for (const burst of fwFlakBursts) burst.life -= dt;
  fwFlakBursts = fwFlakBursts.filter((b) => b.life > 0);
  fwFlakRounds = fwFlakRounds.filter((r) => r.life > 0 && r.target?.life > 0);
}
function fwTryInterceptShot(s) {
  if (!s.life || !["rocket", "mortar"].includes(s.weaponType)) return false;
  for (const round of fwFlakRounds) {
    if (round.life <= 0 || round.target !== s || round.owner === (s.enemy ? "enemy" : "player")) continue;
    const collision = fwMovingProjectilesTouch(round, s, FW_FLAK_HIT_RADIUS + (s.r || 4));
    if (!collision) continue;
    s.life = 0;
    round.life = 0;
    fwPointDefenseBurst(collision.x, collision.y);
    return true;
  }
  return false;
}
function drawFlakEffects() {
  ctx.save();
  for (const round of fwFlakRounds) {
    if (round.life <= 0) continue;
    ctx.strokeStyle = "#83e9df";
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.moveTo(round.x, round.y);
    ctx.lineTo(round.x - round.vx * 0.012, round.y - round.vy * 0.012);
    ctx.stroke();
    ctx.fillStyle = "#ffdfa0";
    ctx.beginPath();
    ctx.arc(round.x, round.y, 3, 0, Math.PI * 2);
    ctx.fill();
  }
  for (const b of fwFlakBursts) {
    const progress = 1 - b.life / b.maxLife;
    ctx.globalAlpha = Math.max(0, 1 - progress);
    ctx.strokeStyle = "#8eefe5";
    ctx.lineWidth = 2.8;
    ctx.beginPath();
    ctx.arc(b.x, b.y, 5 + progress * 24, 0, Math.PI * 2);
    ctx.stroke();
    ctx.strokeStyle = "#f3c57a";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(b.x, b.y, 2 + progress * 12, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();
}

function physics(dt) {
  if (cheatMode) {
    metal = CHEAT_SUPPLY;
    energy = CHEAT_SUPPLY;
  }
  updateResearch(dt);
  for (const b of beams) if (b.buildRemaining > 0) b.buildRemaining = Math.max(0, b.buildRemaining - dt);
  for (const r of [...resources, ...aiResources]) {
    if (r.buildRemaining > 0 && beams.some((b) => b.id === r.beamId && (b.buildRemaining || 0) <= 0))
      r.buildRemaining = Math.max(0, r.buildRemaining - dt);
  }
  for (const g of guns) {
    if (g.buildRemaining > 0) {
      const available = g.owner === "enemy" ? aiResources : resources;
      const alive =
        (cheatMode && g.owner === "player") ||
        available.some(
          (r) =>
            r.type === "workshop" &&
            (r.buildRemaining || 0) <= 0 &&
            beams.some((b) => b.id === r.beamId && (b.buildRemaining || 0) <= 0),
        );
      if (alive) g.buildRemaining = Math.max(0, g.buildRemaining - dt);
    }
  }
  if (!gameOver) fwMatchTime += dt;
  if (
    !cheatMode &&
    !gameOver &&
    !resources.some(
      (r) =>
        r.owner === "player" &&
        r.type === "mine" &&
        (r.buildRemaining || 0) <= 0 &&
        beams.some((b) => b.id === r.beamId && b.hp > 0),
    ) &&
    metal < RESOURCE_TYPES.mine.cost
  ) {
    metal = Math.min(RESOURCE_TYPES.mine.cost, metal + dt * FW_EMERGENCY_METAL);
  }
  resourceTimer += dt;
  if (resourceTimer >= 1) {
    resourceTimer -= 1;
    metal = cheatMode
      ? CHEAT_SUPPLY
      : Math.min(
          FW_RESOURCE_CAP,
          metal +
            resources.filter((r) => r.owner === "player" && r.type === "mine" && (r.buildRemaining || 0) <= 0)
              .length *
              RESOURCE_TYPES.mine.rate,
        );
    energy = cheatMode
      ? CHEAT_SUPPLY
      : Math.min(
          FW_RESOURCE_CAP,
          energy +
            resources.filter((r) => r.owner === "player" && r.type === "wind" && (r.buildRemaining || 0) <= 0)
              .length *
              RESOURCE_TYPES.wind.rate,
        );
    hud();
  }
  if (enemyOn && !gameOver) {
    updateEnemyAI(dt);
  }
  updateStructuralSupport();
  const corners = rigidCorners();
  let old = nodes.map((n) => ({ x: n.x, y: n.y }));
  for (let n of nodes) {
    if (n.fixed || n.temporary) continue;
    let vx = (n.x - n.px) * 0.994,
      vy = (n.y - n.py) * 0.994;
    n.px = n.x;
    n.py = n.y;
    n.x += vx;
    n.y += vy + GRAV * dt * dt;
    n.x = Math.max(6, Math.min(WORLD_W - 6, n.x));
    if (n.y > floor()) {
      n.y = floor();
      n.py = n.y;
    }
  }
  for (let k = 0; k < 24; k++) {
    for (let b of beams) {
      let a = nodes[b.a],
        d = nodes[b.b],
        dx = d.x - a.x,
        dy = d.y - a.y,
        len = Math.hypot(dx, dy) || 1,
        err = (len - b.len) / len,
        moveX = dx * err,
        moveY = dy * err;
      if (!a.fixed && !a.temporary && !d.fixed && !d.temporary) {
        a.x += moveX * 0.5;
        a.y += moveY * 0.5;
        d.x -= moveX * 0.5;
        d.y -= moveY * 0.5;
      } else if (!a.fixed && !a.temporary) {
        a.x += moveX;
        a.y += moveY;
      } else if (!d.fixed && !d.temporary) {
        d.x -= moveX;
        d.y -= moveY;
      }
      if (k === 13 && Math.abs(len - b.len) > b.len * 0.4) b.hp -= 0.15;
    } // Reinforce square/rectangular joints by maintaining the diagonal distance
    // between the ends of two initially perpendicular connected beams.
    for (const brace of corners) {
      const a = nodes[brace.a],
        d = nodes[brace.b];
      if (!a || !d) continue;
      const dx = d.x - a.x,
        dy = d.y - a.y,
        len = Math.hypot(dx, dy) || 1;
      const err = (len - brace.len) / len,
        fx = dx * err * 0.24,
        fy = dy * err * 0.24;
      const am = !a.fixed && !a.temporary,
        dm = !d.fixed && !d.temporary;
      if (am && dm) {
        a.x += fx;
        a.y += fy;
        d.x -= fx;
        d.y -= fy;
      } else if (am) {
        a.x += fx * 2;
        a.y += fy * 2;
      } else if (dm) {
        d.x -= fx * 2;
        d.y -= fy * 2;
      }
    }
    // No attraction to original build coordinates: damaged beams and unsupported
    // cantilevers must respond to gravity. Beam-length constraints above provide
    // structural stiffness; closed triangles are rigid through their geometry.
    for (let n of nodes)
      if (n.y > floor()) {
        n.y = floor();
        n.py = Math.min(n.py, floor());
      }
  }
  const fwDamagedThisFrame = fwPendingCollapse || beams.some((b) => b.hp <= 0 && !b.fwFalling);
  fwPendingCollapse = false;
  if (fwDamagedThisFrame) fwCollapseHangingParts();
  destroyDetachedFortPieces();
  beams = beams.filter((b) => b.hp > 0);
  cleanNodes();
  updateStructuralSupport();
  if (!fwDamagedThisFrame && performance.now() - fwHangSnapAt > 400) fwRefreshHangSnapshot();
  updatePointDefense(dt);
  for (const salvoShot of shots) salvoShot.volleyCheckedThisFrame = false;
  for (let s of shots) {
    // V14.30: Atomic salvo gate. A volley is evaluated and released as a unit,
    // never one projectile at a time while iterating through the shots array.
    if (s.volleyId) {
      const volley = shots.filter((other) => other.volleyId === s.volleyId && other.life > 0);
      if (!volley.length) continue;
      const id = s.volleyId;
      // Once per frame, evaluated on the first shot only; the result is shared.
      if (volley[0] === s) {
        let ready = true;
        for (const other of volley) {
          for (const doorId of other.waitDoorIds || []) {
            const door = beams.find((b) => b.id === doorId);
            if (!door || !door.armorDoor || door.hp <= 0) continue;
            door.doorTimer = Math.max(door.doorTimer || 0, 1.2);
            if ((door.doorProgress || 0) < 0.999 || !safeDoorArc(other, door, false)) ready = false;
          }
        }
        if (ready) ready = volley.every((other) => safeVolleyRelease(other));
        const elapsed = ready ? (volley[0].volleyReadyTime || 0) + dt : 0;
        for (const other of volley) other.volleyReadyTime = elapsed;
        if (elapsed >= 0.18) {
          // The release happens for every gun in this same simulation tick.
          for (const other of volley) {
            other.volleyId = null;
            other.waitDoorIds = [];
            other.waitGunId = null;
            other.waitGunType = null;
            other.doorFullyOpenTime = 0.18;
            const gun = guns[other.sourceGunIndex];
            if (gun) gun.flash = 0.13;
            playWeaponSound(gun?.type || "cannon");
          }
        }
      }
      if (s.volleyId === id) continue;
    }
    // All doors on the ballistic path must finish opening before the shot exists in flight.
    if (s.waitDoorIds?.length) {
      let allOpen = true;
      for (const id of s.waitDoorIds) {
        const door = beams.find((b) => b.id === id);
        if (door && door.armorDoor && door.hp > 0) {
          door.doorTimer = Math.max(door.doorTimer || 0, 0.8);
          if ((door.doorProgress || 0) < 0.999) allOpen = false;
        }
      }
      if (!allOpen) {
        s.doorFullyOpenTime = 0;
        continue;
      }
      // Final clearance check, including the remaining end plates.
      if (!safeVolleyRelease(s)) {
        s.life = 0;
        continue;
      }
      s.doorFullyOpenTime = (s.doorFullyOpenTime || 0) + dt;
      if (s.doorFullyOpenTime < 0.18) continue;
      s.waitDoorIds = [];
      const firingGun = guns.find((g) => g.id === s.waitGunId);
      if (firingGun) firingGun.flash = 0.13;
      playWeaponSound(s.waitGunType || "cannon");
      for (let i = 0; i < 6; i++) {
        const a = Math.atan2(s.vy, s.vx) + (Math.random() - 0.5) * 1.5,
          sp = 22 + Math.random() * 55;
        particles.push({
          x: s.x,
          y: s.y,
          vx: Math.cos(a) * sp,
          vy: Math.sin(a) * sp - 15,
          life: 0.45 + Math.random() * 0.6,
          maxLife: 1.05,
          kind: "smoke",
          muzzleOwner: s.enemy ? "enemy" : "player",
          size: 7 + Math.random() * 7,
        });
      }
      s.waitGunId = null;
      s.waitGunType = null;
    }
    if ((s.launchDelay || 0) > 0) {
      s.launchDelay = Math.max(0, s.launchDelay - dt);
      continue;
    }
    s.px = s.x;
    s.py = s.y;
    s.x += s.vx * dt;
    s.y += s.vy * dt + 0.5 * GRAV * 0.45 * dt * dt;
    s.vy += GRAV * 0.45 * dt;
    s.life -= dt;
    if (!s.enemy && s.trail) {
      const n = s.trail.length;
      if (Math.hypot(s.x - s.trail[n - 2], s.y - s.trail[n - 1]) > 10) s.trail.push(s.x, s.y);
    }
    if (fwTryInterceptShot(s)) continue;
    let impact = null,
      firstT = 2;
    // Sweep the whole projectile path so fast shots cannot tunnel through beams.
    // Only player-built armor doors block shots; weapons have no attached armor.
    for (const b of beams) {
      if (b.background || b.id === s.mountBeamId) continue;
      const a = nodes[b.a],
        d = nodes[b.b];
      if (b.armorDoor) {
        // Two sliding plates separate from the center; the opening is truly passable.
        const opening = (b.doorProgress || 0) * 1.0;
        const left = (1 - opening) / 2,
          right = (1 + opening) / 2;
        const pieces = [
          [0, left],
          [right, 1],
        ];
        for (const [t0, t1] of pieces) {
          if (t1 - t0 < 0.01) continue;
          const hit = segmentHit(
            s.px,
            s.py,
            s.x,
            s.y,
            a.x + (d.x - a.x) * t0,
            a.y + (d.y - a.y) * t0,
            a.x + (d.x - a.x) * t1,
            a.y + (d.y - a.y) * t1,
            s.r + 6,
          );
          if (hit && hit.t < firstT) {
            firstT = hit.t;
            impact = hit;
            impact.hitBeam = b;
          }
        }
        continue;
      }
      const hit = segmentHit(s.px, s.py, s.x, s.y, a.x, a.y, d.x, d.y, s.r + 5);
      if (hit && hit.t < firstT) {
        firstT = hit.t;
        impact = hit;
        impact.hitBeam = b;
      }
    }
    // Weapons are solid: a shell cannot pass through another gun, including allies.
    // Ignore only the gun that fired this shell.
    for (let gi = 0; gi < guns.length; gi++) {
      if (gi === s.sourceGunIndex) continue;
      const gun = guns[gi],
        pos = weaponPosition(gun);
      if (!pos || (gun.hp || 130) <= 0) continue;
      const hit = segmentHit(s.px, s.py, s.x, s.y, pos.x - 21, pos.y - 13, pos.x + 21, pos.y + 13, s.r + 6);
      if (hit && hit.t < firstT) {
        firstT = hit.t;
        impact = hit;
        impact.hitGun = gun;
      }
    }
    for (const core of [playerCore, enemyCore]) {
      if (!core || core.dead || (s.enemy && core.owner === "enemy") || (!s.enemy && core.owner === "player"))
        continue;
      const hit = segmentHit(s.px, s.py, s.x, s.y, core.x, core.y - 27, core.x, core.y + 27, s.r + 19);
      if (hit && hit.t < firstT) {
        firstT = hit.t;
        impact = hit;
        impact.hitCore = core;
      }
    }
    if (s.y >= floor()) {
      const t = (floor() - s.py) / (s.y - s.py || 1);
      if (t >= 0 && t <= 1 && t < firstT) {
        impact = { x: s.px + (s.x - s.px) * t, y: floor() };
        firstT = t;
      }
    }
    if (impact) {
      if (!s.enemy) {
        const ownHit = impact.hitBeam?.owner === "player" || impact.hitGun?.owner === "player";
        const enemyHit =
          impact.hitBeam?.owner === "enemy" ||
          impact.hitGun?.owner === "enemy" ||
          impact.hitCore?.owner === "enemy";
        if (ownHit) fwOwnHit(impact.hitBeam || null);
        else if (enemyHit) {
          hits++;
          document.getElementById("hits").textContent = hits;
          fwStatAdd("hits", 1);
        }
      } else {
        // online: count the guest's hits (shown on the guest's HUD)
        if (
          window.FWOnlineMatch &&
          (impact.hitBeam?.owner === "player" || impact.hitGun?.owner === "player" || impact.hitCore?.owner === "player")
        )
          fwGuestHits++;
        if (impact.hitCore?.owner === "player" || Math.hypot(impact.x - playerCore.x, impact.y - playerCore.y) < 160)
          fwVibrate(35);
      }
      s.x = impact.x;
      s.y = impact.y;
      if (!s.enemy && s.trail) fwRememberShot(s);
      if (impact.hitGun) {
        impact.hitGun.maxHp = getGunMaxHp(impact.hitGun);
        impact.hitGun.hp = (impact.hitGun.hp ?? impact.hitGun.maxHp) - (s.damage || 30);
        if (impact.hitGun.hp <= 0) impact.hitGun.destroyed = true;
      }
      explode(s.x, s.y, s.damage || 115, s.radius || 95);
      s.life = 0;
    }
  }
  for (const b of beams)
    if (b.armorDoor) {
      b.doorTimer = Math.max(0, (b.doorTimer || 0) - dt);
      const target = b.doorTimer > 0 ? 1 : 0;
      b.doorProgress = Math.max(
        0,
        Math.min(
          1,
          (b.doorProgress || 0) +
            Math.sign(target - (b.doorProgress || 0)) *
              Math.min(Math.abs(target - (b.doorProgress || 0)), dt * 4),
        ),
      );
    }
  for (const g of guns) {
    g.doorTimer = Math.max(0, (g.doorTimer || 0) - dt);
    g.flash = Math.max(0, g.flash - dt);
    g.cooldown = Math.max(0, (g.cooldown || 0) - dt);
  }
  updatePlayerAutocannons(dt);
  updateRepairDevices(dt);
  resources = resources.filter((r) => !r.destroyed && beams.some((b) => b.id === r.beamId && b.hp > 0));
  aiResources = aiResources.filter((r) => !r.destroyed && beams.some((b) => b.id === r.beamId && b.hp > 0));
  guns = guns.filter((g) => !g.destroyed && beams.some((b) => b.id === g.beamId && b.hp > 0));
  shots = shots.filter((s) => s.life > 0 && s.x < WORLD_W + 50 && s.y < WORLD_H + 100);
  fwFlakRounds = fwFlakRounds.filter((r) => r.life > 0 && r.target?.life > 0);
  particles.forEach((p) => {
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.vy += (p.kind === "smoke" ? -100 : p.kind === "spark" ? 150 : 300) * dt;
    p.vx *= p.kind === "smoke" ? 0.985 : 0.996;
    p.life -= dt;
  });
  particles = particles.filter((p) => p.life > 0).slice(-360);
  fwUpdateBeamCount();
} // Resolve the first visible structural reaction in the same impact frame.
// Subsequent physics frames continue the collapse naturally.
function settleImpactStructure(x, y, radius) {
  const nearby = nodes
    .map((n, i) => ({ n, i }))
    .filter((o) => !o.n.fixed && !o.n.temporary && Math.hypot(o.n.x - x, o.n.y - y) < radius + 260);
  if (!nearby.length) return;
  const affected = new Set(nearby.map((o) => o.i));
  for (let pass = 0; pass < 5; pass++) {
    for (const { n } of nearby) {
      n.y += 1.6;
      if (n.y > floor()) n.y = floor();
    }
    for (const b of beams) {
      if (b.hp <= 0 || (b.buildRemaining || 0) > 0 || (!affected.has(b.a) && !affected.has(b.b))) continue;
      const a = nodes[b.a],
        d = nodes[b.b];
      if (!a || !d) continue;
      const dx = d.x - a.x,
        dy = d.y - a.y,
        len = Math.hypot(dx, dy) || 1;
      const delta = (len - b.len) / len,
        fx = dx * delta * 0.4,
        fy = dy * delta * 0.4;
      const am = !a.fixed && !a.temporary,
        dm = !d.fixed && !d.temporary;
      if (am) {
        a.x += fx * (dm ? 0.5 : 1);
        a.y += fy * (dm ? 0.5 : 1);
      }
      if (dm) {
        d.x -= fx * (am ? 0.5 : 1);
        d.y -= fy * (am ? 0.5 : 1);
      }
    }
  }
  for (const { n } of nearby) {
    n.px = n.x;
    n.py = n.y;
  }
}
// V15.04 — purely visual impact effects; no gameplay damage or collision changes.
let fwImpactShake = 0,
  fwImpactShakePhase = 0;
function fwSpawnHitMaterial(x, y, material, strength, destroyed = false) {
  const n = destroyed ? 18 : Math.max(4, Math.min(12, Math.round(strength / 14)));
  for (let i = 0; i < n; i++) {
    const a = Math.random() * Math.PI * 2,
      speed = (destroyed ? 75 : 35) + Math.random() * (destroyed ? 220 : 155);
    const kind = material === "metal" ? "metalShard" : "woodShard";
    particles.push({
      x: x + (Math.random() - 0.5) * 10,
      y: y + (Math.random() - 0.5) * 10,
      vx: Math.cos(a) * speed,
      vy: Math.sin(a) * speed - 35,
      life: 0.35 + Math.random() * 0.65,
      maxLife: 1.0,
      kind,
      size: (material === "metal" ? 3 : 5) + Math.random() * 7,
      angle: a,
      spin: (Math.random() - 0.5) * 12,
    });
  }
  for (let i = 0; i < (material === "metal" ? 9 : 5); i++) {
    const a = Math.random() * Math.PI * 2,
      v = 70 + Math.random() * 190;
    particles.push({
      x,
      y,
      vx: Math.cos(a) * v,
      vy: Math.sin(a) * v - 50,
      life: 0.2 + Math.random() * 0.35,
      maxLife: 0.55,
      kind: material === "metal" ? "metalSpark" : "dust",
      size: 2 + Math.random() * 5,
    });
  }
}
function fwImpactVisual(x, y, damage, radius) {
  fwImpactShake = Math.max(fwImpactShake, Math.min(10, 2 + damage * 0.038));
  fwImpactShakePhase = Math.random() * 100;
  for (let i = 0; i < 19; i++) {
    const a = Math.random() * Math.PI * 2,
      sp = 20 + Math.random() * 105;
    particles.push({
      x: x + (Math.random() - 0.5) * 22,
      y: y + (Math.random() - 0.5) * 14,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp - 60,
      life: 0.28 + Math.random() * 0.48,
      maxLife: 0.76,
      kind: "dust",
      size: 5 + Math.random() * 10,
    });
  }
}
function explode(x, y, damage = 115, radius = 95) {
  playImpactSound(damage, radius);
  coreDamage(x, y, damage, radius);
  for (let b of beams) {
    let a = nodes[b.a],
      d = nodes[b.b],
      vx = d.x - a.x,
      vy = d.y - a.y,
      t = Math.max(0, Math.min(1, ((x - a.x) * vx + (y - a.y) * vy) / (vx * vx + vy * vy || 1))),
      hx = a.x + t * vx,
      hy = a.y + t * vy,
      dist = Math.hypot(x - hx, y - hy);
    if (dist < radius) {
      const fwHit = damage * (1 - dist / (radius + 15));
      const fwBefore = b.hp;
      if (fwBefore > 0 && fwHit > 9 && Math.random() < 0.72)
        fwSpawnHitMaterial(hx, hy, b.armorWall || b.armorDoor ? "metal" : "wood", fwHit, fwBefore <= fwHit);
      b.repairBlockedUntil = performance.now() + 4000;
      b.maxHp = getBeamMaxHp(b);
      b.hp -= fwHit;
      if (b.hp <= 0) {
        for (const id of [b.a, b.b])
          if (nodes[id] && !nodes[id].fixed) ((nodes[id].temporary = false), (nodes[id].grace = 0));
      }
    }
  }
  for (const r of [...resources, ...aiResources]) {
    const p = getResourceWorldPos(r);
    if (!p) continue;
    const dist = Math.hypot(x - p.x, y - p.y);
    if (dist < radius + 18) damageResource(r, damage * Math.max(0.18, 1 - dist / (radius + 18)) * 0.45);
  }
  for (const g of guns) {
    const p = weaponPosition(g);
    if (!p) continue;
    const dist = Math.hypot(x - p.x, y - p.y);
    if (dist < radius + 18) damageGun(g, damage * Math.max(0.18, 1 - dist / (radius + 18)) * 0.42);
  }
  if (beams.some((b) => b.hp <= 0)) fwPendingCollapse = true; // physics() checks for hanging parts
  /* Remove destroyed beams in the impact frame, not at the next physics tick. */ beams = beams.filter(
    (b) => b.hp > 0,
  );
  resources = resources.filter((r) => !r.destroyed && beams.some((b) => b.id === r.beamId && b.hp > 0));
  aiResources = aiResources.filter((r) => !r.destroyed && beams.some((b) => b.id === r.beamId && b.hp > 0));
  guns = guns.filter((g) => !g.destroyed && beams.some((b) => b.id === g.beamId && b.hp > 0));
  for (let n of nodes) {
    let dx = n.x - x,
      dy = n.y - y,
      dist = Math.hypot(dx, dy) || 1;
    if (!n.fixed && dist < radius + 35) {
      n.temporary = false;
      n.provisional = false;
      n.grace = 0;
      let impulse = (1 - dist / (radius + 35)) * 34;
      n.px -= (dx / dist) * impulse;
      n.py -= (dy / dist) * impulse;
    }
  }
  updateStructuralSupport();
  settleImpactStructure(x, y, radius);
  fwImpactVisual(x, y, damage, radius);
  for (let i = 0; i < 36; i++) {
    let angle = Math.random() * Math.PI * 2,
      speed = 35 + Math.random() * 300;
    particles.push({
      x,
      y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      life: 0.35 + Math.random() * 0.95,
      maxLife: 1.3,
      kind: i < 12 ? "smoke" : i < 25 ? "spark" : "debris",
      size: 3 + Math.random() * 13,
    });
  }
  particles.push({ x, y, vx: 0, vy: 0, life: 0.38, maxLife: 0.38, kind: "shockwave", size: radius * 0.9 });
}
// Each new match gets a different visual battlefield. No changes to gameplay physics.
const BATTLEFIELDS = [
  {
    name: "Alpen",
    top: "#18334f",
    mid: "#64819a",
    horizon: "#f2c49a",
    bottom: "#7da2a5",
    ridges: ["#8fa2b4", "#648392", "#375f69"],
    soil: "#6a7858",
    vegetation: "#2d595d",
    sun: "#ffeab8",
    weather: "clear",
  },
  {
    name: "Wüstenklippen",
    top: "#2f4157",
    mid: "#9e6d58",
    horizon: "#ffc28b",
    bottom: "#d89464",
    ridges: ["#bf9178", "#a96d55", "#7d4a3f"],
    soil: "#9f714f",
    vegetation: "#6e5d40",
    sun: "#ffe0aa",
    weather: "clear",
  },
  {
    name: "Nebelwald",
    top: "#213949",
    mid: "#5d7a81",
    horizon: "#b6c0b5",
    bottom: "#86a59a",
    ridges: ["#96a8a5", "#698582", "#416460"],
    soil: "#4f6b5b",
    vegetation: "#204b44",
    sun: "#e7efe1",
    weather: "mist",
  },
  {
    name: "Gewitterfront",
    top: "#0d182d",
    mid: "#35465a",
    horizon: "#8b92a2",
    bottom: "#667786",
    ridges: ["#6c7889", "#4c5f73", "#2b4757"],
    soil: "#404d55",
    vegetation: "#24434d",
    sun: "#d2def0",
    weather: "rain",
  },
];
let battlefield = BATTLEFIELDS[0],
  weatherTime = 0;
function chooseBattlefield() {
  battlefield = BATTLEFIELDS[Math.floor(Math.random() * BATTLEFIELDS.length)];
  weatherTime = 0;
}
function drawSceneryAtmosphere(b) {
  ctx.save();
  const g = floor();
  const desert = b.name === "Wüstenklippen";
  const alpine = b.name === "Alpen";
  const storm = b.weather === "rain";
  const mist = b.weather === "mist";
  for (let layer = 0; layer < 3; layer++) {
    const y = 155 + layer * 82;
    for (let i = 0; i < 10; i++) {
      const x = -320 + i * 355 + Math.sin(i * 2.4 + layer * 0.9) * 70;
      const rx = 120 + layer * 28 + (i % 3) * 18;
      const ry = 34 + layer * 6 + (i % 2) * 8;
      const cloud = ctx.createRadialGradient(x, y, 8, x, y, rx);
      const a = storm ? 0.11 : mist ? 0.1 : 0.085 - layer * 0.012;
      cloud.addColorStop(0, "rgba(255,250,244," + (a + 0.02) + ")");
      cloud.addColorStop(0.55, "rgba(240,242,244," + a + ")");
      cloud.addColorStop(1, "rgba(240,242,244,0)");
      ctx.fillStyle = cloud;
      ctx.beginPath();
      ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  const glow = ctx.createLinearGradient(0, 400, 0, g);
  glow.addColorStop(0, "rgba(255,240,216,0)");
  glow.addColorStop(
    0.55,
    desert ? "rgba(255,200,132,.08)" : alpine ? "rgba(214,236,255,.09)" : "rgba(235,217,188,.085)",
  );
  glow.addColorStop(1, "rgba(255,240,216,0)");
  ctx.fillStyle = glow;
  ctx.fillRect(-600, 350, 4200, g - 320);
  for (let j = 0; j < 4; j++) {
    const y = 640 + j * 90;
    const grad = ctx.createLinearGradient(0, y - 40, 0, y + 82);
    grad.addColorStop(0, "rgba(226,238,236,0)");
    grad.addColorStop(0.45, mist ? "rgba(228,240,237,.17)" : "rgba(228,240,237,.10)");
    grad.addColorStop(1, "rgba(228,240,237,0)");
    ctx.fillStyle = grad;
    ctx.fillRect(-700, y - 40, 4300, 122);
  }
  if (!storm && !desert) {
    ctx.strokeStyle = "rgba(35,48,56,.25)";
    ctx.lineWidth = 1.5;
    for (let i = 0; i < 8; i++) {
      const x = 260 + i * 245 + (i % 2) * 35;
      const y = 165 + (i % 3) * 28;
      ctx.beginPath();
      ctx.arc(x, y, 10, Math.PI * 0.08, Math.PI * 0.92);
      ctx.arc(x + 18, y, 10, Math.PI * 0.08, Math.PI * 0.92);
      ctx.stroke();
    }
  }
  if (!desert) {
    for (let layer = 0; layer < 2; layer++) {
      for (let i = 0; i < 88; i++) {
        const x = i * 33 - 135 + Math.sin(i * 1.43 + layer) * 10;
        const ground = (layer === 0 ? 930 : 1006) + Math.sin(i * 0.47 + layer) * 16;
        const h = (layer === 0 ? 36 : 54) + ((i * 19) % 27);
        ctx.strokeStyle = layer === 0 ? "rgba(26,51,51,.20)" : "rgba(14,38,42,.42)";
        ctx.lineWidth = 2.1;
        ctx.beginPath();
        ctx.moveTo(x, ground);
        ctx.lineTo(x, ground - h * 0.72);
        ctx.stroke();
        ctx.fillStyle = layer === 0 ? "rgba(133,173,154,.15)" : "rgba(41,88,82,.22)";
        ctx.beginPath();
        ctx.moveTo(x, ground - h * 0.88);
        ctx.lineTo(x - h * 0.16, ground - h * 0.34);
        ctx.lineTo(x - h * 0.06, ground - h * 0.5);
        ctx.lineTo(x + h * 0.06, ground - h * 0.5);
        ctx.lineTo(x + h * 0.16, ground - h * 0.34);
        ctx.closePath();
        ctx.fill();
      }
    }
  }
  for (let i = 0; i < 55; i++) {
    const x = -110 + i * 58 + ((i * 17) % 21),
      y = g - 2 + (i % 3) * 2;
    if (desert) {
      ctx.fillStyle = "rgba(86,71,55,.26)";
      ctx.beginPath();
      ctx.ellipse(x, y, 4 + (i % 3), 2 + (i % 2), 0, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.fillStyle = "rgba(17,37,42,.12)";
      ctx.beginPath();
      ctx.ellipse(x, y, 4 + (i % 3), 2 + (i % 2), 0, 0, Math.PI * 2);
      ctx.fill();
      if (i % 7 === 0) {
        ctx.fillStyle = "rgba(223,210,152,.18)";
        ctx.fillRect(x - 1, y - 7, 2, 4);
      }
    }
  }
  ctx.restore();
}
// V14.91: strong readable landscape silhouettes even on phones at 24% zoom.
// Decorative only: does not modify terrain, collision, weapons or AI.
function drawLandmarkScenery(b) {
  ctx.save();
  const desert = b.name === "Wüstenklippen";
  const alpine = b.name === "Alpen";
  const ground = floor();
  const bloom = ctx.createRadialGradient(1650, ground - 335, 20, 1650, ground - 335, 720);
  bloom.addColorStop(
    0,
    desert ? "rgba(255,211,150,.26)" : alpine ? "rgba(215,239,255,.24)" : "rgba(255,223,176,.22)",
  );
  bloom.addColorStop(
    0.55,
    desert ? "rgba(247,176,109,.10)" : alpine ? "rgba(180,214,255,.10)" : "rgba(255,210,160,.10)",
  );
  bloom.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = bloom;
  ctx.fillRect(-800, 120, 4700, 1100);
  for (let layer = 0; layer < 3; layer++) {
    const base = ground - (layer === 0 ? 250 : layer === 1 ? 165 : 92);
    ctx.beginPath();
    ctx.moveTo(-650, ground);
    for (let x = -650; x <= 3600; x += 24) {
      const y =
        base -
        28 * Math.sin(x * 0.0051 + layer * 1.8) -
        18 * Math.sin(x * 0.011 + layer * 0.7) -
        8 * Math.cos(x * 0.022 + layer * 1.3) +
        (layer === 2 ? Math.sin(x * 0.032) * 4 : 0);
      ctx.lineTo(x, y);
    }
    ctx.lineTo(3600, ground);
    ctx.closePath();
    ctx.fillStyle =
      layer === 0
        ? desert
          ? "rgba(121,82,63,.34)"
          : alpine
            ? "rgba(92,120,139,.30)"
            : "rgba(64,108,98,.30)"
        : layer === 1
          ? desert
            ? "rgba(92,63,50,.47)"
            : alpine
              ? "rgba(63,93,115,.44)"
              : "rgba(38,83,79,.44)"
          : desert
            ? "rgba(63,48,42,.62)"
            : alpine
              ? "rgba(42,71,91,.60)"
              : "rgba(26,65,63,.62)";
    ctx.fill();
  }
  for (let i = 0; i < 9; i++) {
    const x = 130 + i * 345 + Math.sin(i * 2.7) * 52;
    const y = ground - 110 + (i % 2) * 12;
    const h = desert ? 150 + (i % 3) * 46 : alpine ? 138 + (i % 3) * 52 : 88 + (i % 3) * 34;
    if (desert) {
      ctx.fillStyle = "rgba(79,58,50,.74)";
      ctx.beginPath();
      ctx.moveTo(x - 44, y + 48);
      ctx.lineTo(x - 30, y - h * 0.55);
      ctx.lineTo(x - 12, y - h);
      ctx.lineTo(x + 20, y - h * 0.88);
      ctx.lineTo(x + 36, y - h * 0.42);
      ctx.lineTo(x + 54, y + 48);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "rgba(237,208,174,.16)";
      ctx.beginPath();
      ctx.moveTo(x - 13, y - h);
      ctx.lineTo(x + 3, y - h * 0.88);
      ctx.lineTo(x - 11, y - h * 0.2);
      ctx.lineTo(x - 25, y - h * 0.5);
      ctx.closePath();
      ctx.fill();
    } else if (alpine) {
      ctx.fillStyle = "rgba(55,85,104,.66)";
      ctx.beginPath();
      ctx.moveTo(x - 72, y + 52);
      ctx.lineTo(x - 18, y - h * 0.58);
      ctx.lineTo(x + 1, y - h);
      ctx.lineTo(x + 24, y - h * 0.68);
      ctx.lineTo(x + 76, y + 52);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "rgba(242,248,252,.42)";
      ctx.beginPath();
      ctx.moveTo(x - 5, y - h * 0.96);
      ctx.lineTo(x + 15, y - h * 0.72);
      ctx.lineTo(x + 2, y - h * 0.61);
      ctx.lineTo(x - 18, y - h * 0.78);
      ctx.closePath();
      ctx.fill();
    } else {
      ctx.fillStyle = "rgba(27,63,60,.56)";
      ctx.fillRect(x - 10, y - h * 0.62, 20, h * 0.62);
      for (let t = 0; t < 4; t++) {
        const top = y - h + t * h * 0.18,
          w = 58 - t * 9;
        ctx.fillStyle = t < 2 ? "rgba(33,82,74,.56)" : "rgba(18,56,54,.64)";
        ctx.beginPath();
        ctx.moveTo(x, top);
        ctx.lineTo(x - w, top + h * 0.24);
        ctx.lineTo(x + w, top + h * 0.24);
        ctx.closePath();
        ctx.fill();
      }
    }
  }
  for (let i = 0; i < 34; i++) {
    const x = -180 + i * 103 + (i % 3) * 10;
    const base = ground + 4;
    const height = 115 + ((i * 31) % 95);
    if (desert) {
      ctx.fillStyle = "rgba(47,42,36,.52)";
      ctx.fillRect(x - 6, base - height * 0.72, 12, height * 0.72);
      ctx.beginPath();
      ctx.moveTo(x - 22, base - height * 0.72);
      ctx.lineTo(x - 6, base - height);
      ctx.lineTo(x + 18, base - height * 0.72);
      ctx.fill();
    } else {
      ctx.fillStyle = "rgba(18,47,47,.50)";
      ctx.fillRect(x - 3, base - height * 0.84, 6, height * 0.84);
      for (let t = 0; t < 3; t++) {
        const top = base - height + t * height * 0.24;
        const spread = height * (0.17 - t * 0.022);
        ctx.fillStyle = t === 0 ? "rgba(24,77,72,.48)" : "rgba(10,44,44,.58)";
        ctx.beginPath();
        ctx.moveTo(x, top);
        ctx.lineTo(x - spread, top + height * 0.45);
        ctx.lineTo(x + spread, top + height * 0.45);
        ctx.closePath();
        ctx.fill();
      }
    }
  }
  ctx.fillStyle = desert
    ? "rgba(232,182,116,.40)"
    : alpine
      ? "rgba(204,231,241,.26)"
      : "rgba(171,217,187,.28)";
  ctx.fillRect(-700, ground - 8, 4300, 4);
  ctx.restore();
}
function drawBattleLandscape() {
  const b = battlefield;
  const g = floor();
  const sky = ctx.createLinearGradient(0, -320, 0, g);
  sky.addColorStop(0, b.top);
  sky.addColorStop(0.24, b.mid);
  sky.addColorStop(0.58, b.horizon);
  sky.addColorStop(1, b.bottom);
  ctx.fillStyle = sky;
  ctx.fillRect(-8000, -8000, 18000, 16000);
  const sunX = b.name === "Wüstenklippen" ? 1450 : b.name === "Alpen" ? 1320 : 1520;
  const sunY = b.weather === "rain" ? 230 : 300;
  const sun = ctx.createRadialGradient(sunX, sunY, 10, sunX, sunY, 520);
  sun.addColorStop(0, b.sun + "aa");
  sun.addColorStop(0.22, b.sun + "46");
  sun.addColorStop(0.58, b.sun + "18");
  sun.addColorStop(1, b.sun + "00");
  ctx.fillStyle = sun;
  ctx.fillRect(500, -120, 1700, 1200);
  const vignette = ctx.createLinearGradient(0, -100, 0, 480);
  vignette.addColorStop(0, "rgba(7,18,29,.18)");
  vignette.addColorStop(1, "rgba(7,18,29,0)");
  ctx.fillStyle = vignette;
  ctx.fillRect(-600, -200, 4200, 760);
  for (let layer = 0; layer < 4; layer++) {
    const baseline = 625 + layer * 106;
    const amplitude = layer === 0 ? 215 : layer === 1 ? 165 : layer === 2 ? 118 : 74;
    ctx.beginPath();
    ctx.moveTo(-1300, baseline + 350);
    for (let x = -1300; x <= 3950; x += 42) {
      const ridge =
        Math.abs(Math.sin(x * 0.0031 + layer * 1.37)) * amplitude +
        Math.abs(Math.sin(x * 0.0087 + layer * 0.8)) * amplitude * 0.31 +
        Math.cos(x * 0.015 + layer) * amplitude * 0.06;
      ctx.lineTo(x, baseline - ridge);
    }
    ctx.lineTo(3950, baseline + 500);
    ctx.closePath();
    ctx.fillStyle =
      layer < 3
        ? b.ridges[Math.min(layer, 2)]
        : b.name === "Wüstenklippen"
          ? "rgba(109,87,74,.22)"
          : "rgba(121,151,149,.18)";
    ctx.fill();
    if (layer === 0 && b.name === "Alpen") {
      ctx.strokeStyle = "rgba(244,248,252,.30)";
      ctx.lineWidth = 5;
      ctx.stroke();
    }
  }
  for (let layer = 0; layer < 2; layer++) {
    const base = layer === 0 ? 918 : 1000;
    for (let i = 0; i < 82; i++) {
      const x = i * 34 - 105,
        scale = 0.55 + ((i * 37) % 13) / 19,
        y = base + Math.sin(i * 0.39 + layer) * 16;
      ctx.fillStyle = layer === 0 ? b.vegetation : b.ridges[2];
      ctx.beginPath();
      if (b.name === "Wüstenklippen") {
        ctx.fillRect(x - 9 * scale, y - 26 * scale, 18 * scale, 26 * scale);
        ctx.moveTo(x - 18 * scale, y - 26 * scale);
        ctx.lineTo(x, y - 61 * scale);
        ctx.lineTo(x + 18 * scale, y - 26 * scale);
      } else {
        ctx.moveTo(x, y - 96 * scale);
        ctx.lineTo(x - 21 * scale, y);
        ctx.lineTo(x + 21 * scale, y);
        ctx.closePath();
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(x, y - 120 * scale);
        ctx.lineTo(x - 16 * scale, y - 31 * scale);
        ctx.lineTo(x + 16 * scale, y - 31 * scale);
      }
      ctx.closePath();
      ctx.fill();
    }
  }
  drawSceneryAtmosphere(b);
  drawLandmarkScenery(b);
  drawPremiumSceneryAccent(b);
  const dirt = ctx.createLinearGradient(0, g, 0, g + 260);
  dirt.addColorStop(0, b.soil);
  dirt.addColorStop(0.08, b.name === "Wüstenklippen" ? "#7a5a44" : "#5d6d57");
  dirt.addColorStop(0.28, b.name === "Wüstenklippen" ? "#5b4739" : "#465145");
  dirt.addColorStop(0.62, "#253137");
  dirt.addColorStop(1, "#182229");
  ctx.fillStyle = dirt;
  ctx.fillRect(-8000, g, 18000, 9000);
  const rim = ctx.createLinearGradient(0, g - 8, 0, g + 10);
  rim.addColorStop(0, b.name === "Wüstenklippen" ? "rgba(246,204,142,.34)" : "rgba(182,214,162,.28)");
  rim.addColorStop(0.55, b.name === "Wüstenklippen" ? "rgba(205,154,94,.26)" : "rgba(108,150,98,.18)");
  rim.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = rim;
  ctx.fillRect(-8000, g - 8, 18000, 14);
  ctx.fillStyle = b.soil;
  ctx.fillRect(-8000, g - 3, 18000, 5);
  // Ground texture bands for more premium depth.
  for (let i = 0; i < 140; i++) {
    const x = -200 + i * 26 + ((i * 17) % 11);
    const y = g + 22 + ((i * 19) % 160);
    const w = 18 + (i % 4) * 6;
    const h = 2 + (i % 3);
    ctx.fillStyle = i % 5 === 0 ? "rgba(255,255,255,.018)" : "rgba(12,20,24,.06)";
    ctx.beginPath();
    ctx.ellipse(x, y, w, h, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  for (let i = 0; i < 92; i++) {
    const x = -150 + i * 34 + ((i * 13) % 15);
    const y = g + 56 + ((i * 29) % 190);
    ctx.fillStyle = b.name === "Wüstenklippen" ? "rgba(70,54,43,.16)" : "rgba(34,48,41,.12)";
    ctx.beginPath();
    ctx.ellipse(x, y, 8 + (i % 4) * 3, 2 + (i % 2), 0, 0, Math.PI * 2);
    ctx.fill();
  }
  if (b.name !== "Wüstenklippen") {
    // Rich grassy lip and tiny plants on top of the ground.
    for (let i = 0; i < 220; i++) {
      const x = -180 + i * 15 + (i % 3),
        h = 5 + ((i * 7) % 9);
      ctx.strokeStyle =
        i % 6 === 0 ? "rgba(162,196,128,.30)" : i % 3 === 0 ? "rgba(110,151,96,.24)" : "rgba(78,121,85,.20)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(x, g + 1);
      ctx.lineTo(x - 1, g - h);
      ctx.stroke();
    }
    for (let i = 0; i < 58; i++) {
      const x = -100 + i * 56 + ((i * 23) % 19);
      const base = g + 2;
      ctx.strokeStyle = "rgba(86,128,84,.22)";
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(x, base);
      ctx.lineTo(x - 4, base - 10 - (i % 3) * 3);
      ctx.moveTo(x, base);
      ctx.lineTo(x + 5, base - 8 - (i % 4) * 2);
      ctx.stroke();
      if (i % 5 === 0) {
        ctx.fillStyle = "rgba(228,210,140,.18)";
        ctx.fillRect(x, base - 12, 2, 2);
      }
    }
  } else {
    // Desert pebbles and subtle dune-like highlights.
    for (let i = 0; i < 120; i++) {
      const x = -140 + i * 28 + ((i * 11) % 9),
        y = g + 8 + ((i * 17) % 150);
      ctx.fillStyle = i % 4 === 0 ? "rgba(214,171,114,.12)" : "rgba(70,54,43,.16)";
      ctx.beginPath();
      ctx.ellipse(x, y, 3 + (i % 3), 2 + (i % 2), 0, 0, Math.PI * 2);
      ctx.fill();
    }
    for (let i = 0; i < 32; i++) {
      const x = -120 + i * 110;
      ctx.fillStyle = "rgba(223,180,120,.06)";
      ctx.beginPath();
      ctx.ellipse(x, g + 18, 54, 7, 0, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  if (b.weather === "mist") {
    ctx.fillStyle = "rgba(220,235,235,.11)";
    for (let i = 0; i < 10; i++) ctx.fillRect(-500, 440 + i * 62, 3800, 18 + Math.sin(i * 4) * 8);
  }
  if (b.weather === "rain") {
    ctx.save();
    ctx.strokeStyle = "rgba(187,208,232,.25)";
    ctx.lineWidth = 1.5;
    for (let i = 0; i < 175; i++) {
      const x = ((i * 149 + weatherTime * 170) % 3400) - 500,
        y = ((i * 83 + weatherTime * 430) % 1100) - 100;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x - 16, y + 34);
      ctx.stroke();
    }
    if (Math.sin(weatherTime * 2.7) > 0.985) {
      ctx.fillStyle = "rgba(210,226,255,.10)";
      ctx.fillRect(-600, -200, 4200, 700);
    }
    ctx.restore();
  }
}

function drawPremiumSceneryAccent(b) {
  ctx.save();
  const g = floor();
  const desert = b.name === "Wüstenklippen";
  const alpine = b.name === "Alpen";
  const storm = b.weather === "rain";
  const mist = b.weather === "mist";

  // Cinematic horizon haze.
  const haze = ctx.createLinearGradient(0, g - 350, 0, g + 40);
  haze.addColorStop(0, "rgba(255,244,224,0)");
  haze.addColorStop(
    0.35,
    desert ? "rgba(255,205,135,.08)" : alpine ? "rgba(216,234,255,.08)" : "rgba(245,226,190,.07)",
  );
  haze.addColorStop(0.78, mist ? "rgba(228,241,237,.10)" : "rgba(210,226,216,.05)");
  haze.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = haze;
  ctx.fillRect(-900, g - 380, 4700, 460);

  // Soft volumetric light rays.
  const beamCount = storm ? 3 : 5;
  for (let i = 0; i < beamCount; i++) {
    const x = (desert ? 1180 : 1250) + i * 115 + (i % 2) * 40;
    const topY = storm ? 140 : 120;
    const botY = g - 5;
    const beam = ctx.createLinearGradient(x, topY, x + 90, botY);
    beam.addColorStop(
      0,
      desert ? "rgba(255,223,167,.11)" : alpine ? "rgba(232,244,255,.10)" : "rgba(255,231,178,.09)",
    );
    beam.addColorStop(0.4, "rgba(255,240,215,.03)");
    beam.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = beam;
    ctx.beginPath();
    ctx.moveTo(x, topY);
    ctx.lineTo(x + 72, topY);
    ctx.lineTo(x + 235, botY);
    ctx.lineTo(x + 95, botY);
    ctx.closePath();
    ctx.fill();
  }

  // Extra decorative foreground clusters near edges only, to frame the battlefield.
  if (!desert) {
    const clusters = [-40, 40, 120, 2900, 3030, 3160];
    for (const x of clusters) {
      const base = g + 3;
      for (let i = 0; i < 3; i++) {
        const xx = x + i * 24;
        const h = 58 + i * 18;
        ctx.fillStyle = i === 0 ? "rgba(16,55,51,.58)" : "rgba(10,42,42,.70)";
        ctx.fillRect(xx - 2, base - h * 0.78, 4, h * 0.78);
        for (let t = 0; t < 3; t++) {
          const top = base - h + t * h * 0.22;
          const spread = h * (0.12 - t * 0.02);
          ctx.beginPath();
          ctx.moveTo(xx, top);
          ctx.lineTo(xx - spread, top + h * 0.34);
          ctx.lineTo(xx + spread, top + h * 0.34);
          ctx.closePath();
          ctx.fill();
        }
      }
    }
  } else {
    const rocks = [45, 115, 3000, 3090];
    for (const x of rocks) {
      ctx.fillStyle = "rgba(58,48,41,.60)";
      ctx.beginPath();
      ctx.moveTo(x, g + 1);
      ctx.lineTo(x + 18, g - 30);
      ctx.lineTo(x + 35, g - 12);
      ctx.lineTo(x + 52, g + 1);
      ctx.closePath();
      ctx.fill();
    }
  }

  // Tiny atmosphere particles.
  ctx.fillStyle = storm ? "rgba(196,214,236,.12)" : mist ? "rgba(235,245,240,.14)" : "rgba(255,235,188,.10)";
  for (let i = 0; i < 55; i++) {
    const x = ((i * 61) % 3300) - 80;
    const y = g - 140 - ((i * 37) % 260);
    const r = i % 5 === 0 ? 2.2 : 1.2;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

// Visual-only detail pass: steel joints, timber grain, illuminated structures.
function drawTimberDetail(a, d, b) {
  const dx = d.x - a.x,
    dy = d.y - a.y,
    L = Math.hypot(dx, dy) || 1;
  ctx.save();
  ctx.translate(a.x, a.y);
  ctx.rotate(Math.atan2(dy, dx));
  ctx.lineCap = "round";
  const back = !!b.background,
    maxHp = getBeamMaxHp(b),
    damage = Math.max(0, 1 - b.hp / maxHp);
  const heavyDamage = damage > 0.52,
    critical = damage > 0.78;
  // Slim steel-edged timber matching the industrial sprites. Rear timbers stay darker.
  const outer = back ? 10.4 : 12.0,
    core = back ? 8.5 : 10.0;
  ctx.strokeStyle = back ? "#101a20" : "#101b23";
  ctx.lineWidth = outer;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(L, 0);
  ctx.stroke();
  const wood = ctx.createLinearGradient(0, -core / 2, 0, core / 2);
  if (back) {
    wood.addColorStop(0, heavyDamage ? "#6f4431" : "#70482e");
    wood.addColorStop(0.48, heavyDamage ? "#533122" : "#57371f");
    wood.addColorStop(1, critical ? "#28190f" : "#342316");
  } else {
    wood.addColorStop(0, heavyDamage ? "#975336" : "#9d6037");
    wood.addColorStop(0.43, heavyDamage ? "#81442f" : "#87502e");
    wood.addColorStop(1, critical ? "#3c2318" : "#59351f");
  }
  ctx.strokeStyle = wood;
  ctx.lineWidth = core;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(L, 0);
  ctx.stroke();
  ctx.strokeStyle = back ? "#8a6340" : "#bc8250";
  ctx.lineWidth = 1.15;
  ctx.beginPath();
  ctx.moveTo(5, -core * 0.29);
  ctx.lineTo(L - 5, -core * 0.29);
  ctx.stroke();
  ctx.strokeStyle = back ? "#281b15" : "#4a2c1d";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(6, core * 0.3);
  ctx.lineTo(L - 6, core * 0.3);
  ctx.stroke();
  for (let x = 22; x < L - 10; x += 43) {
    ctx.strokeStyle = back ? "#3b281b" : "#734323";
    ctx.lineWidth = 1.05;
    ctx.beginPath();
    ctx.moveTo(x, -core * 0.34);
    ctx.lineTo(x + 6, core * 0.32);
    ctx.stroke();
    ctx.strokeStyle = back ? "#825739" : "#a87543";
    ctx.lineWidth = 0.7;
    ctx.beginPath();
    ctx.moveTo(x + 11, -core * 0.22);
    ctx.lineTo(x + 19, -core * 0.05);
    ctx.stroke();
  }
  if (damage > 0.16) {
    ctx.save();
    ctx.globalAlpha = Math.min(0.9, 0.25 + damage * 0.9);
    ctx.strokeStyle = critical ? "#20100a" : "#311a12";
    ctx.lineWidth = 1.4 + damage * 1.8;
    const cracks = Math.max(1, Math.round(damage * 5));
    for (let i = 0; i < cracks; i++) {
      const px = 14 + ((L - 28) * (i + 1)) / (cracks + 1),
        dir = i % 2 === 0 ? 1 : -1,
        len = 3 + damage * 8 + (i % 3);
      ctx.beginPath();
      ctx.moveTo(px, -core * 0.38 * dir * 0.25);
      ctx.lineTo(px - len * 0.25, -core * 0.12 * dir);
      ctx.lineTo(px + len * 0.35, core * 0.18 * dir);
      ctx.lineTo(px - len * 0.15, core * 0.42 * dir);
      ctx.stroke();
      if (critical) {
        ctx.beginPath();
        ctx.moveTo(px + 2, -core * 0.05);
        ctx.lineTo(px + 5, core * 0.55 * dir);
        ctx.stroke();
      }
    }
    ctx.fillStyle = "rgba(36,18,10," + (0.12 + damage * 0.24) + ")";
    for (let i = 0; i < Math.max(1, Math.round(damage * 4)); i++) {
      const px = 20 + ((L - 40) * (i + 0.6)) / (Math.max(1, Math.round(damage * 4)) + 0.2),
        w = 6 + damage * 7;
      ctx.beginPath();
      ctx.ellipse(px, (i % 2 ? 1 : -1) * core * 0.08, w, 1.8 + damage * 1.4, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    if (critical) {
      ctx.fillStyle = "rgba(145,87,54,.42)";
      for (let i = 0; i < 3; i++) {
        const px = 18 + ((L - 36) * (i + 1)) / 4;
        ctx.beginPath();
        ctx.moveTo(px, -core * 0.46);
        ctx.lineTo(px + 4, -core * 0.15);
        ctx.lineTo(px - 2, core * 0.18);
        ctx.lineTo(px + 3, core * 0.48);
        ctx.lineTo(px - 4, core * 0.12);
        ctx.closePath();
        ctx.fill();
      }
    }
    ctx.restore();
  }
  ctx.restore();
}
function drawSteelJoint(n) {
  ctx.save();
  ctx.translate(n.x, n.y);
  // Smaller riveted black-steel plates, preserving the original node positions.
  ctx.fillStyle = "#101920";
  ctx.strokeStyle = "#070d12";
  ctx.lineWidth = 1.8;
  ctx.beginPath();
  ctx.roundRect(-7, -7, 14, 14, 2.1);
  ctx.fill();
  ctx.stroke();
  const steel = ctx.createLinearGradient(-7, -7, 7, 7);
  steel.addColorStop(0, "#58616b");
  steel.addColorStop(0.4, "#2c3540");
  steel.addColorStop(1, "#161f28");
  ctx.fillStyle = steel;
  ctx.beginPath();
  ctx.roundRect(-5.5, -5.5, 11, 11, 1.2);
  ctx.fill();
  ctx.strokeStyle = "#89919a";
  ctx.lineWidth = 0.8;
  ctx.beginPath();
  ctx.moveTo(-4.6, -4.7);
  ctx.lineTo(3.8, -4.7);
  ctx.stroke();
  ctx.fillStyle = "#e7a34e";
  for (const x of [-3.9, 3.9])
    for (const y of [-3.9, 3.9]) {
      ctx.beginPath();
      ctx.arc(x, y, 1.25, 0, Math.PI * 2);
      ctx.fill();
    }
  ctx.fillStyle = n.fixed ? "#b1844e" : "#26313b";
  ctx.beginPath();
  ctx.arc(0, 0, 1.7, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#0c151b";
  ctx.lineWidth = 0.9;
  ctx.stroke();
  ctx.restore();
}
const mineSprite = new Image();
mineSprite.src = "assets/img/minesprite.webp";
const windRotorSprite = new Image();
windRotorSprite.src = "assets/img/windrotorsprite.webp";
const windSprite = new Image();
windSprite.src = "assets/img/windsprite.webp";
const workshopSprite = new Image();
workshopSprite.src = "assets/img/workshopsprite.webp";
const repairSprite = new Image();
repairSprite.src = "assets/img/repairsprite.webp";
function drawStructureMount(r, front) {
  // Anchors visually join the sprite to its supporting timber beam.
  const half = r.type === "wind" ? 26 : r.type === "mine" ? 35 : 35;
  if (!front) {
    ctx.save();
    ctx.fillStyle = "rgba(7,13,18,.30)";
    ctx.beginPath();
    ctx.ellipse(0, 17, half + 4, 5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#17232d";
    ctx.fillRect(-half, 14, half * 2, 8);
    ctx.fillStyle = "#576776";
    ctx.fillRect(-half, 14, half * 2, 2.5);
    ctx.fillStyle = "#ad8959";
    ctx.fillRect(-half + 4, 18, half * 2 - 8, 1.5);
    ctx.restore();
    return;
  }
  ctx.save();
  for (const dir of [-1, 1]) {
    const xx = dir * (half - 6);
    ctx.fillStyle = "#17222e";
    ctx.fillRect(xx - 4, 13, 8, 10);
    ctx.fillStyle = "#778898";
    ctx.fillRect(xx - 3.1, 14, 6.2, 2);
    ctx.fillStyle = "#e0c392";
    ctx.beginPath();
    ctx.arc(xx, 19, 1.55, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#263441";
    ctx.lineWidth = 0.7;
    ctx.beginPath();
    ctx.moveTo(xx - 1, 19);
    ctx.lineTo(xx + 1, 19);
    ctx.stroke();
  }
  ctx.restore();
}
function drawStructureDetails(r, x, y) {
  ctx.save();
  ctx.translate(x, y);
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  drawStructureMount(r, false);
  if (r.type === "repair") {
    const active = (r.buildRemaining || 0) <= 0,
      t = performance.now() / 1000;
    if (active) {
      ctx.save();
      ctx.strokeStyle = "rgba(118,225,242,.18)";
      ctx.fillStyle = "rgba(99,214,236,.05)";
      ctx.lineWidth = 1.5;
      ctx.setLineDash([8, 8]);
      ctx.beginPath();
      ctx.arc(0, 6, REPAIR_STATS.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();
    }
    if (repairSprite.complete && repairSprite.naturalWidth) {
      // V15.60: painted repair tower sprite; emitter glows while active
      if (!active) ctx.globalAlpha = 0.75;
      ctx.drawImage(repairSprite, -32, -48, 64, 69);
      ctx.globalAlpha = 1;
      if (active) {
        ctx.save();
        ctx.globalCompositeOperation = "lighter";
        const pulse = 0.35 + 0.25 * Math.sin(t * 5);
        const g = ctx.createRadialGradient(-2.4, -35, 0, -2.4, -35, 14);
        g.addColorStop(0, "rgba(190,250,255," + pulse + ")");
        g.addColorStop(1, "rgba(60,210,240,0)");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(-2.4, -35, 14, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "rgba(143,243,255," + (0.5 - 0.3 * ((t * 0.8) % 1)) + ")";
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(-2.4, -35, 6 + 15 * ((t * 0.8) % 1), 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }
    } else {
    const metal = ctx.createLinearGradient(-24, -34, 24, 22);
      metal.addColorStop(0, "#b5c8cf");
      metal.addColorStop(0.45, "#4c6b7b");
      metal.addColorStop(1, "#233946");
      const brass = ctx.createLinearGradient(-18, -10, 18, 16);
      brass.addColorStop(0, "#ecc67a");
      brass.addColorStop(1, "#8b6439");
      ctx.fillStyle = metal;
      ctx.strokeStyle = "#18303d";
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(-18, 22);
      ctx.lineTo(-12, -20);
      ctx.lineTo(12, -20);
      ctx.lineTo(18, 22);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#294653";
      ctx.fillRect(-24, 20, 48, 7);
      ctx.strokeRect(-24, 20, 48, 7);
      ctx.fillStyle = brass;
      ctx.strokeStyle = "#694e29";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.roundRect(-12, -6, 24, 20, 4);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = "#1a3440";
      ctx.strokeStyle = "#a7d7de";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, 4, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.strokeStyle = "#d5e4e7";
      ctx.lineWidth = 4;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(14, -17);
      ctx.lineTo(26, -29);
      ctx.lineTo(30, -25);
      ctx.lineTo(23, -18);
      ctx.lineTo(28, -13);
      ctx.lineTo(23, -8);
      ctx.lineTo(18, -13);
      ctx.lineTo(11, -6);
      ctx.stroke();
      ctx.strokeStyle = "#95e6f0";
      ctx.lineWidth = 3;
      for (let i = 0; i < 3; i++) {
        const rad = 10 + i * 8 + Math.sin(t * 2 + i) * 1.2;
        ctx.globalAlpha = active ? 0.35 - i * 0.09 : 0.15;
        ctx.beginPath();
        ctx.arc(0, 4, rad, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;
      if (active) {
        ctx.fillStyle = "rgba(255,210,108," + (0.18 + 0.12 * Math.sin(t * 6)) + ")";
        ctx.beginPath();
        ctx.arc(0, 4, 10, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    drawStructureWear(r);
    drawStructureMount(r, true);
    ctx.restore();
    return;
  }
  // Compact, detailed sprite replacements for the two production buildings.
  if (r.type === "wind" && windSprite.complete && windSprite.naturalWidth) {
    ctx.drawImage(windSprite, -27, -62, 54, 83);
    // Rotate the THREE LARGE original sprite blades as a separate texture.
    // Their hub stays attached to the stationary tower, while the whole rotor turns.
    if (windRotorSprite.complete && windRotorSprite.naturalWidth) {
      const active = (r.buildRemaining || 0) <= 0;
      const t = active ? performance.now() / 1400 : 0;
      const rotorX = -27 + (153 * 54) / 422,
        rotorY = -62 + (157 * 83) / 400;
      ctx.save();
      ctx.translate(rotorX, rotorY);
      // Rotate in pixel space, compensating for the sprite's nonuniform scaling.
      ctx.scale(54 / 422, 83 / 400);
      ctx.rotate(t);
      // V15.60: rebuilt rotor (380x380) with the hub in its centre
      ctx.drawImage(windRotorSprite, -windRotorSprite.naturalWidth / 2, -windRotorSprite.naturalHeight / 2);
      ctx.restore();
    }
    if ((r.buildRemaining || 0) <= 0) {
      const a = performance.now() / 700;
      ctx.fillStyle = "rgba(255,204,83," + (0.25 + 0.16 * Math.sin(a * 2)) + ")";
      ctx.beginPath();
      ctx.arc(9, 0, 2.3, 0, Math.PI * 2);
      ctx.fill();
    }
    drawStructureWear(r);
    drawStructureMount(r, true);
    ctx.restore();
    return;
  }
  if (r.type === "workshop" && workshopSprite.complete && workshopSprite.naturalWidth) {
    ctx.drawImage(workshopSprite, -36, -41, 72, 62);
    if ((r.buildRemaining || 0) <= 0) {
      const t = performance.now() / 1000;
      ctx.fillStyle = "rgba(255,172,64," + (0.1 + 0.09 * Math.sin(t * 6)) + ")";
      ctx.beginPath();
      ctx.arc(-16, 6, 8, 0, Math.PI * 2);
      ctx.fill();
      for (let i = 0; i < 3; i++) {
        const phase = (t * 1.3 + i * 0.37) % 1;
        ctx.fillStyle = "rgba(255,202,98," + (1 - phase) * 0.65 + ")";
        ctx.fillRect(-13 + i * 4, -5 - phase * 12, 1.3, 2.3);
      }
    }
    drawStructureWear(r);
    drawStructureMount(r, true);
    ctx.restore();
    return;
  }

  if (r.type === "mine" && mineSprite.complete && mineSprite.naturalWidth) {
    ctx.drawImage(mineSprite, -36, -44, 72, 65);
    // Animated winch: a subtle rotating steel hub over the pulley in the sprite.
    // Keep the original artwork as the base; only the machinery moves.
    const active = (r.buildRemaining || 0) <= 0;
    const t = performance.now() / 1000;
    const wheelX = 21.4,
      wheelY = -27.3;
    ctx.save();
    ctx.translate(wheelX, wheelY);
    ctx.beginPath();
    ctx.arc(0, 0, 7.4, 0, Math.PI * 2);
    ctx.clip();
    ctx.rotate(active ? t * 0.9 : 0);
    ctx.strokeStyle = "#25303a";
    ctx.lineWidth = 2.3;
    for (let i = 0; i < 5; i++) {
      const a = (i * Math.PI * 2) / 5;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * 2.2, Math.sin(a) * 2.2);
      ctx.lineTo(Math.cos(a) * 6.8, Math.sin(a) * 6.8);
      ctx.stroke();
      ctx.strokeStyle = "#a7aeb4";
      ctx.lineWidth = 0.9;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a + 0.17) * 3.3, Math.sin(a + 0.17) * 3.3);
      ctx.lineTo(Math.cos(a + 0.17) * 6.5, Math.sin(a + 0.17) * 6.5);
      ctx.stroke();
      ctx.strokeStyle = "#25303a";
      ctx.lineWidth = 2.3;
    }
    ctx.fillStyle = "#1c2833";
    ctx.beginPath();
    ctx.arc(0, 0, 2.3, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#c7b89d";
    ctx.beginPath();
    ctx.arc(-0.45, -0.45, 0.9, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    if (active) {
      // Tiny ore pieces travel up the existing inclined conveyor.
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(5.2, 3);
      ctx.lineTo(25, -20);
      ctx.lineTo(28, -18);
      ctx.lineTo(8.2, 5);
      ctx.closePath();
      ctx.clip();
      for (let i = 0; i < 4; i++) {
        const f = (t * 0.19 + i * 0.27) % 1;
        const x = 6.5 + 19 * f,
          y = 3 - 22 * f;
        ctx.fillStyle = i % 2 ? "#657a8d" : "#b5c4cf";
        ctx.beginPath();
        ctx.moveTo(x - 1.6, y + 1);
        ctx.lineTo(x - 0.6, y - 1.7);
        ctx.lineTo(x + 1.8, y - 1);
        ctx.lineTo(x + 2, y + 0.7);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();
      // Warm lamp flicker, intentionally very subtle.
      const glow = 0.1 + 0.045 * Math.sin(t * 5.3);
      ctx.fillStyle = "rgba(255,188,66," + glow + ")";
      ctx.beginPath();
      ctx.arc(-10.5, -11, 4.5, 0, Math.PI * 2);
      ctx.fill();
    }
    drawStructureWear(r);
    drawStructureMount(r, true);
    ctx.restore();
    return;
  }

  const enemy = r.owner === "enemy",
    accent = enemy ? "#c86660" : "#70bdd6";
  const built = (r.buildRemaining || 0) <= 0;
  const metal = ctx.createLinearGradient(-30, -30, 30, 26);
  metal.addColorStop(0, "#a8b8bc");
  metal.addColorStop(0.38, "#506e7d");
  metal.addColorStop(1, "#223c4d");
  const wood = ctx.createLinearGradient(-26, -20, 26, 22);
  wood.addColorStop(0, "#d6a36a");
  wood.addColorStop(0.52, "#926039");
  wood.addColorStop(1, "#4a3428");
  const panel = (xx, yy, w, h, c, edge = "#1b2a32") => {
    ctx.fillStyle = c;
    ctx.strokeStyle = edge;
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.roundRect(xx, yy, w, h, 2);
    ctx.fill();
    ctx.stroke();
  };
  const rivet = (xx, yy) => {
    ctx.fillStyle = "#e2d3ae";
    ctx.beginPath();
    ctx.arc(xx, yy, 1.8, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#52646d";
    ctx.beginPath();
    ctx.arc(xx + 0.5, yy + 0.5, 0.65, 0, Math.PI * 2);
    ctx.fill();
  };
  // Common platform, feet and faction marking.
  panel(-32, 19, 64, 7, "#273d4c");
  panel(-25, 25, 13, 5, "#192e3c");
  panel(12, 25, 13, 5, "#192e3c");
  if (r.type === "mine") {
    // Timber-framed shaft with ore chute, rail tracks and a warm lamp.
    panel(-28, -12, 56, 32, wood);
    ctx.fillStyle = "#283944";
    ctx.strokeStyle = "#14242f";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(-33, -12);
    ctx.lineTo(-18, -28);
    ctx.lineTo(19, -28);
    ctx.lineTo(33, -12);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle = "#c7d2d2";
    ctx.lineWidth = 2;
    for (let i = -24; i < 27; i += 10) {
      ctx.beginPath();
      ctx.moveTo(i, -15);
      ctx.lineTo(i + 9, -24);
      ctx.stroke();
    }
    panel(-22, -9, 7, 28, "#bf8b54");
    panel(15, -9, 7, 28, "#bf8b54");
    ctx.fillStyle = "#17242a";
    ctx.beginPath();
    ctx.moveTo(-12, 19);
    ctx.lineTo(-12, 4);
    ctx.arc(0, 4, 12, Math.PI, 0);
    ctx.lineTo(12, 19);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = "#e2ae71";
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.strokeStyle = "#71848b";
    ctx.lineWidth = 2;
    for (let q of [-8, 8]) {
      ctx.beginPath();
      ctx.moveTo(q, 11);
      ctx.lineTo(q, 26);
      ctx.stroke();
    }
    ctx.fillStyle = "#839ca7";
    for (let i = 0; i < 4; i++) {
      ctx.beginPath();
      ctx.moveTo(-26 + i * 8, 19);
      ctx.lineTo(-22 + i * 8, 12 - (i % 2) * 3);
      ctx.lineTo(-16 + i * 8, 19);
      ctx.fill();
    }
    // Mine: steel headframe, winding wheel, ore cart and mineral highlights.
    ctx.strokeStyle = "#354854";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(-14, -28);
    ctx.lineTo(-7, -41);
    ctx.lineTo(7, -41);
    ctx.lineTo(15, -28);
    ctx.stroke();
    ctx.fillStyle = "#bd935c";
    ctx.strokeStyle = "#1b2c35";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, -37, 7, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle = "#273b45";
    for (let k = 0; k < 6; k++) {
      const a = (k * Math.PI) / 3;
      ctx.beginPath();
      ctx.moveTo(0, -37);
      ctx.lineTo(Math.cos(a) * 6, -37 + Math.sin(a) * 6);
      ctx.stroke();
    }
    ctx.strokeStyle = "#b8c4c1";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(0, -30);
    ctx.lineTo(0, -10);
    ctx.stroke();
    panel(10, 12, 17, 9, "#435664");
    ctx.fillStyle = "#dbad6b";
    ctx.fillRect(12, 10, 13, 4);
    for (const cx of [14, 24]) {
      ctx.fillStyle = "#1c2a32";
      ctx.beginPath();
      ctx.arc(cx, 23, 3, 0, Math.PI * 2);
      ctx.fill();
    }
    for (const [ox, oy] of [
      [14, 9],
      [19, 11],
      [23, 9],
    ]) {
      ctx.fillStyle = "#91b9c3";
      ctx.beginPath();
      ctx.moveTo(ox, oy - 4);
      ctx.lineTo(ox + 4, oy);
      ctx.lineTo(ox - 3, oy + 1);
      ctx.fill();
    }
    panel(-27, -8, 8, 10, "#edbc71");
    rivet(-24, -5);
    if (built) {
      ctx.fillStyle = "#ffe3a4";
      ctx.shadowColor = "#ffbf64";
      ctx.shadowBlur = 11;
      ctx.fillRect(-25, -6, 4, 5);
      ctx.shadowBlur = 0;
    }
  } else if (r.type === "workshop") {
    // Forged-steel workshop, chimney, riveted walls, illuminated furnace.
    panel(-31, -12, 62, 34, wood);
    panel(12, -42, 13, 28, metal);
    panel(10, -45, 17, 5, "#c4d0d0");
    ctx.fillStyle = "#435d6b";
    ctx.strokeStyle = "#1b2b35";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(-36, -12);
    ctx.lineTo(-23, -30);
    ctx.lineTo(23, -30);
    ctx.lineTo(36, -12);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle = "#bacbd0";
    ctx.lineWidth = 2;
    for (let i = -24; i <= 24; i += 12) {
      ctx.beginPath();
      ctx.moveTo(i, -27);
      ctx.lineTo(i + 9, -14);
      ctx.stroke();
    }
    panel(-25, -8, 20, 25, "#253943");
    panel(-21, -4, 12, 17, "#d9a15b");
    if (built) {
      ctx.save();
      ctx.shadowColor = "#ffac4c";
      ctx.shadowBlur = 18;
      ctx.fillStyle = "#ffcc7a";
      ctx.fillRect(-19, -2, 8, 13);
      ctx.restore();
    }
    panel(2, -8, 23, 30, metal);
    panel(8, -2, 11, 14, "#192d39");
    for (let i of [-26, 26]) {
      panel(i - 2, -8, 5, 29, "#b18b5d");
      rivet(i, 13);
    }
    for (let i of [-18, 18]) rivet(i, -17);
    // Workshop: smokestack rim, vents, pipes, pressure gauge and riveted door.
    ctx.strokeStyle = "#9cabb0";
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.moveTo(18, -41);
    ctx.lineTo(18, -49);
    ctx.lineTo(29, -49);
    ctx.stroke();
    panel(8, -51, 21, 5, "#788c97");
    for (let i = 0; i < 4; i++) {
      ctx.strokeStyle = "#182c36";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(5 + i * 5, -10);
      ctx.lineTo(7 + i * 5, -10);
      ctx.stroke();
    }
    ctx.fillStyle = "#bdc9c5";
    ctx.strokeStyle = "#21313b";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(21, 7, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle = "#ad6b43";
    ctx.beginPath();
    ctx.moveTo(21, 7);
    ctx.lineTo(23, 4);
    ctx.stroke();
    for (const yy of [1, 9, 17]) {
      ctx.fillStyle = "#d1a76e";
      ctx.fillRect(5, yy, 2, 2);
      ctx.fillRect(22, yy, 2, 2);
    }
    ctx.strokeStyle = "#c7b38c";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(-30, 8);
    ctx.lineTo(-35, 8);
    ctx.lineTo(-35, 17);
    ctx.stroke();
    panel(-4, 7, 8, 4, "#d3a15e");
  } else if (r.type === "wind") {
    // Braced turbine tower with a rotating three-bladed rotor.
    ctx.fillStyle = metal;
    ctx.strokeStyle = "#172b3a";
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(-13, 22);
    ctx.lineTo(-6, -42);
    ctx.lineTo(6, -42);
    ctx.lineTo(13, 22);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.strokeStyle = "#bdd0d2";
    ctx.lineWidth = 2;
    for (let yy = -27; yy < 18; yy += 15) {
      ctx.beginPath();
      ctx.moveTo(-8, yy);
      ctx.lineTo(8, yy + 15);
      ctx.moveTo(8, yy);
      ctx.lineTo(-8, yy + 15);
      ctx.stroke();
    }
    panel(-9, -45, 18, 10, "#385769");
    ctx.save();
    ctx.translate(0, -43);
    ctx.rotate(performance.now() / 1700);
    for (let i = 0; i < 3; i++) {
      ctx.rotate((Math.PI * 2) / 3);
      ctx.fillStyle = "#e3e8e2";
      ctx.strokeStyle = "#425a64";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-4, -4);
      ctx.lineTo(-8, -34);
      ctx.lineTo(-1, -39);
      ctx.lineTo(5, -5);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.strokeStyle = "#9db6bf";
      ctx.beginPath();
      ctx.moveTo(-2, -8);
      ctx.lineTo(-3, -28);
      ctx.stroke();
    }
    ctx.restore();
    ctx.fillStyle = "#dcb676";
    ctx.strokeStyle = "#304655";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, -43, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    // Turbine: generator cooling fins, service ladder, foundation bolts and cables.
    for (let i = 0; i < 4; i++) {
      ctx.strokeStyle = "#b8c9cb";
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.moveTo(-7 + i * 4, -43);
      ctx.lineTo(-7 + i * 4, -35);
      ctx.stroke();
    }
    ctx.strokeStyle = "#d2c49d";
    ctx.lineWidth = 1.7;
    for (let yy = -20; yy < 18; yy += 9) {
      ctx.beginPath();
      ctx.moveTo(-4, yy);
      ctx.lineTo(4, yy);
      ctx.stroke();
    }
    ctx.strokeStyle = "#1c2e3a";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(6, -33);
    ctx.bezierCurveTo(16, -23, 9, -10, 12, 17);
    ctx.stroke();
    panel(-18, 18, 36, 6, "#506d78");
    rivet(-9, 17);
    rivet(9, 17);
  }
  drawStructureWear(r);
  // Small faction-colored badge and an industrial warning stripe.
  panel(-9, 18, 18, 5, accent);
  ctx.strokeStyle = "#263844";
  ctx.lineWidth = 1;
  for (let i = -6; i <= 6; i += 6) {
    ctx.beginPath();
    ctx.moveTo(i, 19);
    ctx.lineTo(i + 2, 22);
    ctx.stroke();
  }
  ctx.restore();
}
// V13.55: Initialize weapon image assets once at script startup, NOT inside render().
// The previous render() recreated all Image objects and their onload handlers
// every frame, so the new sprite buffers were always empty until the next frame.
const weaponLayerArt = {
  cannon_upper: "assets/img/cannon-upper.webp",
  cannon_base: "assets/img/cannon-base.webp",
  cannon_full: "assets/img/cannon-full.webp",
  mg_upper: "assets/img/mg-upper.webp",
  mg_base: "assets/img/mg-base.webp",
  mg_full: "assets/img/mg-full.webp",
  rocket_upper: "assets/img/rocket-upper.webp",
  rocket_base: "assets/img/rocket-base.webp",
  rocket_full: "assets/img/rocket-full.webp",
  autocannon_upper: "assets/img/autocannon-upper.webp",
  autocannon_base: "assets/img/autocannon-base.webp",
  autocannon_full: "assets/img/autocannon-full.webp",
  heavy_upper: "assets/img/heavy-upper.webp",
  heavy_base: "assets/img/heavy-base.webp",
  heavy_full: "assets/img/heavy-full.webp",
  sniper_upper: "assets/img/sniper-upper.webp",
  sniper_base: "assets/img/sniper-base.webp",
  sniper_full: "assets/img/sniper-full.webp",
  mortar_upper: "assets/img/mortar-upper.webp",
  mortar_base: "assets/img/mortar-base.webp",
  mortar_full: "assets/img/mortar-full.webp",
};
const weaponLayerImages = {};
for (const [key, url] of Object.entries(weaponLayerArt)) {
  const im = new Image();
  im.src = url;
  weaponLayerImages[key] = im;
}

// V13.39: mechanically articulated, resolution-independent weapons.
// No pre-rendered sheet frames: prevents chopped barrels and stray crop pixels.
const articulatedSpriteUrls = {
  cannon_barrel: "assets/img/cannon-barrel.webp",
  cannon_base: "assets/img/cannon-base-2.webp",
  heavy_barrel: "assets/img/heavy-barrel.webp",
  heavy_base: "assets/img/heavy-base-2.webp",
  sniper_barrel: "assets/img/sniper-barrel.webp",
  sniper_base: "assets/img/sniper-base-2.webp",
  rocket_barrel: "assets/img/rocket-barrel.webp",
  rocket_base: "assets/img/rocket-base-2.webp",
  autocannon_barrel: "assets/img/autocannon-barrel.webp",
  autocannon_base: "assets/img/autocannon-base-2.webp",
  mg_barrel: "assets/img/mg-barrel.webp",
  mg_base: "assets/img/mg-base-2.webp",
  mortar_barrel: "assets/img/mortar-barrel.webp",
  mortar_base: "assets/img/mortar-base-2.webp",
};
articulatedSpriteUrls["flak_base"] = "assets/img/flak-base.webp";
articulatedSpriteUrls["flak_barrel"] = "assets/img/flak-barrel.webp";

// V15.38: Mortar tube lifted 12 sprite px into existing cradle; original gear/pivot and base stay in place.
articulatedSpriteUrls["mortar_base"] = "assets/img/mortar-base-2.webp";
/* V15.45: one canonical complete user-supplied mortar barrel PNG; no override. */
/* V15.41: foreground curved cradle, drawn after the rotating mortar tube. */
articulatedSpriteUrls["mortar_saddle_front"] = "assets/img/mortar-saddle-front.webp";
const articulatedSpriteImages = {};
// Decode the large embedded WebP images ONCE into persistent canvas surfaces.
// Mobile Chrome may discard/redecode Image backing stores under memory pressure;
// canvas copies remain available to the renderer without testing image readiness
// on every animation frame.
const weaponSpriteSurfaces = {};
for (const [key, url] of Object.entries(articulatedSpriteUrls)) {
  const im = new Image();
  articulatedSpriteImages[key] = im;
  im.onload = () => {
    if (!im.naturalWidth || !im.naturalHeight) return;
    const surface = document.createElement("canvas");
    surface.width = im.naturalWidth;
    surface.height = im.naturalHeight;
    const surfaceCtx = surface.getContext("2d", { alpha: true });
    surfaceCtx.drawImage(im, 0, 0);
    weaponSpriteSurfaces[key] = surface;
  };
  im.src = url;
}
// The independently drawn base is stationary, only the barrel turns.
function drawLayeredWeapon(cx, type, angle = 0, enemy = false, flash = 0) {
  if (type === "flak") {
    const fBase =
      weaponSpriteSurfaces["flak_base"] ||
      (articulatedSpriteImages["flak_base"]?.naturalWidth ? articulatedSpriteImages["flak_base"] : null);
    const fBarrel =
      weaponSpriteSurfaces["flak_barrel"] ||
      (articulatedSpriteImages["flak_barrel"]?.naturalWidth ? articulatedSpriteImages["flak_barrel"] : null);
    if (fBase && fBarrel) {
      cx.save();
      if (enemy) cx.scale(-1, 1);
      // V15.19: Flak-only mount adjustment. Keep the stationary base and rotating
      // barrels together by deriving both from the same higher baseY/pivot.
      // V15.23: Flak base alpha bottom (row 811) aligns with the supporting
      // beam center, matching the original weapons; barrel retains its own offset.
      // V15.28: align the flak base to the same support-beam height as the other weapons.
      const baseScale = 0.112,
        baseX = -39,
        baseY = -96.4;
      cx.drawImage(fBase, baseX, baseY, fBase.width * baseScale, fBase.height * baseScale);
      const pivotBase = { x: 347, y: 561 };
      const pivotBarrel = { x: 110, y: 430 };
      const barrelVisualYOffset = -28; // V15.21: only raise the barrel, keep the base on the beam.
      const px = baseX + pivotBase.x * baseScale,
        py = baseY + pivotBase.y * baseScale;
      const rawAngle = Number.isFinite(angle) ? angle : 0;
      const target = enemy ? Math.PI - rawAngle : rawAngle;
      const restAngle = -0.11;
      let delta = target - restAngle;
      if (delta > Math.PI) delta -= Math.PI * 2;
      if (delta < -Math.PI) delta += Math.PI * 2;
      delta = Math.max(-0.95, Math.min(0.62, delta));
      cx.save();
      cx.translate(px, py);
      cx.rotate(delta);
      const barrelScale = 0.12;
      cx.drawImage(
        fBarrel,
        -pivotBarrel.x * barrelScale,
        -pivotBarrel.y * barrelScale + barrelVisualYOffset,
        fBarrel.width * barrelScale,
        fBarrel.height * barrelScale,
      );
      cx.restore();
      if (flash > 0) {
        const muzzleDx = 57,
          muzzleDy = -34;
        const fx = px + Math.cos(target) * muzzleDx - Math.sin(target) * muzzleDy;
        const fy = py + Math.sin(target) * muzzleDx + Math.cos(target) * muzzleDy;
        cx.fillStyle = "rgba(121,243,225,.50)";
        cx.beginPath();
        cx.arc(fx, fy, 5 + flash * 24, 0, Math.PI * 2);
        cx.fill();
      }
      cx.restore();
      return;
    }
    cx.save();
    if (enemy) cx.scale(-1, 1);
    // fallback vector flak while sprite loads
    cx.fillStyle = "#253a48";
    cx.strokeStyle = "#0d202d";
    cx.lineWidth = 3;
    cx.beginPath();
    cx.moveTo(-35, -4);
    cx.lineTo(-26, -25);
    cx.lineTo(27, -25);
    cx.lineTo(36, -4);
    cx.closePath();
    cx.fill();
    cx.stroke();
    const metal = cx.createLinearGradient(-30, -31, 28, -2);
    metal.addColorStop(0, "#b5c5c9");
    metal.addColorStop(0.55, "#526d7c");
    metal.addColorStop(1, "#25394b");
    cx.fillStyle = metal;
    cx.fillRect(-36, -13, 72, 18);
    cx.strokeRect(-36, -13, 72, 18);
    cx.fillStyle = "#d8ae65";
    for (const bx of [-27, -8, 12, 28]) {
      cx.beginPath();
      cx.arc(bx, -5, 2.5, 0, Math.PI * 2);
      cx.fill();
    }
    const a = enemy ? Math.atan2(Math.sin(Math.PI - angle), Math.cos(Math.PI - angle)) : angle;
    const elevation = Math.max(-Math.PI * 0.82, Math.min(Math.PI * 0.82, a));
    cx.save();
    cx.translate(0, -24);
    cx.rotate(elevation);
    cx.fillStyle = "#a6bdc7";
    cx.strokeStyle = "#142b39";
    cx.lineWidth = 2.5;
    for (const by of [-9, 6]) {
      cx.fillRect(3, by - 4, 46, 8);
      cx.strokeRect(3, by - 4, 46, 8);
      cx.fillStyle = "#dbab5f";
      cx.fillRect(44, by - 6, 10, 12);
      cx.fillStyle = "#a6bdc7";
    }
    cx.restore();
    cx.fillStyle = "#a67e43";
    cx.strokeStyle = "#182c3a";
    cx.lineWidth = 3;
    cx.beginPath();
    cx.arc(0, -23, 17, 0, Math.PI * 2);
    cx.fill();
    cx.stroke();
    cx.fillStyle = "#233f50";
    cx.beginPath();
    cx.arc(0, -23, 10, 0, Math.PI * 2);
    cx.fill();
    cx.strokeStyle = "#93e2d9";
    cx.lineWidth = 3;
    cx.beginPath();
    cx.arc(19, -47, 13, Math.PI * 1.05, Math.PI * 1.88);
    cx.stroke();
    cx.fillStyle = "#e0b877";
    cx.beginPath();
    cx.arc(20, -50, 4, 0, Math.PI * 2);
    cx.fill();
    if (flash > 0) {
      cx.fillStyle = "rgba(121,243,225,.6)";
      cx.beginPath();
      cx.arc(51, -31, 8 + flash * 27, 0, Math.PI * 2);
      cx.fill();
    }
    cx.restore();
    return;
  }

  if (type === "mortar") {
    // V15.51: The full upper PNG rotates *around the screw in that image*.
    // The fixed wooden/metal chassis is drawn afterwards, as foreground.
    const base =
      weaponSpriteSurfaces["mortar_base"] ||
      (articulatedSpriteImages["mortar_base"]?.naturalWidth ? articulatedSpriteImages["mortar_base"] : null);
    const barrel =
      weaponSpriteSurfaces["mortar_barrel"] ||
      (articulatedSpriteImages["mortar_barrel"]?.naturalWidth
        ? articulatedSpriteImages["mortar_barrel"]
        : null);
    if (base && barrel) {
      cx.save();
      if (enemy) cx.scale(-1, 1);
      const c = FW_MORTAR_CONFIG;
      const pivotX = c.baseX + c.basePivotX * c.artScale + (window.__fwMortarCalibration?.x ?? 2.5);
      const pivotY = c.baseY + c.basePivotY * c.artScale + (window.__fwMortarCalibration?.y ?? 1);
      const visualAngle = enemy ? c.restAngle : Number.isFinite(angle) ? angle : c.restAngle;
      const delta = fwMortarVisualRotation(visualAngle);
      const barrelScale = (384 * c.artScale) / barrel.width;
      // Rotating sprite is behind the static cradle; translation is not rotated.
      cx.save();
      cx.translate(pivotX, pivotY);
      cx.rotate(delta);
      cx.drawImage(
        barrel,
        -c.spritePivotX * barrelScale,
        -c.spritePivotY * barrelScale,
        barrel.width * barrelScale,
        barrel.height * barrelScale,
      );
      cx.restore();
      cx.drawImage(base, c.baseX, c.baseY, 384 * c.artScale, base.height * c.artScale);
      if (flash > 0) {
        const muzzleDx = (c.muzzleX - c.spritePivotX) * barrelScale;
        const muzzleDy = (c.muzzleY - c.spritePivotY) * barrelScale;
        const fx = pivotX + muzzleDx * Math.cos(delta) - muzzleDy * Math.sin(delta);
        const fy = pivotY + muzzleDx * Math.sin(delta) + muzzleDy * Math.cos(delta);
        cx.fillStyle = "rgba(255,186,62,.4)";
        cx.beginPath();
        cx.arc(fx, fy, 3 + flash * 25, 0, Math.PI * 2);
        cx.fill();
      }
      cx.restore();
      return;
    }
  }

  const base =
    weaponSpriteSurfaces[type + "_base"] ||
    (articulatedSpriteImages[type + "_base"]?.naturalWidth ? articulatedSpriteImages[type + "_base"] : null);
  const barrel =
    weaponSpriteSurfaces[type + "_barrel"] ||
    (articulatedSpriteImages[type + "_barrel"]?.naturalWidth
      ? articulatedSpriteImages[type + "_barrel"]
      : null);
  // Never leave a placed weapon blank. Keep a visible placeholder while an
  // embedded image is being decoded; a diagnostic counter records these frames.
  if (!base || !barrel) {
    window.__missingWeaponSpriteFrames = (window.__missingWeaponSpriteFrames || 0) + 1;
    cx.save();
    cx.fillStyle = "#8e6032";
    cx.strokeStyle = "#f2bb62";
    cx.lineWidth = 2;
    cx.fillRect(-39, -24, 78, 23);
    cx.strokeRect(-39, -24, 78, 23);
    cx.fillStyle = "#eac58a";
    cx.font = "bold 9px sans-serif";
    cx.textAlign = "center";
    cx.fillText("GRAFIK LÄDT", 0, -9);
    cx.restore();
    return;
  }
  cx.save();
  if (enemy) cx.scale(-1, 1);
  const scale = 0.215;
  // V15.28: MG and Autokanone sat a few pixels too low. Raise only those types,
  // keeping the clean reference weapons untouched.
  const typeYOffset = type === "mg" || type === "autocannon" ? -3 : 0;
  const bx = -41,
    by = -43 + typeYOffset,
    tx = -26,
    ty = -67 + typeYOffset;
  cx.drawImage(base, bx, by, 384 * scale, base.height * scale);
  const pivotX = 121,
    pivotY = 150;
  const px = tx + pivotX * scale,
    py = ty + pivotY * scale;
  // Idle guns hold the original neutral elevation. Clamp aim to the mechanical
  // travel of the sprite so the barrel cannot rotate through its own carriage.
  const rawAngle = Number.isFinite(angle) ? angle : 0;
  const target = enemy ? 0 : rawAngle;
  const delta = Math.max(-0.72, Math.min(0.22, target)) - -0.42;
  cx.save();
  cx.translate(px, py);
  cx.rotate(delta);
  cx.drawImage(barrel, -pivotX * scale, -pivotY * scale, 384 * scale, barrel.height * scale);
  cx.restore();
  if (flash > 0) {
    cx.fillStyle = "rgba(255,186,62,.4)";
    cx.beginPath();
    cx.arc(px + 52 * Math.cos(target), py + 52 * Math.sin(target), 3 + flash * 25, 0, Math.PI * 2);
    cx.fill();
  }
  cx.restore();
}
function updateWeaponSkinCards() {
  // V15.30: Each arsenal icon is an actual draw of the current weapon skin.
  // It shares the renderer, angle and art offsets with the battlefield,
  // including the separately animated Flak and the corrected mortar cradle.
  const cards = document.querySelectorAll("#weaponDock .weaponCard[data-weapon]");
  const previewAngle = 0;
  for (const card of cards) {
    const type = card.dataset.weapon,
      ill = card.querySelector(".illustration");
    if (!ill) continue;
    const base = articulatedSpriteImages[type + "_base"];
    const barrel = articulatedSpriteImages[type + "_barrel"];
    if (!base || !barrel) continue;
    const update = () => {
      if (!base.complete || !barrel.complete || !base.naturalWidth || !barrel.naturalWidth) return;
      try {
        const working = document.createElement("canvas");
        working.width = 400;
        working.height = 280;
        const g = working.getContext("2d", { willReadFrequently: true });
        g.save();
        g.translate(200, 166);
        g.scale(2.15, 2.15);
        drawLayeredWeapon(g, type, previewAngle, false, 0);
        g.restore();
        // Crop transparent sprite margins so every icon uses the available card space.
        const pixels = g.getImageData(0, 0, working.width, working.height).data;
        let x0 = working.width,
          y0 = working.height,
          x1 = -1,
          y1 = -1;
        for (let y = 0; y < working.height; y++) {
          for (let x = 0; x < working.width; x++) {
            if (pixels[(y * working.width + x) * 4 + 3] > 12) {
              if (x < x0) x0 = x;
              if (x > x1) x1 = x;
              if (y < y0) y0 = y;
              if (y > y1) y1 = y;
            }
          }
        }
        if (x1 < x0 || y1 < y0) return;
        const pw = x1 - x0 + 1,
          ph = y1 - y0 + 1;
        const icon = document.createElement("canvas");
        icon.width = 384;
        icon.height = 220;
        const ig = icon.getContext("2d");
        const factor = Math.min(360 / pw, 202 / ph);
        const rw = pw * factor,
          rh = ph * factor;
        ig.drawImage(working, x0, y0, pw, ph, (384 - rw) / 2, (220 - rh) / 2, rw, rh);
        ill.style.setProperty("background-image", 'url("' + icon.toDataURL("image/png") + '")', "important");
        ill.style.setProperty("background-size", "contain", "important");
        ill.style.setProperty("background-position", "center", "important");
        ill.style.setProperty("background-repeat", "no-repeat", "important");
        ill.dataset.skinPreview = "v15.31";
      } catch (err) {
        console.warn("Waffen-Icon konnte nicht erzeugt werden:", type, err);
      }
    };
    if (base.complete && barrel.complete && base.naturalWidth && barrel.naturalWidth) update();
    else {
      base.addEventListener("load", update, { once: true });
      barrel.addEventListener("load", update, { once: true });
    }
  }
}

function drawArmorWall(a, d, b) {
  if (!a || !d) return;
  const dx = d.x - a.x,
    dy = d.y - a.y,
    L = Math.hypot(dx, dy) || 1;
  ctx.save();
  ctx.translate(a.x, a.y);
  ctx.rotate(Math.atan2(dy, dx));
  ctx.lineCap = "butt";
  ctx.fillStyle = "#202f3b";
  ctx.fillRect(0, -12, L, 24);
  ctx.fillStyle = "#718795";
  ctx.fillRect(0, -9, L, 18);
  ctx.fillStyle = "#a6b7c1";
  ctx.fillRect(0, -9, L, 4);
  ctx.fillStyle = "#3e5262";
  ctx.fillRect(0, 5, L, 4);
  ctx.strokeStyle = "#19242d";
  ctx.lineWidth = 2;
  for (let x = 0; x < L; x += 25) {
    ctx.beginPath();
    ctx.moveTo(x, -9);
    ctx.lineTo(x, 9);
    ctx.stroke();
    ctx.fillStyle = "#d1a96c";
    ctx.beginPath();
    ctx.arc(x + 8, -4, 2, 0, Math.PI * 2);
    ctx.arc(x + 8, 5, 2, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}
function drawVisibleEnemyArmorDoors(side) {
  // Render enemy sliding armor doors again on TOP of the wooden façade.
  for (const b of beams) {
    if (!b.armorDoor || b.owner !== side || b.hp <= 0) continue;
    const a = nodes[b.a],
      d = nodes[b.b];
    if (!a || !d) continue;
    const dx = d.x - a.x,
      dy = d.y - a.y,
      L = Math.hypot(dx, dy) || 1;
    const nx = -dy / L,
      ny = dx / L,
      opening = (b.doorProgress || 0) * 1.0;
    ctx.save();
    ctx.lineCap = "round";
    ctx.setLineDash([]);
    ctx.strokeStyle = "#1b2932";
    ctx.lineWidth = 29;
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(d.x, d.y);
    ctx.stroke();
    ctx.strokeStyle = "#879fac";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(a.x + nx * 13, a.y + ny * 13);
    ctx.lineTo(d.x + nx * 13, d.y + ny * 13);
    ctx.stroke();
    for (const [t0, t1] of [
      [0, (1 - opening) / 2],
      [(1 + opening) / 2, 1],
    ]) {
      if (t1 - t0 < 0.01) continue;
      const x0 = a.x + dx * t0,
        y0 = a.y + dy * t0,
        x1 = a.x + dx * t1,
        y1 = a.y + dy * t1;
      ctx.lineCap = "butt";
      ctx.strokeStyle = "#a8bac5";
      ctx.lineWidth = 23;
      ctx.beginPath();
      ctx.moveTo(x0, y0);
      ctx.lineTo(x1, y1);
      ctx.stroke();
      ctx.strokeStyle = "#e0e9ee";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(x0 + nx * 4, y0 + ny * 4);
      ctx.lineTo(x1 + nx * 4, y1 + ny * 4);
      ctx.stroke();
      ctx.fillStyle = "#e4b667";
      for (const [x, y] of [
        [x0, y0],
        [x1, y1],
      ]) {
        ctx.beginPath();
        ctx.arc(x, y, 3, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.restore();
  }
}
function render() {
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, W, H);
  ctx.save();
  if (fwImpactShake > 0) {
    const t = fwImpactShakePhase;
    ctx.translate(Math.sin(t * 2.1) * fwImpactShake, Math.cos(t * 2.7) * fwImpactShake * 0.6);
  }
  ctx.translate(camX, camY);
  ctx.scale(zoom, zoom);
  drawBattleLandscape();
  ctx.strokeStyle = "rgba(220,239,255,.11)";
  ctx.lineWidth = 1;
  for (let x = 0; x <= WORLD_W; x += 40) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, floor());
    ctx.stroke();
  }
  for (let y = 0; y < floor(); y += 40) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(WORLD_W, y);
    ctx.stroke();
  }
  for (let b of beams.filter((b) => b.background)) {
    let a = nodes[b.a],
      d = nodes[b.b];
    if (a && d) drawTimberDetail(a, d, b);
  }
  for (let b of beams.filter((b) => !b.background)) {
    let a = nodes[b.a],
      d = nodes[b.b];
    if (b.armorDoor) {
      const opening = (b.doorProgress || 0) * 1.0;
      const dx = d.x - a.x,
        dy = d.y - a.y,
        L = Math.hypot(dx, dy) || 1;
      const nx = -dy / L,
        ny = dx / L;
      // Fixed rail and pistons remain visible while two heavy plates slide apart.
      ctx.lineCap = "round";
      ctx.setLineDash([]);
      ctx.strokeStyle = "#263c4a";
      ctx.lineWidth = 23;
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(d.x, d.y);
      ctx.stroke();
      ctx.strokeStyle = "#718e9d";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(a.x + nx * 12, a.y + ny * 12);
      ctx.lineTo(d.x + nx * 12, d.y + ny * 12);
      ctx.stroke();
      const left = (1 - opening) / 2,
        right = (1 + opening) / 2;
      for (const [t0, t1] of [
        [0, left],
        [right, 1],
      ]) {
        if (t1 - t0 < 0.01) continue;
        const x0 = a.x + dx * t0,
          y0 = a.y + dy * t0,
          x1 = a.x + dx * t1,
          y1 = a.y + dy * t1;
        ctx.lineCap = "butt";
        ctx.strokeStyle = "#9daeb9";
        ctx.lineWidth = 19;
        ctx.beginPath();
        ctx.moveTo(x0, y0);
        ctx.lineTo(x1, y1);
        ctx.stroke();
        ctx.strokeStyle = "#d9e6ed";
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(x0 + nx * 3, y0 + ny * 3);
        ctx.lineTo(x1 + nx * 3, y1 + ny * 3);
        ctx.stroke();
        ctx.fillStyle = "#efc16a";
        ctx.beginPath();
        ctx.arc(x1, y1, 3, 0, Math.PI * 2);
        ctx.arc(x0, y0, 3, 0, Math.PI * 2);
        ctx.fill();
      }
      if (opening > 0.04) {
        ctx.fillStyle = "#91edc7";
        ctx.beginPath();
        ctx.arc((a.x + d.x) / 2, (a.y + d.y) / 2, 3, 0, Math.PI * 2);
        ctx.fill();
      }
      continue;
    }
    if (b.armorWall) {
      drawArmorWall(a, d, b);
      continue;
    }
    drawTimberDetail(a, d, b);
  }
  for (let n of nodes) {
    drawSteelJoint(n);
  }
  if (drag) {
    // Construction length guide, measured from the actual snapped start joint.
    const startWorld = drag.start;
    const startSnap = snapBuildPoint(startWorld.x, startWorld.y);
    const ax = startSnap.x,
      ay = startSnap.y;
    let ex = drag.end.x,
      ey = Math.min(drag.end.y, floor());
    const tolerance = Math.max(9, 18 / zoom);
    if (Math.abs(ex - ax) <= tolerance) ex = ax;
    if (Math.abs(ey - ay) <= tolerance) ey = ay;
    const endSnap = snapBuildPoint(ex, ey, startSnap.index);
    ex = endSnap.x;
    ey = endSnap.y;
    // Highlight the snapped grid crosshair while dragging.
    if (
      Math.abs(ex / BUILD_GRID - Math.round(ex / BUILD_GRID)) < 0.001 ||
      Math.abs(ey / BUILD_GRID - Math.round(ey / BUILD_GRID)) < 0.001
    ) {
      ctx.save();
      ctx.strokeStyle = "rgba(255,213,110,.75)";
      ctx.lineWidth = 1.5 / zoom;
      ctx.beginPath();
      ctx.moveTo(ex - 12 / zoom, ey);
      ctx.lineTo(ex + 12 / zoom, ey);
      ctx.moveTo(ex, ey - 12 / zoom);
      ctx.lineTo(ex, ey + 12 / zoom);
      ctx.stroke();
      ctx.restore();
    }
    const length = Math.hypot(ex - ax, ey - ay);
    const allowed = length >= MINLEN && length <= MAXLEN;
    // Faint circular limit and endpoint marker show the permitted range.
    ctx.save();
    ctx.lineWidth = 2 / zoom;
    ctx.setLineDash([7 / zoom, 7 / zoom]);
    ctx.strokeStyle = "rgba(112,228,202,.8)";
    ctx.beginPath();
    ctx.arc(ax, ay, MAXLEN, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.strokeStyle = allowed ? "#91ffd2" : "#ff7777";
    ctx.lineWidth = 5 / zoom;
    ctx.beginPath();
    ctx.moveTo(ax, ay);
    ctx.lineTo(ex, ey);
    ctx.stroke();
    ctx.fillStyle = allowed ? "#91ffd2" : "#ff7777";
    ctx.beginPath();
    ctx.arc(ex, ey, 6 / zoom, 0, Math.PI * 2);
    ctx.fill();
    // Keep the label legible at every camera zoom level.
    const label = Math.round(length) + " / " + MAXLEN + (allowed ? "" : "  ✕");
    ctx.font = "bold " + 15 / zoom + "px sans-serif";
    const tw = ctx.measureText(label).width;
    const tx = ex + 12 / zoom,
      ty = ey - 18 / zoom;
    ctx.fillStyle = "rgba(12,25,35,.88)";
    ctx.fillRect(tx - 5 / zoom, ty - 17 / zoom, tw + 10 / zoom, 24 / zoom);
    ctx.fillStyle = allowed ? "#b5ffde" : "#ffb0a8";
    ctx.fillText(label, tx, ty);
    ctx.restore();
  } // Construction markers: translucent frame and progress percentage.
  for (const b of beams) {
    if (!(b.buildRemaining > 0)) continue;
    const a = nodes[b.a],
      d = nodes[b.b];
    if (!a || !d) continue;
    const progress = 1 - b.buildRemaining / b.buildTotal;
    ctx.save();
    ctx.lineCap = "round";
    ctx.lineWidth = b.armorDoor ? 15 : 8;
    ctx.strokeStyle = "rgba(255,205,110,.28)";
    ctx.setLineDash([10, 7]);
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(d.x, d.y);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.strokeStyle = "rgba(255,205,110,.92)";
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(a.x + (d.x - a.x) * progress, a.y + (d.y - a.y) * progress);
    ctx.stroke();
    ctx.restore();
  }

  // V13.32: genuine layered vector weapon: fixed carriage, rotating barrel.
  function drawSteampunkWeapon(cx, type, angle = 0, enemy = false, flash = 0) {
    cx.save();
    cx.lineJoin = "round";
    cx.lineCap = "round";
    const metal = "#26313a",
      edge = "#0e1720",
      gold = "#b77932",
      wood = "#925426",
      bright = "#e6ad59";
    // Rail-mounted wooden chassis and bolted steel base.
    cx.fillStyle = "#17232c";
    cx.strokeStyle = edge;
    cx.lineWidth = 2.7;
    cx.fillRect(-28, 6, 56, 9);
    cx.strokeRect(-28, 6, 56, 9);
    cx.fillStyle = wood;
    cx.fillRect(-23, -2, 46, 10);
    cx.fillStyle = gold;
    cx.fillRect(-23, 4, 46, 2);
    for (const x of [-19, 19]) {
      cx.fillStyle = "#18212a";
      cx.beginPath();
      cx.arc(x, 12, 6, 0, Math.PI * 2);
      cx.fill();
      cx.fillStyle = "#bda071";
      cx.beginPath();
      cx.arc(x, 12, 2.4, 0, Math.PI * 2);
      cx.fill();
    }
    // Rotating turret including the full barrel; not a pasted static sprite.
    cx.save();
    cx.translate(0, -10);
    cx.rotate(angle);
    cx.fillStyle = "#473322";
    cx.strokeStyle = edge;
    cx.lineWidth = 2.6;
    if (type === "rocket") {
      for (const y of [-10, 0, 10]) {
        cx.fillStyle = metal;
        cx.fillRect(-5, y - 5, 45, 9);
        cx.strokeRect(-5, y - 5, 45, 9);
        cx.fillStyle = "#bb7738";
        cx.fillRect(7, y - 5, 4, 9);
        cx.fillStyle = "#a43d27";
        cx.beginPath();
        cx.moveTo(40, y - 5);
        cx.lineTo(52, y - 0.5);
        cx.lineTo(40, y + 4);
        cx.closePath();
        cx.fill();
      }
    } else if (type === "mg" || type === "autocannon") {
      const count = type === "autocannon" ? 2 : 3;
      for (let i = 0; i < count; i++) {
        const y = (i - (count - 1) / 2) * 5;
        cx.fillStyle = metal;
        cx.fillRect(0, y - 2, 47, 4);
        cx.strokeRect(0, y - 2, 47, 4);
        cx.fillStyle = gold;
        cx.fillRect(13, y - 2, 4, 4);
      }
      cx.fillStyle = "#1c252d";
      cx.fillRect(40, -8, 10, 16);
    } else {
      const thick = type === "heavy" ? 11 : type === "mortar" ? 13 : 7;
      const len = type === "sniper" ? 59 : type === "mortar" ? 38 : 48;
      cx.fillStyle = metal;
      cx.strokeStyle = edge;
      cx.beginPath();
      cx.moveTo(-3, -thick);
      cx.lineTo(len, -thick * 0.8);
      cx.lineTo(len, thick * 0.8);
      cx.lineTo(-3, thick);
      cx.closePath();
      cx.fill();
      cx.stroke();
      cx.fillStyle = gold;
      for (const x of [8, 17, len - 9]) cx.fillRect(x, -thick * 1.0, 3, thick * 1.76);
      cx.fillStyle = "#111923";
      cx.fillRect(len - 4, -thick * 0.95, 7, thick * 1.9);
      if (type === "sniper") {
        cx.fillStyle = bright;
        cx.fillRect(3, -thick - 6, 22, 3);
      }
    }
    // Copper ring, gearing and side plate follow the barrel angle.
    cx.fillStyle = "#8b532b";
    cx.strokeStyle = edge;
    cx.lineWidth = 2.2;
    cx.beginPath();
    cx.arc(0, 0, 12, 0, Math.PI * 2);
    cx.fill();
    cx.stroke();
    cx.fillStyle = gold;
    cx.beginPath();
    cx.arc(0, 0, 7, 0, Math.PI * 2);
    cx.fill();
    cx.fillStyle = "#26323d";
    cx.beginPath();
    cx.arc(0, 0, 3.3, 0, Math.PI * 2);
    cx.fill();
    if (flash > 0) {
      const f = type === "rocket" ? 54 : type === "sniper" ? 64 : 52;
      const size = 7 + flash * 95;
      cx.fillStyle = "rgba(255,185,63,.55)";
      cx.beginPath();
      cx.arc(f, 0, size, 0, Math.PI * 2);
      cx.fill();
    }
    cx.restore();
    // Stationary armored housing in front of the barrel's pivot.
    cx.fillStyle = enemy ? "#653d35" : "#463b32";
    cx.strokeStyle = edge;
    cx.lineWidth = 2.3;
    cx.beginPath();
    cx.moveTo(-15, -5);
    cx.lineTo(-11, -21);
    cx.lineTo(8, -21);
    cx.lineTo(17, -6);
    cx.lineTo(11, 3);
    cx.lineTo(-13, 3);
    cx.closePath();
    cx.fill();
    cx.stroke();
    cx.strokeStyle = gold;
    cx.lineWidth = 2;
    cx.beginPath();
    cx.moveTo(-10, -17);
    cx.lineTo(8, -17);
    cx.stroke();
    cx.fillStyle = bright;
    for (const x of [-9, 10]) {
      cx.beginPath();
      cx.arc(x, -7, 1.8, 0, Math.PI * 2);
      cx.fill();
    }
    cx.fillStyle = "#f2bb62";
    cx.fillRect(-19, -3, 4, 5);
    cx.restore();
  }

  if (!window.__weaponCardsInitialized) {
    window.__weaponCardsInitialized = true;
    requestAnimationFrame(updateWeaponSkinCards);
  }
  // V13.78: Opaque wooden cladding over intact enclosed enemy compartments.
  // Panels are purely visual; beam damage opens gaps without changing hit detection.
  let enemyWoodCache = { stamp: 0, key: "", panels: [] };
  function drawEnemyWoodCladding(side, collectOnly = false) {
    // Identify actual enclosed compartments in the structural beam graph.
    // Each bounded face is rendered individually: triangles, trapezoids and polygons.
    const onRight = fwFacesLeft(side); // online guests see the sides swapped
    const left = onRight ? WORLD_W / 2 : 0,
      right = onRight ? WORLD_W : WORLD_W / 2;
    const edges = beams.filter(
      (b) =>
        b.hp > 0 &&
        (b.buildRemaining || 0) <= 0 &&
        nodes[b.a] &&
        nodes[b.b] &&
        nodes[b.a].x >= left &&
        nodes[b.a].x <= right &&
        nodes[b.b].x >= left &&
        nodes[b.b].x <= right,
    );
    if (!edges.length) return collectOnly ? [] : undefined;
    const adjacency = new Map();
    const add = (from, to) => {
      if (!adjacency.has(from)) adjacency.set(from, []);
      if (!adjacency.get(from).includes(to)) adjacency.get(from).push(to);
    };
    for (const b of edges) {
      add(b.a, b.b);
      add(b.b, b.a);
    }
    for (const [id, neighbors] of adjacency)
      neighbors.sort(
        (a, b) =>
          Math.atan2(nodes[a].y - nodes[id].y, nodes[a].x - nodes[id].x) -
          Math.atan2(nodes[b].y - nodes[id].y, nodes[b].x - nodes[id].x),
      );
    const visited = new Set(),
      faces = [];
    for (const [from, neighbors] of adjacency)
      for (const to of neighbors) {
        const key = from + ":" + to;
        if (visited.has(key)) continue;
        let a = from,
          b = to,
          poly = [],
          closed = false;
        for (let steps = 0; steps < edges.length * 2 + 4; steps++) {
          const k = a + ":" + b;
          if (visited.has(k)) break;
          visited.add(k);
          poly.push(nodes[a]);
          const nexts = adjacency.get(b);
          if (!nexts) break;
          const reverse = nexts.indexOf(a);
          if (reverse < 0) break;
          const c = nexts[(reverse - 1 + nexts.length) % nexts.length];
          a = b;
          b = c;
          if (a === from && b === to) {
            closed = true;
            break;
          }
        }
        if (!closed || poly.length < 3) continue;
        const area =
          poly.reduce((sum, v, i) => {
            const w = poly[(i + 1) % poly.length];
            return sum + v.x * w.y - w.x * v.y;
          }, 0) / 2;
        // The reverse winding is the unbounded exterior; never cover empty sky.
        if (area < -120 && Math.abs(area) < 300000) faces.push(poly);
      }
    if (collectOnly) return faces;
    ctx.save();
    for (const poly of faces) {
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(poly[0].x, poly[0].y);
      for (let i = 1; i < poly.length; i++) ctx.lineTo(poly[i].x, poly[i].y);
      ctx.closePath();
      ctx.clip();
      const x0 = Math.min(...poly.map((p) => p.x)),
        x1 = Math.max(...poly.map((p) => p.x));
      const y0 = Math.min(...poly.map((p) => p.y)),
        y1 = Math.max(...poly.map((p) => p.y));
      ctx.fillStyle = "#674125";
      ctx.fillRect(x0, y0, x1 - x0, y1 - y0);
      // Real planks are clipped to the compartment geometry, including diagonals.
      for (let y = Math.floor(y0 / 15) * 15; y < y1 + 15; y += 15) {
        ctx.fillStyle = Math.round(y / 15) % 2 ? "#81532e" : "#97643a";
        ctx.fillRect(x0, y, x1 - x0, 13.5);
        ctx.strokeStyle = "#bc8750";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(x0, y + 2);
        ctx.lineTo(x1, y + 2);
        ctx.stroke();
        ctx.strokeStyle = "#3a2417";
        ctx.beginPath();
        ctx.moveTo(x0, y + 13);
        ctx.lineTo(x1, y + 13);
        ctx.stroke();
      }
      // Iron frame follows the precise outline, not an enclosing rectangle.
      ctx.strokeStyle = "#2c2522";
      ctx.lineWidth = 8;
      ctx.beginPath();
      ctx.moveTo(poly[0].x, poly[0].y);
      for (let i = 1; i < poly.length; i++) ctx.lineTo(poly[i].x, poly[i].y);
      ctx.closePath();
      ctx.stroke();
      ctx.strokeStyle = "#c09359";
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.fillStyle = "#d9b67b";
      for (const v of poly) {
        ctx.beginPath();
        ctx.arc(v.x, v.y, 2.8, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }
    ctx.restore();
  }
  // Fog of war: fort walls and reactors remain visible, internal equipment is concealed.
  const viewerSide = "player"; // online guests see their own fort as "player" (sides swapped)
  const hideEnemyContents = !cheatMode;
  const concealedSide = viewerSide === "player" ? "enemy" : "player";
  const concealedFaces = hideEnemyContents ? drawEnemyWoodCladding(concealedSide, true) : [];
  // Show only portions of opposing equipment that extend OUTSIDE enclosed wooden panels.
  function clipOutsideEnemyPanels() {
    if (!concealedFaces.length) return;
    ctx.beginPath();
    ctx.rect(-10000, -10000, 30000, 30000);
    for (const poly of concealedFaces) {
      if (!poly.length) continue;
      ctx.moveTo(poly[0].x, poly[0].y);
      for (let i = 1; i < poly.length; i++) ctx.lineTo(poly[i].x, poly[i].y);
      ctx.closePath();
    }
    ctx.clip("evenodd");
  }

  // Draw projectiles behind the opaque fortress cladding: no visible shots inside concealed compartments.
  drawFlakEffects();
  for (let s of shots) {
    ctx.beginPath();
    ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
    ctx.shadowColor = "#ffae48";
    ctx.shadowBlur = 12;
    ctx.fillStyle = "#29323a";
    ctx.fill();
    ctx.strokeStyle = "#ffcf6d";
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.shadowBlur = 0;
  }
  drawReactor(playerCore);
  drawReactor(enemyCore);
  if (!cheatMode) {
    drawEnemyWoodCladding(viewerSide === "player" ? "enemy" : "player");
    drawVisibleEnemyArmorDoors(viewerSide === "player" ? "enemy" : "player");
  }
  for (const g of guns) {
    const concealedGun = hideEnemyContents && g.owner !== viewerSide;
    if (concealedGun) {
      ctx.save();
      clipOutsideEnemyPanels();
    }
    const n = weaponPosition(g);
    if (!n) continue;
    const type = g.type || "cannon",
      enemy = fwFacesLeft(g.owner);
    // The art mount is latched at construction time. Physics impulses may move
    // nodes a few pixels every simulation tick; that must NOT animate the sprite.
    // Re-anchor only after a genuine large displacement (e.g. a collapsing fort).
    if (!g.visualMount) g.visualMount = { x: n.x, y: n.y };
    // Keep the idle mount absolutely fixed. Repeated threshold crossings were
    // snapping the sprite between two positions under physics impulses.
    // A destroyed gun is removed by the game state, not by moving this sprite.

    // The barrel has a true parked pose. In particular, an unselected weapon
    // never receives physics/AI target noise through its display angle.
    const active =
      (g.type === "flak" && !!g.flakTarget) ||
      (!!window.FWOnlineMatch && !!g.lastAim && g.type !== "flak") ||
      (g.owner === "player" &&
        ((mode === "shoot" && selectedAimGuns.has(g)) ||
          (g.type === "autocannon" && (enemyOn || !!window.FWOnlineMatch) && !!g.autoTarget)));
    const parked = type === "mortar" ? FW_MORTAR_CONFIG.restAngle : 0;
    if (!active) {
      g.visualAngle = parked;
    } else {
      if (!Number.isFinite(g.visualAngle)) g.visualAngle = parked;
      const aim =
        type === "mortar" && g.owner === "player" && !aimTarget
          ? parked
          : Number.isFinite(g.angle)
            ? g.angle
            : parked;
      const aimLocal = enemy && window.FWOnlineMatch && aim !== parked ? fwMirrorAngle(aim) : aim;
      const diff = Math.atan2(Math.sin(aimLocal - g.visualAngle), Math.cos(aimLocal - g.visualAngle));
      if (Math.abs(diff) > 0.015) g.visualAngle += diff * 0.12;
    }
    ctx.save();
    ctx.translate(Math.round(g.visualMount.x * zoom) / zoom, Math.round(g.visualMount.y * zoom) / zoom);
    // V14.25: All weapon artwork 15% smaller than V14.24; physics and collisions unchanged.
    // Cannon-family weapons retain their earlier 5% reduction as well.
    ctx.scale(
      ["cannon", "heavy", "autocannon", "sniper", "mortar"].includes(type) ? 0.8075 : 0.85,
      ["cannon", "heavy", "autocannon", "sniper", "mortar"].includes(type) ? 0.8075 : 0.85,
    );
    // V14.26: Lower the visual artwork slightly after scaling; aiming and physics remain anchored.
    ctx.translate(0, 8);
    drawLayeredWeapon(ctx, type, g.visualAngle, enemy, g.flash || 0);
    ctx.restore();
    if (mode === "shoot" && selectedAimGuns.has(g)) {
      ctx.save();
      ctx.strokeStyle = "#68f2dc";
      ctx.lineWidth = 3 / zoom;
      ctx.setLineDash([7 / zoom, 5 / zoom]);
      ctx.beginPath();
      ctx.arc(n.x, n.y, 36, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = "#68f2dc";
      ctx.font = "bold 18px system-ui";
      ctx.textAlign = "center";
      ctx.fillText("✓", n.x, n.y - 31);
      ctx.restore();
    }
    // Visible circular progress indicators for every gun, including enemy weapons.
    const building = (g.buildRemaining || 0) > 0;
    const reloading = !building && (g.cooldown || 0) > 0 && (g.reloadTotal || 0) > 0;
    if ((building || reloading) && (cheatMode || g.owner === viewerSide)) {
      const duration = building ? g.buildTotal || 1 : g.reloadTotal;
      const remaining = building ? g.buildRemaining : g.cooldown;
      const progress = Math.max(0, Math.min(1, 1 - remaining / duration));
      const cx = n.x,
        cy = n.y - 47,
        rad = 19;
      ctx.save();
      ctx.fillStyle = "rgba(9,22,34,.88)";
      ctx.strokeStyle = "rgba(215,231,241,.50)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(cx, cy, rad + 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.strokeStyle = building ? "#ffcb72" : "#72e2f5";
      ctx.lineWidth = 5;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.arc(cx, cy, rad, -Math.PI / 2, -Math.PI / 2 + progress * Math.PI * 2);
      ctx.stroke();
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.font = "bold 12px system-ui";
      ctx.fillStyle = "#fff8e9";
      ctx.fillText(Math.ceil(remaining) + "s", cx, cy);
      ctx.font = "bold 9px system-ui";
      ctx.fillStyle = building ? "#ffe1a3" : "#a7edff";
      ctx.fillText(building ? "BAU" : "LÄDT", cx, cy + 35);
      ctx.restore();
    }
    if (concealedGun) ctx.restore();
  }
  for (const r of [...resources, ...aiResources]) {
    const concealedResource =
      hideEnemyContents && (aiResources.includes(r) ? "enemy" : "player") !== viewerSide;
    if (concealedResource) {
      ctx.save();
      clipOutsideEnemyPanels();
    }
    const b = beams.find((b) => b.id === r.beamId);
    if (!b) {
      if (concealedResource) ctx.restore();
      continue;
    }
    const a = nodes[b.a],
      z = nodes[b.b];
    if (!a || !z) {
      if (concealedResource) ctx.restore();
      continue;
    }
    const x = a.x + (z.x - a.x) * r.t,
      y = a.y + (z.y - a.y) * r.t - 20;
    ctx.save();
    ctx.translate(x, y);
    drawStructureDetails(r, 0, 0);
    // Baustellen sind klar erkennbar und erhalten einen Fortschrittsbalken.
    if ((r.buildRemaining || 0) > 0 && (cheatMode || r.owner === viewerSide)) {
      const fraction = Math.max(0, Math.min(1, 1 - r.buildRemaining / (r.buildTotal || 1)));
      ctx.fillStyle = "rgba(8,18,29,.76)";
      ctx.fillRect(-29, -49, 58, 71);
      ctx.strokeStyle = "#f5be69";
      ctx.lineWidth = 2;
      ctx.setLineDash([5, 4]);
      ctx.strokeRect(-25, -25, 50, 45);
      ctx.setLineDash([]);
      ctx.fillStyle = "#ffe0a1";
      ctx.font = "bold 11px system-ui";
      ctx.textAlign = "center";
      ctx.fillText("BAU", 0, -34);
      ctx.fillStyle = "#15232c";
      ctx.fillRect(-28, 26, 56, 9);
      ctx.fillStyle = "#ffca73";
      ctx.fillRect(-27, 27, 54 * fraction, 7);
      ctx.strokeStyle = "#d4e0e7";
      ctx.lineWidth = 1;
      ctx.strokeRect(-28, 26, 56, 9);
      ctx.fillStyle = "#fff1d7";
      ctx.font = "bold 12px system-ui";
      ctx.fillText(Math.ceil(r.buildRemaining) + " s", 0, 48);
    }
    if (r.type === "workshop" && (r.buildRemaining || 0) <= 0) {
      ctx.save();
      ctx.globalAlpha = 0.22;
      ctx.fillStyle = "#ffd38a";
      ctx.shadowColor = "#ffbb61";
      ctx.shadowBlur = 24;
      ctx.beginPath();
      ctx.arc(-12, 0, 13, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
    drawReactorBlast();
    ctx.restore();
    if (concealedResource) ctx.restore();
  }
  fwDrawLastShots();
  drawAimTrajectory();
  for (let p of particles) {
    if (!cheatMode && p.kind === "smoke" && p.muzzleOwner && p.muzzleOwner !== viewerSide) continue;
    ctx.save();
    const fade = Math.max(0, Math.min(1, p.life / (p.maxLife || 0.7)));
    if (p.kind === "smoke") {
      const radius = (p.size || 12) * (1.7 - fade * 0.5),
        grad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, radius);
      grad.addColorStop(0, "rgba(34,39,46," + fade * 0.37 + ")");
      grad.addColorStop(1, "rgba(28,35,41,0)");
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(p.x, p.y, radius, 0, Math.PI * 2);
      ctx.fill();
    } else if (p.kind === "shockwave") {
      ctx.strokeStyle = "rgba(255,194,101," + fade * 0.65 + ")";
      ctx.lineWidth = 3 + fade * 7;
      ctx.beginPath();
      ctx.arc(p.x, p.y, (p.size || 50) * (1.7 - fade), 0, Math.PI * 2);
      ctx.stroke();
    } else if (p.kind === "spark") {
      ctx.globalAlpha = fade;
      ctx.strokeStyle = "#ffdc83";
      ctx.shadowColor = "#ff982c";
      ctx.shadowBlur = 11;
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(p.x - p.vx * 0.025, p.y - p.vy * 0.025);
      ctx.stroke();
    } else if (p.kind === "metalSpark") {
      ctx.globalAlpha = fade;
      ctx.strokeStyle = "#fff1bf";
      ctx.shadowColor = "#ffae45";
      ctx.shadowBlur = 9;
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(p.x - p.vx * 0.027, p.y - p.vy * 0.027);
      ctx.stroke();
    } else if (p.kind === "woodShard" || p.kind === "metalShard") {
      ctx.globalAlpha = fade;
      ctx.translate(p.x, p.y);
      ctx.rotate((p.angle || 0) + (1 - fade) * (p.spin || 0));
      ctx.fillStyle =
        p.kind === "woodShard" ? (fade > 0.4 ? "#ab7543" : "#754729") : fade > 0.4 ? "#bac5cc" : "#63747f";
      ctx.strokeStyle = p.kind === "woodShard" ? "#50301e" : "#27343e";
      ctx.lineWidth = 0.8;
      ctx.beginPath();
      ctx.moveTo(-(p.size || 6) * 0.6, -2);
      ctx.lineTo((p.size || 6) * 0.85, -1);
      ctx.lineTo((p.size || 6) * 0.2, 3);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    } else if (p.kind === "dust") {
      const r = (p.size || 7) * (1.25 + 0.4 * (1 - fade));
      ctx.globalAlpha = fade * 0.28;
      ctx.fillStyle = "#a6a19a";
      ctx.beginPath();
      ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
      ctx.fill();
    } else if (p.kind === "debris") {
      ctx.globalAlpha = fade;
      ctx.translate(p.x, p.y);
      ctx.rotate(p.x * 0.09);
      ctx.fillStyle = "#71503b";
      ctx.fillRect(-3, -2, p.size || 6, 4);
    } else {
      ctx.globalAlpha = Math.min(1, p.life * 2);
      ctx.fillStyle = "#ffc268";
      ctx.fillRect(p.x, p.y, 4, 4);
    }
    ctx.restore();
  }
  ctx.globalAlpha = 1;
  ctx.restore();
  drawPlacementCursor();
}
function closestBeam(x, y, r, owner) {
  let result = null,
    best = r;
  for (const b of beams) {
    if (owner && b.owner !== owner) continue;
    const a = nodes[b.a],
      d = nodes[b.b],
      vx = d.x - a.x,
      vy = d.y - a.y,
      t = Math.max(0, Math.min(1, ((x - a.x) * vx + (y - a.y) * vy) / (vx * vx + vy * vy || 1))),
      dist = Math.hypot(x - (a.x + vx * t), y - (a.y + vy * t));
    if (dist < best) {
      best = dist;
      result = b;
    }
  }
  return result;
}

// V14.15: Layered, filtered battlefield sound design (offline Web Audio).
let soundEnabled = true,
  musicEnabled = true, // V15.60: real battle theme, on by default
  audioCtx = null,
  masterAudio = null,
  lastShotSound = 0,
  lastImpactSound = 0;
let audioCompressor = null,
  noiseCache = null;
function audioReady() {
  if (!soundEnabled && !musicEnabled) return null;
  try {
    if (!audioCtx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      audioCtx = new AC();
      masterAudio = audioCtx.createGain();
      masterAudio.gain.value = 0.58;
      audioCompressor = audioCtx.createDynamicsCompressor();
      audioCompressor.threshold.value = -15;
      audioCompressor.knee.value = 12;
      audioCompressor.ratio.value = 3.5;
      audioCompressor.attack.value = 0.004;
      audioCompressor.release.value = 0.18;
      masterAudio.connect(audioCompressor);
      audioCompressor.connect(audioCtx.destination);
    }
    if (audioCtx.state === "suspended") audioCtx.resume().catch(() => {});
    return audioCtx.state === "running" ? audioCtx : null;
  } catch (e) {
    return null;
  }
}
function soundTone(freq, endFreq, duration, volume, type = "sine", delay = 0) {
  const c = audioReady();
  if (!c) return;
  const t = c.currentTime + delay,
    o = c.createOscillator(),
    g = c.createGain();
  o.type = type;
  o.frequency.setValueAtTime(Math.max(20, freq), t);
  o.frequency.exponentialRampToValueAtTime(Math.max(20, endFreq), t + duration);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(Math.max(0.0002, volume), t + 0.006);
  g.gain.exponentialRampToValueAtTime(0.0001, t + duration);
  o.connect(g);
  g.connect(masterAudio);
  o.start(t);
  o.stop(t + duration + 0.025);
}
function soundNoise(duration, volume, lowpass = 1200, delay = 0, highpass = 35, attack = 0.002) {
  const c = audioReady();
  if (!c) return;
  if (!noiseCache) {
    const len = c.sampleRate * 2;
    noiseCache = c.createBuffer(1, len, c.sampleRate);
    const data = noiseCache.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
  }
  const src = c.createBufferSource(),
    hp = c.createBiquadFilter(),
    lp = c.createBiquadFilter(),
    g = c.createGain();
  const t = c.currentTime + delay;
  src.buffer = noiseCache;
  src.loop = true;
  src.loopStart = 0;
  src.loopEnd = noiseCache.duration;
  hp.type = "highpass";
  hp.frequency.value = highpass;
  lp.type = "lowpass";
  lp.frequency.value = lowpass;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.linearRampToValueAtTime(Math.max(0.0002, volume), t + attack);
  g.gain.exponentialRampToValueAtTime(0.0001, t + duration);
  src.connect(hp);
  hp.connect(lp);
  lp.connect(g);
  g.connect(masterAudio);
  src.start(t, Math.random() * (noiseCache.duration - 0.1));
  src.stop(t + duration + 0.02);
}
function playWeaponSound(type) {
  if (!soundEnabled) return;
  const now = performance.now();
  if (now - lastShotSound < 42) return;
  lastShotSound = now;
  const presets = {
    mg: [0.085, 0.12, 2600, 140, 0.048],
    flak: [0.095, 0.1, 2600, 180, 0.045],
    autocannon: [0.15, 0.19, 1800, 105, 0.1],
    cannon: [0.34, 0.32, 1100, 72, 0.22],
    rocket: [0.44, 0.19, 1450, 88, 0.17],
    sniper: [0.22, 0.25, 2200, 115, 0.13],
    mortar: [0.42, 0.3, 950, 65, 0.24],
    heavy: [0.54, 0.37, 820, 51, 0.32],
  };
  const [dur, level, cutoff, bass, thump] = presets[type] || presets.cannon;
  // Broadband transient and short filtered body, not a sustained electronic beep.
  soundNoise(Math.min(0.065, dur * 0.45), level * 0.82, 4200, 0, 160, 0.001);
  soundNoise(dur, level, cutoff, 0.008, 45, 0.003);
  soundTone(bass, bass * 0.38, Math.min(dur * 0.8, 0.32), thump, "sine", 0.004);
  if (type === "rocket") {
    soundNoise(0.4, 0.11, 650, 0.055, 80, 0.025);
    soundTone(135, 52, 0.3, 0.06, "sine", 0.035);
  }
}
function playImpactSound(damage, radius) {
  if (!soundEnabled) return;
  const now = performance.now();
  if (now - lastImpactSound < 85) return;
  lastImpactSound = now;
  const size = Math.min(1.6, Math.max(0.55, (radius || 95) / 100));
  // Sharp crack, low pressure wave and slowly decaying debris/rumble.
  soundNoise(0.07, 0.32 * size, 4200, 0, 120, 0.001);
  soundNoise(0.27 * size, 0.23 * size, 1250, 0.014, 50, 0.006);
  soundTone(86 * size, 27, 0.37 * size, 0.27 * size, "sine", 0.009);
  soundNoise(0.62 * size, 0.115 * size, 420, 0.075, 28, 0.016);
  soundNoise(0.28 * size, 0.055 * size, 2600, 0.13, 450, 0.014);
}
function playBuildSound() {
  if (soundEnabled) {
    soundNoise(0.075, 0.045, 1900, 0, 350, 0.002);
    soundTone(260, 135, 0.105, 0.06, "sine");
  }
}
function playResearchSound() {
  if (soundEnabled) {
    soundTone(440, 660, 0.12, 0.06, "sine");
    soundTone(660, 880, 0.15, 0.06, "sine", 0.13);
  }
}
let musicPhase = 0,
  musicStep = -1;
function updateMusic(dt) {
  if (!musicEnabled || paused || document.getElementById("mainOverlay")?.hidden === false) return;
  musicPhase += dt;
  if (musicPhase < 1.5) return;
  musicPhase = 0;
  musicStep = (musicStep + 1) % 8;
  const bass = [55, 55, 65.4, 55, 49, 49, 65.4, 73.4][musicStep];
  const fwGain = window.fwMusicGain ? fwMusicGain() : 1;
  if (fwGain <= 0) return;
  soundTone(bass, bass * 0.97, 1.25, 0.028 * fwGain, "sine");
  if (musicStep % 2 === 0) soundTone(bass * 2, bass * 1.9, 0.8, 0.012 * fwGain, "triangle");
}
document.addEventListener("pointerdown", audioReady, { passive: true });
document.addEventListener("keydown", audioReady);
// Player autocannons are autonomous turrets. Other weapons remain manual.
// Target and fire are updated at simulation cadence, not in the renderer.
function updatePlayerAutocannons(dt) {
  // Online: host simulates both sides. Offline: retain the original AI-opponent behavior.
  const online = !!window.FWOnlineMatch;
  if (gameOver || (!enemyOn && !online)) return;
  for (const g of guns) {
    if (g.type !== "autocannon" || (g.buildRemaining || 0) > 0) continue;
    if (g.owner !== "player" && !(online && g.owner === "enemy")) continue;
    const pos = weaponPosition(g);
    if (!pos || !beams.some((b) => b.id === g.beamId && b.hp > 0 && (b.buildRemaining || 0) <= 0)) continue;
    const opponent = g.owner === "player" ? "enemy" : "player";
    const direction = g.owner === "player" ? 1 : -1;
    g.autoScan = (g.autoScan || 0) - dt;
    if (g.autoScan <= 0 || !g.autoTarget) {
      g.autoScan = 0.3;
      const candidates = [];
      for (const w of guns)
        if (w.owner === opponent && (w.buildRemaining || 0) <= 0) {
          const p = weaponPosition(w);
          if (p) candidates.push({ x: p.x, y: p.y, weight: 0 });
        }
      for (const r of opponent === "enemy" ? aiResources : resources) {
        const b = beams.find((b) => b.id === r.beamId);
        if (!b || b.hp <= 0) continue;
        const a = nodes[b.a],
          z = nodes[b.b];
        if (a && z)
          candidates.push({
            x: a.x + (z.x - a.x) * (r.t ?? 0.5),
            y: a.y + (z.y - a.y) * (r.t ?? 0.5) - 20,
            weight: 90,
          });
      }
      const core = opponent === "enemy" ? enemyCore : playerCore;
      if (core && !core.dead) candidates.push({ x: core.x, y: core.y, weight: 170 });
      const targets = candidates.filter(
        (t) => (t.x - pos.x) * direction > 30 && !aiOwnShotBlocked(g, t.x, t.y),
      );
      targets.sort(
        (a, b) =>
          Math.hypot(a.x - pos.x, a.y - pos.y) + a.weight - Math.hypot(b.x - pos.x, b.y - pos.y) - b.weight,
      );
      g.autoTarget = targets[0] || null;
    }
    if (!g.autoTarget) continue;
    const target = g.autoTarget;
    const angle = calculateLaunchAngle(g, target.x, target.y);
    if (!Number.isFinite(angle)) continue;
    g.angle = angle;
    const current = Number.isFinite(g.visualAngle) ? g.visualAngle : 0;
    const difference = Math.atan2(Math.sin(angle - current), Math.cos(angle - current));
    if ((g.cooldown || 0) <= 0 && energy >= WEAPONS.autocannon.energy) {
      if (fireGun(g.owner, target.x, target.y, g)) {
        energy -= WEAPONS.autocannon.energy;
        g.autoScan = 0;
      }
    }
  }
}
// V14.27: Verify the REAL remaining door aperture against the projectile arc.
// A fully open door still has 6% solid plate at each end.
// V14.39: Use the same swept collision geometry as the real projectile,
// with a small safety margin for discrete integration and moving structures.
// A door is safe only if BOTH solid end plates stay clear of the whole shell.
function safeDoorArc(shot, door, fullyOpen = true) {
  const a = nodes[door.a],
    b = nodes[door.b];
  if (!a || !b || door.hp <= 0) return false;
  const opening = (fullyOpen ? 1 : door.doorProgress || 0) * 1.0;
  const ranges = [
    [0, (1 - opening) / 2],
    [(1 + opening) / 2, 1],
  ];
  const gravity = GRAV * 0.45;
  const radius = (shot.r || 0) + 7; // align clearance with actual projectile collision tolerance
  for (let t = 0; t < 2; t += 0.008) {
    const t1 = t + 0.008;
    const x0 = shot.x + shot.vx * t,
      y0 = shot.y + shot.vy * t + (gravity * t * t) / 2;
    const x1 = shot.x + shot.vx * t1,
      y1 = shot.y + shot.vy * t1 + (gravity * t1 * t1) / 2;
    for (const [u, v] of ranges) {
      if (v - u < 0.01) continue;
      if (
        segmentHit(
          x0,
          y0,
          x1,
          y1,
          a.x + (b.x - a.x) * u,
          a.y + (b.y - a.y) * u,
          a.x + (b.x - a.x) * v,
          a.y + (b.y - a.y) * v,
          radius,
        )
      )
        return false;
    }
  }
  return true;
}
// Recheck ALL friendly doors against the current structure immediately before
// releasing a waiting shot. Other doors may have moved into its flight path.
function safeVolleyRelease(shot) {
  const owner = shot.enemy ? "enemy" : "player";
  return beams.every(
    (door) => !door.armorDoor || door.owner !== owner || door.hp <= 0 || safeDoorArc(shot, door, false),
  );
}

function fireGun(owner, tx, ty, preferred = null) {
  const g = preferred
    ? preferred.owner === owner &&
      preferred.type !== "flak" &&
      weaponPosition(preferred) &&
      (preferred.cooldown || 0) <= 0
      ? preferred
      : null
    : guns.find((g) => g.owner === owner && g.type !== "flak" && weaponPosition(g) && (g.cooldown || 0) <= 0);
  if (!g || g.buildRemaining > 0 || !beams.some((b) => b.id === g.beamId && (b.buildRemaining || 0) <= 0))
    return false;
  const spec = WEAPONS[g.type || "cannon"],
    n = weaponPosition(g),
    dx = tx - n.x,
    dy = ty - n.y;
  // Every selected weapon solves its own trajectory toward the SAME target.
  // This also compensates for different mounting heights and muzzle offsets.
  const angle = calculateLaunchAngle(g, tx, ty);
  g.angle = angle;
  // V14.21: Check the actual ballistic path against every friendly armor door.
  // Do not spawn a moving projectile until all blocking doors are fully open.
  if (shots.some((s) => s.waitDoorIds?.length && s.waitGunId === g.id)) return false;
  const muzzleCheck = weaponMuzzle(g, angle);
  const vx0 = Math.cos(angle) * spec.speed,
    vy0 = Math.sin(angle) * spec.speed;
  const blockingDoors = [];
  for (const door of beams) {
    if (!door.armorDoor || door.owner !== owner || (door.buildRemaining || 0) > 0 || door.hp <= 0) continue;
    const a = nodes[door.a],
      b = nodes[door.b];
    if (!a || !b) continue;
    // Sample the ballistic arc up to 2 seconds, including projectile thickness.
    let intersects = false;
    for (let t = 0; t < 2.0; t += 0.035) {
      const t2 = t + 0.035;
      const x0 = muzzleCheck.x + vx0 * t,
        y0 = muzzleCheck.y + vy0 * t + (GRAV * 0.45 * t * t) / 2;
      const x1 = muzzleCheck.x + vx0 * t2,
        y1 = muzzleCheck.y + vy0 * t2 + (GRAV * 0.45 * t2 * t2) / 2;
      if (segmentHit(x0, y0, x1, y1, a.x, a.y, b.x, b.y, spec.ball + 7)) {
        intersects = true;
        break;
      }
    }
    if (intersects) blockingDoors.push(door);
  }
  // If the projectile clips the door's fixed end plates even when fully
  // open, refuse to fire rather than destroying the player's own base.
  const candidate = { x: muzzleCheck.x, y: muzzleCheck.y, vx: vx0, vy: vy0, r: spec.ball };
  if (blockingDoors.some((door) => !safeDoorArc(candidate, door, true))) return false;
  const waitingForDoors = blockingDoors.length > 0;
  if (!playerVolleyPreparing)
    for (const door of blockingDoors) door.doorTimer = Math.max(door.doorTimer || 0, 2);
  if (!waitingForDoors && !playerVolleyPreparing) {
    g.flash = 0.13;
    playWeaponSound(g.type || "cannon");
  }
  if (spec.magazine) {
    g.ammo = (g.ammo ?? spec.magazine) - 1;
    if (g.ammo <= 0) {
      g.cooldown = spec.reload;
      g.reloadTotal = spec.reload;
      g.ammo = spec.magazine;
    } else {
      g.cooldown = spec.shotDelay;
      g.reloadTotal = 0;
    }
  } else {
    g.cooldown = spec.reload || spec.cooldown;
    g.reloadTotal = g.cooldown;
  }
  if (doorMode === "auto") g.doorTimer = 0.95;
  const muzzle = weaponMuzzle(g, angle),
    x = muzzle.x,
    y = muzzle.y;
  shots.push({
    x,
    y,
    px: x,
    py: y,
    vx: Math.cos(angle) * spec.speed,
    vy: Math.sin(angle) * spec.speed,
    r: spec.ball,
    damage: spec.damage,
    radius: spec.radius,
    life: 9,
    launchDelay: 0,
    waitDoorIds: blockingDoors.map((d) => d.id),
    waitGunId: waitingForDoors ? g.id : null,
    waitGunType: waitingForDoors ? g.type || "cannon" : null,
    enemy: owner === "enemy",
    weaponType: g.type,
    sourceGunIndex: guns.indexOf(g),
    mountBeamId: g.beamId,
    targetX: tx,
    targetY: ty,
  });
  for (let i = 0; i < (!waitingForDoors ? (g.type === "mg" ? 2 : 6) : 0); i++) {
    const speed = 22 + Math.random() * 55,
      spread = angle + (Math.random() - 0.5) * 1.5;
    particles.push({
      x,
      y,
      vx: Math.cos(spread) * speed,
      vy: Math.sin(spread) * speed - 15,
      life: 0.45 + Math.random() * 0.6,
      maxLife: 1.05,
      kind: "smoke",
      muzzleOwner: owner,
      size: 7 + Math.random() * 7,
    });
  }
  return true;
}
// Closest approach of two line segments, including projectile radius.
function segmentHit(ax, ay, bx, by, cx, cy, dx, dy, r) {
  let best = null;
  for (let i = 0; i <= 12; i++) {
    let t = i / 12,
      x = ax + (bx - ax) * t,
      y = ay + (by - ay) * t,
      vx = dx - cx,
      vy = dy - cy,
      u = Math.max(0, Math.min(1, ((x - cx) * vx + (y - cy) * vy) / (vx * vx + vy * vy || 1)));
    if (Math.hypot(x - (cx + u * vx), y - (cy + u * vy)) <= r) {
      best = { t, x, y };
      break;
    }
  }
  return best;
}
// Dynamische Bau-KI: bewertet vorhandene Struktur, Schäden, Waffen und Ressourcen.
const DIFFICULTY = {
  easy: {
    label: "Leicht",
    thinkMin: 0.65,
    thinkSpread: 0.25,
    fireChance: 0.53,
    maintainChance: 0.3,
    aimNoise: 58,
    // seconds between AI fire decisions (base + random spread) and weapon cap
    fireDelay: 5.5,
    fireDelaySpread: 2.0,
    maxGuns: 3,
  },
  normal: {
    label: "Normal",
    thinkMin: 0.58,
    thinkSpread: 0.22,
    fireChance: 1,
    maintainChance: 1,
    aimNoise: 0,
    fireDelay: 1.0,
    fireDelaySpread: 0.45,
    maxGuns: 5,
  },
  hard: {
    label: "Schwer",
    thinkMin: 0.38,
    thinkSpread: 0.14,
    fireChance: 1,
    maintainChance: 1,
    aimNoise: 0,
    fireDelay: 0.35,
    fireDelaySpread: 0.15,
    maxGuns: 6,
  },
};
let difficulty = "normal";
let aiFireDecisionTimer = 0;
function setDifficulty(value) {
  if (!DIFFICULTY[value]) return;
  difficulty = value;
  document
    .querySelectorAll("[data-difficulty]")
    .forEach((b) => b.classList.toggle("selected", b.dataset.difficulty === value));
  document.getElementById("difficultyBadge").textContent = "KI: " + DIFFICULTY[value].label;
}
document
  .querySelectorAll("[data-difficulty]")
  .forEach((b) => b.addEventListener("click", () => setDifficulty(b.dataset.difficulty)));
document.getElementById("reset").addEventListener("click", () => {
  paused = true;
  document.getElementById("difficultyOverlay").hidden = false;
});
document.getElementById("difficultyStart").addEventListener("click", () => {
  document.getElementById("difficultyOverlay").hidden = true;
  reset();
  startOpeningCamera();
  menuHasGame = true;
  document.getElementById("mainContinue").disabled = false;
});
let aiMetal = 120,
  aiEnergy = 100,
  aiThink = 0,
  aiStage = 0,
  aiLevel = 0,
  aiRebuild = 0,
  aiShots = 0,
  aiLastAction = "Start",
  aiBuildStyle = 0,
  aiBuildMirror = 1;
let aiBlueprint = [];
let aiStallTicks = 0,
  aiLastGunCount = 0,
  aiShellAttempts = 0;
let aiStrategy = {
  style: "balanced",
  bias: Math.random() * 2 - 1,
  revision: 0,
  lastReview: 0,
  lastIntegrity: 0,
  damagePressure: 0,
};
const AI_STYLES = ["compact", "tower", "battery"];
function aiReviewStrategy() {
  const own = beams.filter((b) => b.owner === "enemy" && b.hp > 0);
  const integrity = own.reduce((sum, b) => sum + Math.max(0, b.hp), 0);
  const current = performance.now();
  if (current - aiStrategy.lastReview < 7000) return;
  const old = aiStrategy.lastIntegrity || integrity;
  const loss = Math.max(0, old - integrity);
  aiStrategy.damagePressure = aiStrategy.damagePressure * 0.6 + Math.min(2, loss / 170);
  aiStrategy.lastIntegrity = integrity;
  aiStrategy.lastReview = current;
  const enemyGuns = guns.filter((g) => g.owner === "enemy" && g.hp > 0).length;
  const playerGuns = guns.filter((g) => g.owner === "player" && g.hp > 0).length;
  // Switch plans if current fort is suffering or the player's arsenal changes.
  if (loss > 85 || aiStrategy.revision === 0 || Math.random() < 0.1) {
    const scores = {
      compact: 1.1 + aiStrategy.damagePressure * 0.9 + (playerGuns > enemyGuns ? 0.3 : 0),
      tower: 1.0 + (playerGuns < 2 ? 0.55 : 0) - aiStrategy.damagePressure * 0.4,
      battery: 1.0 + (enemyGuns < playerGuns ? 0.6 : 0) + Math.min(1, aiMetal / 300) * 0.3,
    };
    const options = AI_STYLES.map((style) => ({ style, score: scores[style] + Math.random() * 0.95 })).sort(
      (a, b) => b.score - a.score,
    );
    const next = options[0].style;
    if (next !== aiStrategy.style) {
      aiStrategy.style = next;
      aiStrategy.revision++;
    } else if (!aiStrategy.revision) aiStrategy.revision = 1;
  }
}

function startEnemy() {
  if (enemyStarted) {
    enemyOn = true;
    return;
  }
  enemyStarted = true;
  enemyOn = true;
  enemyReady = true;
  aiMetal = 105;
  aiEnergy = 35;
  aiStallTicks = 0;
  aiLastGunCount = 0;
  aiShellAttempts = 0;
  aiThink = DIFFICULTY[difficulty].thinkMin;
  aiFireDecisionTimer = 0;
  aiShots = 0;
  aiStage = 0;
  aiLevel = 0;
  aiBuildStyle = 0;
  aiBuildMirror = 1;
  aiStrategy = {
    style: AI_STYLES[Math.floor(Math.random() * 3)],
    bias: Math.random() * 2 - 1,
    revision: 1,
    lastReview: 0,
    lastIntegrity: 0,
    damagePressure: 0,
  };
  // The opponent starts with exactly the same fort and no mounted weapons.
  starterFortAt(1920, "enemy");
  aiBlueprint = beams
    .filter((b) => b.owner === "enemy")
    .map((b) => ({ x1: nodes[b.a].homeX, y1: nodes[b.a].homeY, x2: nodes[b.b].homeX, y2: nodes[b.b].homeY }));
  updateStructuralSupport();
  fwUpdateBeamCount();
  document.getElementById("enemy").classList.add("active");
  document.getElementById("tip").textContent =
    "Beide Seiten starten mit derselben Festung und ohne Waffen. Die KI rüstet später selbst auf.";
}
// Keep future construction clear of existing friendly firing lanes.
// Uses the real ballistic blocker check after a candidate has been built.
// V14.34: evaluate actual ballistic corridors before committing new supports.
// This is geometric planning, not a predetermined fortress blueprint.
function aiProposedBeamBlocksShot(x1, y1, x2, y2) {
  const active = guns.filter(
    (g) => g.owner === "enemy" && g.hp > 0 && (g.buildRemaining || 0) <= 0 && weaponPosition(g),
  );
  if (!active.length || !playerCore || playerCore.dead) return false;
  for (const gun of active) {
    const pos = weaponPosition(gun),
      spec = WEAPONS[gun.type || "cannon"];
    if (!pos || !spec || aiOwnShotBlocked(gun, playerCore.x, playerCore.y)) continue;
    const angle = calculateLaunchAngle(gun, playerCore.x, playerCore.y);
    let px = pos.x + Math.cos(angle) * 58,
      py = pos.y + Math.sin(angle) * 58;
    let vx = Math.cos(angle) * spec.speed,
      vy = Math.sin(angle) * spec.speed;
    for (let k = 0; k < 280; k++) {
      const ox = px,
        oy = py;
      vy += GRAV * 0.45 * 0.025;
      px += vx * 0.025;
      py += vy * 0.025;
      if (px < 0 || px > WORLD_W || py >= floor()) break;
      if (segmentHit(ox, oy, px, py, x1, y1, x2, y2, (spec.ball || 5) + 6)) return true;
      if (Math.hypot(px - playerCore.x, py - playerCore.y) < 22) break;
    }
  }
  return false;
}
function aiProtectFiringLanes(newBeam) {
  if (!newBeam || newBeam.owner !== "enemy" || newBeam.armorDoor) return;
  const ready = guns.filter(
    (g) => g.owner === "enemy" && (g.buildRemaining || 0) <= 0 && g.hp > 0 && weaponPosition(g),
  );
  if (!ready.length) return;
  const target = { x: playerCore.x, y: playerCore.y };
  // New beams that interfere with a gun's firing lane become rear-layer supports.
  for (const gun of ready) {
    if (aiShotBlockers(gun, target.x, target.y).some((b) => b.id === newBeam.id)) {
      newBeam.background = true;
      aiLastAction = "Stütze hinter Schussfeld";
      break;
    }
  }
}
function aiBeam(x1, y1, x2, y2) {
  if (aiMetal < cost || aiCandidateInterferesWithEquipment(x1, y1, x2, y2)) return false;
  const preserveFiringLane = aiProposedBeamBlocksShot(x1, y1, x2, y2);
  const before = nodes.length;
  const a = getNode(x1, y1),
    b = getNode(x2, y2);
  const previous = buildingEnemy;
  buildingEnemy = true;
  const ok = beam(a, b, true);
  buildingEnemy = previous;
  if (ok) {
    aiMetal -= cost;
    aiLastAction = "Baue Balken";
    const built = beams[beams.length - 1];
    built.buildRemaining = BUILD_TIMES.wood;
    built.buildTotal = BUILD_TIMES.wood;
    if (preserveFiringLane) {
      built.background = true;
      aiLastAction = "Stütze hinter Schussfeld";
    } else aiProtectFiringLanes(built);
    if (
      !aiBlueprint.some(
        (e) =>
          (Math.hypot(e.x1 - x1, e.y1 - y1) < 3 && Math.hypot(e.x2 - x2, e.y2 - y2) < 3) ||
          (Math.hypot(e.x1 - x2, e.y1 - y2) < 3 && Math.hypot(e.x2 - x1, e.y2 - y1) < 3),
      )
    )
      aiBlueprint.push({ x1, y1, x2, y2 });
    return true;
  }
  if (nodes.length > before) nodes.length = before;
  return false;
}
function aiSetBackground(b) {
  // Move existing AI beams to the rear layer; never move doors or foundations.
  if (!b || b.owner !== "enemy" || b.background || b.armorDoor || b.hp <= 0) return false;
  b.background = true;
  return true;
}
function aiFreeMounts() {
  const candidates = beams.filter(
    (b) => b.owner === "enemy" && aiHorizontalBeam(b) && (b.buildRemaining || 0) <= 0,
  );
  return candidates
    .map((b) => {
      const a = nodes[b.a],
        z = nodes[b.b],
        x = (a.x + z.x) / 2,
        y = (a.y + z.y) / 2 - 14;
      return { b, x, y, point: { beamId: b.id, t: 0.5, x, y } };
    })
    .filter((c) => !aiMountOccupied(c.x, c.y, 100));
}
// Adaptive construction: evaluate current structure, not a fixed list of coordinates.
// V14.09: emergent structural evaluation; no coordinates or prefab blueprints.
function aiCandidateQuality(x1, y1, x2, y2, own) {
  const cx = (x1 + x2) / 2,
    cy = (y1 + y2) / 2;
  const dx = x2 - x1,
    dy = y2 - y1;
  const length = Math.hypot(dx, dy);
  const nearby = own.filter((b) => {
    const a = nodes[b.a],
      z = nodes[b.b];
    if (!a || !z) return false;
    return Math.hypot((a.x + z.x) / 2 - cx, (a.y + z.y) / 2 - cy) < 130;
  }).length;
  // Reward joining existing joints and triangular braces, discourage tall exposed spires.
  const existing = own.flatMap((b) => [nodes[b.a], nodes[b.b]]).filter(Boolean);
  const endpointSupport = existing.some((n) => Math.hypot(n.x - x2, n.y - y2) < 7);
  const diagonal = Math.abs(dx) > 20 && Math.abs(dy) > 20;
  const height = Math.max(0, floor() - cy);
  let value = (endpointSupport ? 6 : 0) + (diagonal && nearby >= 2 ? 4 : 0) + Math.min(nearby, 5) * 0.7;
  if (!endpointSupport && height > 230) value -= (height - 230) * 0.032;
  if (!endpointSupport && nearby < 2) value -= 7;
  // Do not create a wall immediately in front of a gun, including a gun above the wall.
  for (const gun of guns.filter((g) => g.owner === "enemy" && g.hp > 0)) {
    const p = weaponPosition(gun);
    if (!p) continue;
    const ahead = cx < p.x && cx > p.x - 240;
    if (ahead && Math.abs(cy - p.y) < 85) value -= 15;
    if (Math.hypot(cx - p.x, cy - p.y) < 50) value -= 12;
  }
  return value;
}
// V14.11: spatial reasoning based on current equipment, not a prefab layout.
function aiEquipmentFootprintClear(x, y, kind) {
  const radius = kind === "gun" ? 43 : kind === "workshop" ? 45 : kind === "wind" ? 34 : 38;
  for (const item of [...guns.filter((g) => g.owner === "enemy" && g.hp > 0), ...aiResources]) {
    const b = beams.find((b) => b.id === item.beamId);
    if (!b) continue;
    const a = nodes[b.a],
      z = nodes[b.b];
    if (!a || !z) continue;
    const t = item.t ?? 0.5,
      px = a.x + (z.x - a.x) * t,
      py = a.y + (z.y - a.y) * t - 14;
    const other =
      item.type === "workshop"
        ? 39
        : item.type === "wind"
          ? 30
          : item.owner === "enemy" && guns.includes(item)
            ? 41
            : 35;
    const vertical = kind === "gun" ? 48 : item.type === "wind" ? 63 : 51;
    if (Math.abs(px - x) < radius + other && Math.abs(py - y) < vertical) return false;
  }
  return true;
}
function aiCandidateInterferesWithEquipment(x1, y1, x2, y2) {
  // A new strut must not pass through the usable body of an existing building or gun.
  for (const item of [...guns.filter((g) => g.owner === "enemy" && g.hp > 0), ...aiResources]) {
    const b = beams.find((b) => b.id === item.beamId);
    if (!b) continue;
    const a = nodes[b.a],
      z = nodes[b.b];
    if (!a || !z) continue;
    const t = item.t ?? 0.5,
      px = a.homeX + (z.homeX - a.homeX) * t,
      py = a.homeY + (z.homeY - a.homeY) * t - 14;
    const vx = x2 - x1,
      vy = y2 - y1,
      den = vx * vx + vy * vy || 1;
    const u = Math.max(0, Math.min(1, ((px - x1) * vx + (py - y1) * vy) / den));
    const dist = Math.hypot(x1 + u * vx - px, y1 + u * vy - py);
    // The mounting beam below the object is intentional; other beams aren't.
    if (
      b &&
      Math.hypot(
        (nodes[b.a].homeX + nodes[b.b].homeX) / 2 - (x1 + x2) / 2,
        (nodes[b.a].homeY + nodes[b.b].homeY) / 2 - (y1 + y2) / 2,
      ) < 7
    )
      continue;
    if (dist < (guns.includes(item) ? 37 : item.type === "workshop" ? 43 : 33)) return true;
  }
  return false;
}
// Exact segment intersection: the projectile sampling routine uses only 12
// points and cannot reliably detect thin doors across a 1,500 px sightline.
function aiExactLineCross(ax, ay, bx, by, cx, cy, dx, dy) {
  const rx = bx - ax,
    ry = by - ay,
    sx = dx - cx,
    sy = dy - cy;
  const den = rx * sy - ry * sx;
  if (Math.abs(den) < 1e-9) return false;
  const qx = cx - ax,
    qy = cy - ay;
  const t = (qx * sy - qy * sx) / den,
    u = (qx * ry - qy * rx) / den;
  return t > 0 && t < 1 && u >= 0 && u <= 1;
}
// V14.74: protection is judged per weapon by a true attacker-to-gun
// intersection, never by the number of nearby doors.
function aiThreatInterceptsBeam(b, gun, margin = 8) {
  const p = weaponPosition(gun);
  if (!p || !playerCore) return false;
  const a = nodes[b.a],
    z = nodes[b.b];
  if (!a || !z) return false;
  const centerX = (a.x + z.x) / 2,
    centerY = (a.y + z.y) / 2;
  if (centerX <= playerCore.x + 10 || centerX >= p.x - 30 || p.x - centerX > 138) return false;
  if (Math.abs(centerY - p.y) > 76) return false;
  return aiExactLineCross(playerCore.x, playerCore.y, p.x, p.y - 10, a.x, a.y, z.x, z.y);
}
function aiGunDoor(gun, includePending = false) {
  return (
    beams.find(
      (b) =>
        b.owner === "enemy" &&
        b.hp > 0 &&
        b.armorDoor &&
        !b.background &&
        (includePending || (b.buildRemaining || 0) <= 0) &&
        aiThreatInterceptsBeam(b, gun, 9),
    ) || null
  );
}
function aiGunDoorCandidate(gun) {
  const p = weaponPosition(gun);
  if (!p) return null;
  const candidates = [];
  for (const b of beams) {
    if (
      b.owner !== "enemy" ||
      b.hp <= 0 ||
      b.background ||
      b.armorDoor ||
      b.armorWall ||
      (b.buildRemaining || 0) > 0 ||
      aiBeamUsed(b)
    )
      continue;
    const a = nodes[b.a],
      z = nodes[b.b];
    if (!a || !z) continue;
    const len = Math.hypot(z.x - a.x, z.y - a.y);
    if (len < 50 || len > 124 || !aiThreatInterceptsBeam(b, gun, 4)) continue;
    const mx = (a.x + z.x) / 2,
      my = (a.y + z.y) / 2;
    const vertical = Math.abs(a.y - z.y) > Math.abs(a.x - z.x) * 1.3;
    if (!vertical) continue;
    const score = 210 - Math.abs(p.x - mx - 80) * 0.8 - Math.abs(p.y - my) * 0.7;
    candidates.push({ b, score });
  }
  candidates.sort((a, b) => b.score - a.score);
  return candidates[0]?.b || null;
}
function aiInstallArmorDoor() {
  if (aiMetal < 48) return false;
  const unprotected = guns.filter(
    (g) => g.owner === "enemy" && g.hp > 0 && weaponPosition(g) && !aiGunDoor(g, true),
  );
  if (!unprotected.length) return false;
  // First convert a physically intersecting existing wall on the opponent side.
  for (const gun of unprotected) {
    const b = aiGunDoorCandidate(gun);
    if (!b) continue;
    b.armorDoor = true;
    b.armorWall = false;
    b.background = false;
    b.doorTimer = 0;
    b.doorProgress = 0;
    b.maxHp = 220;
    b.hp = Math.min(220, Math.max(b.hp, 180));
    b.buildRemaining = BUILD_TIMES.door;
    b.buildTotal = BUILD_TIMES.door;
    aiMetal -= 48;
    aiLastAction = "Panzertür direkt vor Waffe";
    return true;
  }
  // If no wall crosses the actual incoming-fire line, build an anchored wall.
  // Its starting point is selected from the CURRENT fortress structure; no blueprint.
  if (aiMetal < 48 + cost) return false;
  for (const gun of unprotected) {
    const p = weaponPosition(gun);
    if (!p) continue;
    const choices = [];
    const used = new Set();
    for (const b of beams) {
      if (b.owner !== "enemy" || b.hp <= 0) continue;
      for (const id of [b.a, b.b]) {
        if (used.has(id)) continue;
        used.add(id);
        const n = nodes[id];
        if (!n) continue;
        const forward = p.x - n.x;
        if (forward < 43 || forward > 120 || n.x < playerCore.x + 15 || Math.abs(n.y - p.y) > 94) continue;
        for (const dy of [-85, -72, 72, 85]) {
          const endY = n.homeY + dy;
          if (endY < floor() - 450 || endY > floor() - 12) continue;
          const fake = { a: id, b: id };
          // Exact segment intersection with the attacker's line to the gun.
          if (!aiExactLineCross(playerCore.x, playerCore.y, p.x, p.y - 10, n.homeX, n.homeY, n.homeX, endY))
            continue;
          if (aiCandidateInterferesWithEquipment(n.homeX, n.homeY, n.homeX, endY)) continue;
          const mid = (n.homeY + endY) / 2;
          choices.push({
            x: n.homeX,
            y1: n.homeY,
            y2: endY,
            score: 170 - Math.abs(forward - 80) - Math.abs(mid - p.y) * 0.5,
          });
        }
      }
    }
    choices.sort((a, b) => b.score - a.score);
    for (const c of choices.slice(0, 15)) {
      if (!aiBeam(c.x, c.y1, c.x, c.y2)) continue;
      const b = beams[beams.length - 1];
      b.armorDoor = true;
      b.armorWall = false;
      b.background = false;
      b.doorTimer = 0;
      b.doorProgress = 0;
      b.maxHp = 220;
      b.hp = 220;
      b.buildRemaining = BUILD_TIMES.door;
      b.buildTotal = BUILD_TIMES.door;
      aiMetal -= 48;
      aiLastAction = "Baut gezielten Waffenschutz";
      return true;
    }
  }
  // No existing anchor in front of the weapon: create a short linked support
  // at a tactical position, then erect the protective door on that support.
  if (aiMetal < 48 + cost * 2) return false;
  for (const gun of unprotected) {
    const p = weaponPosition(gun),
      mount = beams.find((b) => b.id === gun.beamId);
    if (!p || !mount) continue;
    const nearbyAnchors = [
      ...new Set(beams.filter((b) => b.owner === "enemy" && b.hp > 0).flatMap((b) => [b.a, b.b])),
    ]
      .map((id) => nodes[id])
      .filter(Boolean);
    const extensions = [];
    for (const anchor of nearbyAnchors) {
      for (const offset of [74, 92, 110, 58]) {
        const x = p.x - offset;
        if (x <= playerCore.x + 15) continue;
        const rayY =
          playerCore.y + ((p.y - 10 - playerCore.y) * (x - playerCore.x)) / (p.x - playerCore.x || 1);
        for (const direction of [-1, 1]) {
          const y = rayY + direction * 43,
            endY = rayY - direction * 48;
          if (y > floor() - 12 || endY > floor() - 12 || y < floor() - 470 || endY < floor() - 470) continue;
          const distance = Math.hypot(x - anchor.homeX, y - anchor.homeY);
          if (distance < MINLEN || distance > MAXLEN) continue;
          if (!aiExactLineCross(playerCore.x, playerCore.y, p.x, p.y - 10, x, y, x, endY)) continue;
          if (aiCandidateInterferesWithEquipment(anchor.homeX, anchor.homeY, x, y)) continue;
          if (aiCandidateInterferesWithEquipment(x, y, x, endY)) continue;
          extensions.push({
            ax: anchor.homeX,
            ay: anchor.homeY,
            x,
            y,
            endY,
            score: 210 - Math.abs(offset - 85) * 0.8 - distance * 0.16 - Math.abs(anchor.homeY - y) * 0.05,
          });
        }
      }
    }
    extensions.sort((a, b) => b.score - a.score);
    for (const e of extensions) {
      if (!aiBeam(e.ax, e.ay, e.x, e.y)) continue;
      const support = beams[beams.length - 1];
      support.background = true;
      if (!aiBeam(e.x, e.y, e.x, e.endY)) continue;
      const door = beams[beams.length - 1];
      door.armorDoor = true;
      door.armorWall = false;
      door.background = false;
      door.doorTimer = 0;
      door.doorProgress = 0;
      door.maxHp = 220;
      door.hp = 220;
      door.buildRemaining = BUILD_TIMES.door;
      door.buildTotal = BUILD_TIMES.door;
      aiMetal -= 48;
      aiLastAction = "Baut Tür mit eigener Befestigung";
      return true;
    }
  }
  return false;
}
// V14.14: evaluate prospective construction as part of a usable local structure.
// No fixed coordinates or templates: scores depend on existing joints, equipment and threats.

// V15.15 — adaptive, geometry-based construction quality. No prebuilt plans.
// Rewards useful triangular ties, discourages tangled webs and protects future gun decks.
function aiConstructionUtility(x1, y1, x2, y2, own) {
  const dx = x2 - x1,
    dy = y2 - y1,
    len = Math.hypot(dx, dy);
  if (len < MINLEN || len > MAXLEN) return -Infinity;
  const near = (x, y) => {
    let best = -1,
      dist = 7;
    for (let i = 0; i < nodes.length; i++) {
      const n = nodes[i];
      if (!n) continue;
      const d = Math.hypot(n.homeX - x, n.homeY - y);
      if (d < dist) {
        dist = d;
        best = i;
      }
    }
    return best;
  };
  const i1 = near(x1, y1),
    i2 = near(x2, y2);
  let closeParallel = 0,
    local = 0;
  const mx = (x1 + x2) * 0.5,
    my = (y1 + y2) * 0.5;
  for (const b of own) {
    const a = nodes[b.a],
      z = nodes[b.b];
    if (!a || !z) continue;
    if (aiExactLineCross(x1, y1, x2, y2, a.homeX, a.homeY, z.homeX, z.homeY)) return -Infinity;
    const bx = (a.homeX + z.homeX) * 0.5,
      by = (a.homeY + z.homeY) * 0.5;
    const d = Math.hypot(bx - mx, by - my);
    if (d < 125) local++;
    if (d < 35) {
      const ux = z.homeX - a.homeX,
        uy = z.homeY - a.homeY;
      const parallel = Math.abs(dx * ux + dy * uy) / (len * Math.hypot(ux, uy) || 1);
      if (parallel > 0.9) closeParallel++;
    }
  }
  if (closeParallel) return -Infinity;
  // Do not thread a new brace through the free space over an unoccupied gun deck.
  // Room walls/roofs are created by their separate, deliberate enclosure routine.
  if (Math.abs(dx) > 10 && Math.abs(dy) > 10) {
    for (const deck of own) {
      if (!aiHorizontalBeam(deck) || aiBeamUsed(deck)) continue;
      const a = nodes[deck.a],
        z = nodes[deck.b];
      if (!a || !z) continue;
      const lo = Math.min(a.homeX, z.homeX) + 15,
        hi = Math.max(a.homeX, z.homeX) - 15;
      const level = (a.homeY + z.homeY) * 0.5;
      if (hi <= lo || level > floor() - 45) continue;
      const cx = (x1 + x2) * 0.5,
        cy = (y1 + y2) * 0.5;
      if (cx > lo && cx < hi && cy < level - 10 && cy > level - 100) return -Infinity;
    }
  }
  let utility = -Math.max(0, local - 5) * 4;
  if (i1 >= 0 && i2 >= 0) {
    // A brace is useful when it closes a genuine triangle, not an empty duplicate.
    const connectedA = new Set();
    const connectedB = new Set();
    for (const b of own) {
      if (b.a === i1) connectedA.add(b.b);
      if (b.b === i1) connectedA.add(b.a);
      if (b.a === i2) connectedB.add(b.b);
      if (b.b === i2) connectedB.add(b.a);
    }
    const shared = [...connectedA].filter((n) => connectedB.has(n)).length;
    utility += shared ? 25 + Math.min(2, shared) * 7 : 10;
    // A closed connection helps most where the structure was sparsely supported.
    utility += Math.max(0, 5 - local) * 1.8;
  } else if (i2 < 0) {
    // Free tips are expensive unless they open a plausible, level future deck.
    const horizontal = Math.abs(dy) < 7;
    utility += horizontal ? 2 : -9;
    if (my < floor() - 245) utility -= 18;
  }
  return utility;
}

function aiStrategicBeamScore(x1, y1, x2, y2, own, used) {
  const dx = x2 - x1,
    dy = y2 - y1,
    midX = (x1 + x2) / 2,
    midY = (y1 + y2) / 2;
  const horizontal = Math.abs(dy) < 5,
    vertical = Math.abs(dx) < 5;
  const joints = [...used].map((id) => nodes[id]).filter(Boolean);
  const at = (x, y) => joints.some((n) => Math.hypot(n.homeX - x, n.homeY - y) < 6);
  const close = (x, y) => joints.filter((n) => Math.hypot(n.homeX - x, n.homeY - y) < 119).length;
  const endAttached = at(x2, y2),
    nearEnd = close(x2, y2);
  let score = 0;
  // A new platform must create usable space, a connection, or protective cover.
  if (horizontal) {
    const occupied = aiResources.some((r) => {
      const b = beams.find((q) => q.id === r.beamId);
      if (!b) return false;
      const a = nodes[b.a],
        z = nodes[b.b];
      return (
        a &&
        z &&
        Math.abs((a.homeX + z.homeX) / 2 - midX) < 85 &&
        Math.abs((a.homeY + z.homeY) / 2 - midY) < 90
      );
    });
    score += occupied ? -10 : 9;
    if (endAttached) score += 7;
  } else if (vertical) {
    score += endAttached ? 5 : -9;
    if (nearEnd < 3) score -= 11;
    if (midY < floor() - 240 && !endAttached) score -= 13;
  } else {
    score += endAttached ? 13 : 0;
    if (nearEnd < 2) score -= 9;
  }
  // Unprotected extensions towards the enemy are poor locations for vital equipment.
  if (midX < enemyCore.x - 160 && midY < floor() - 120) score -= 5;
  // Reinforce the reactor's exposed approach, but avoid filling empty sky.
  const coreDist = Math.hypot(midX - enemyCore.x, midY - enemyCore.y);
  if (coreDist < 170 && coreDist > 65 && endAttached) score += 5;
  if (!endAttached && nearEnd < 2) score -= 12;
  return score;
}
// V14.75: Close real gaps between existing joints before spreading the base.
// No fixed blueprint: each connection is computed from the living fortress.
function aiSealFortress(preWeapon = false) {
  const own = beams.filter((b) => b.owner === "enemy" && b.hp > 0);
  if (aiMetal < cost || own.length >= 56 || !enemyCore) return false;
  const ids = [...new Set(own.flatMap((b) => [b.a, b.b]))];
  const edges = new Set(own.map((b) => [Math.min(b.a, b.b), Math.max(b.a, b.b)].join(":")));
  const equipment = [
    ...aiResources.filter((r) => r.owner === "enemy"),
    ...guns.filter((g) => g.owner === "enemy" && g.hp > 0),
  ]
    .map((r) => {
      const b = beams.find((q) => q.id === r.beamId);
      if (!b) return null;
      const a = nodes[b.a],
        z = nodes[b.b];
      return a && z ? { x: (a.homeX + z.homeX) / 2, y: (a.homeY + z.homeY) / 2 - 22 } : null;
    })
    .filter(Boolean);
  const candidates = [];
  for (let i = 0; i < ids.length; i++)
    for (let j = i + 1; j < ids.length; j++) {
      const a = nodes[ids[i]],
        b = nodes[ids[j]];
      if (!a || !b) continue;
      if (edges.has([Math.min(ids[i], ids[j]), Math.max(ids[i], ids[j])].join(":"))) continue;
      const dx = b.homeX - a.homeX,
        dy = b.homeY - a.homeY,
        len = Math.hypot(dx, dy);
      if (len < 58 || len > Math.min(MAXLEN, 173)) continue;
      const mx = (a.homeX + b.homeX) / 2,
        my = (a.homeY + b.homeY) / 2;
      if (Math.abs(mx - enemyCore.x) > 310 || my < floor() - 350 || my > floor() - 12) continue;
      if (aiCandidateInterferesWithEquipment(a.homeX, a.homeY, b.homeX, b.homeY)) continue;
      const truss = aiConstructionUtility(a.homeX, a.homeY, b.homeX, b.homeY, own);
      if (!Number.isFinite(truss)) continue;
      const near = own.filter((q) => {
        const u = nodes[q.a],
          v = nodes[q.b];
        return u && v && Math.hypot((u.homeX + v.homeX) / 2 - mx, (u.homeY + v.homeY) / 2 - my) < 115;
      }).length;
      if (near < 2) continue;
      const protect = equipment.reduce((best, e) => {
        const ahead = e.x - mx;
        return Math.max(best, ahead > 20 && ahead < 165 && Math.abs(e.y - my) < 105 ? 1 : 0);
      }, 0);
      const center = Math.abs(mx - enemyCore.x);
      const score =
        near * 2 +
        truss * 1.6 +
        protect * 40 -
        center * 0.065 +
        Math.min(1, len / 100) * 6 +
        (Math.abs(dy) > 30 ? 7 : 0) +
        (preWeapon ? 11 : 0) +
        Math.random() * 4;
      candidates.push({ x1: a.homeX, y1: a.homeY, x2: b.homeX, y2: b.homeY, score });
    }
  candidates.sort((a, b) => b.score - a.score);
  for (const c of candidates.slice(0, 55)) {
    if (aiBeam(c.x1, c.y1, c.x2, c.y2)) {
      aiLastAction = "Schließt Lücke im Festungsgerüst";
      return true;
    }
  }
  return false;
}
function aiBuildPlatform(priorityType = null) {
  const own = beams.filter((b) => b.owner === "enemy" && b.hp > 0);
  // V14.67: normal growth is capped early; only genuine missing mount sites
  // may trigger extra structural construction.
  const workshopReady = aiResources.some(
    (r) =>
      r.type === "workshop" &&
      r.hp > 0 &&
      (r.buildRemaining || 0) <= 0 &&
      beams.some((b) => b.id === r.beamId && b.hp > 0),
  );
  const gunReady = guns.some((g) => g.owner === "enemy" && g.hp > 0);
  const freeMount = own.some((b) => {
    if (!aiHorizontalBeam(b) || aiBeamUsed(b)) return false;
    const a = nodes[b.a],
      z = nodes[b.b];
    if (!a || !z) return false;
    const x = (a.x + z.x) / 2,
      y = (a.y + z.y) / 2 - 14;
    return (
      workshopReady &&
      y < floor() - 45 &&
      aiEquipmentFootprintClear(x, y, "gun") &&
      !aiOwnShotBlocked({ beamId: b.id, t: 0.5, owner: "enemy", type: "cannon" }, playerCore.x, playerCore.y)
    );
  });
  const emergency = workshopReady && !freeMount;
  if (own.length >= (emergency ? 82 : 64) || aiMetal < cost) return false;
  // After an operational economy exists, stop spending on decorative beams.
  if (!emergency && gunReady && own.length >= 44) return false;
  const missingWorkshop = !aiResources.some(
    (r) => r.type === "workshop" && r.hp > 0 && beams.some((b) => b.id === r.beamId && b.hp > 0),
  );
  const missingMine = !aiResources.some(
    (r) => r.type === "mine" && r.hp > 0 && beams.some((b) => b.id === r.beamId && b.hp > 0),
  );
  const missingGun = !guns.some((g) => g.owner === "enemy" && g.hp > 0);
  const firstGunCost = Math.min(WEAPONS.mg.cost, WEAPONS.cannon.cost);
  const reserve = missingMine
    ? RESOURCE_TYPES.mine.cost
    : missingWorkshop
      ? RESOURCE_TYPES.workshop.cost
      : missingGun
        ? firstGunCost + cost
        : 0;
  if (aiMetal - cost < reserve && own.length > 22) return false;
  const used = new Set(own.flatMap((b) => [b.a, b.b]));
  const mounts = own
    .filter((b) => aiHorizontalBeam(b))
    .map((b) => {
      const a = nodes[b.a],
        z = nodes[b.b];
      return { x: (a.homeX + z.homeX) / 2, y: (a.homeY + z.homeY) / 2 };
    });
  const edges = new Set(own.map((b) => [b.a, b.b].sort((a, b) => a - b).join(":")));
  const candidates = [];
  const step = 80;
  const center = enemyCore.x;
  for (const id of used) {
    const n = nodes[id];
    if (!n || !Number.isFinite(n.homeX) || !Number.isFinite(n.homeY)) continue;
    for (const [dx, dy] of [
      [-step, 0],
      [step, 0],
      [0, -step],
      [0, step],
      [-step, -step],
      [step, -step],
      [-step, step],
      [step, step],
    ]) {
      const x = n.homeX + dx,
        y = n.homeY + dy;
      if (x < center - 420 || x > center + 420 || y < floor() - 470 || y > floor() - 15) continue;
      const near = Array.from(used).find((j) => Math.hypot(nodes[j].homeX - x, nodes[j].homeY - y) < 5);
      // Diagonal growth is permitted only as a brace between existing joints.
      // This prevents free-floating diagonal spires and encourages triangles.
      if (dx !== 0 && dy !== 0 && near === undefined) continue;
      if (near !== undefined && edges.has([id, near].sort((a, b) => a - b).join(":"))) continue;
      if (aiCandidateInterferesWithEquipment(n.homeX, n.homeY, x, y)) continue;
      const truss = aiConstructionUtility(n.homeX, n.homeY, x, y, own);
      if (!Number.isFinite(truss)) continue;
      // Prefer horizontal platforms near the front, but keep load-bearing verticals.
      const horizontal = dy === 0,
        diagonal = dx !== 0 && dy !== 0;
      const local = own.filter((b) => {
        const a = nodes[b.a],
          z = nodes[b.b];
        return Math.hypot((a.homeX + z.homeX) / 2 - x, (a.homeY + z.homeY) / 2 - y) < 125;
      }).length;
      const nearbyMount = own.some(
        (b) =>
          aiHorizontalBeam(b) &&
          Math.hypot((nodes[b.a].x + nodes[b.b].x) / 2 - x, (nodes[b.a].y + nodes[b.b].y) / 2 - y) < 105,
      );
      const frontier = Math.abs(x - center) / 420;
      const elevation = (floor() - y) / 470;
      const style = aiStrategy.style;
      const isFront = x < center;
      const compact = (horizontal ? 3.2 : 1.2) + Math.min(local, 4) * 2.4 - frontier * 14.0 - elevation * 2.2;
      const tower = (horizontal ? 1.3 : 3.4) + elevation * 2.0 - frontier * 10 + Math.min(local, 4) * 1.1;
      const battery =
        (horizontal ? 5.0 : 0.4) +
        (isFront ? 1.0 : 0) +
        elevation * 0.6 -
        (nearbyMount ? 2.3 : 0) -
        frontier * 11;
      const gunClearance = guns
        .filter((g) => g.owner === "enemy" && g.hp > 0)
        .reduce((pen, g) => {
          const p = weaponPosition(g);
          if (!p) return pen;
          const front = (x + p.x) / 2,
            midY = (y + p.y) / 2;
          return pen + (front < p.x && Math.abs(midY - p.y) < 100 ? 5 : 0);
        }, 0);
      // V14.58: expand towards actual equipment demand, rather than endlessly
      // selecting attractive but unusable vertical/decorative struts.
      const aiHasWorkshop = aiResources.some(
        (r) =>
          r.type === "workshop" &&
          r.hp > 0 &&
          r.buildRemaining <= 0 &&
          beams.some((b) => b.id === r.beamId && b.hp > 0),
      );
      const aiNeedsGun = aiHasWorkshop && !guns.some((g) => g.owner === "enemy" && g.hp > 0);
      const aiNeedsEconomy = ["mine", "wind", "workshop"].some(
        (t) =>
          !aiResources.some(
            (r) => r.type === t && r.hp > 0 && beams.some((b) => b.id === r.beamId && b.hp > 0),
          ),
      );
      const mountX = (n.homeX + x) / 2,
        mountY = (n.homeY + y) / 2 - 14;
      const neededType =
        priorityType ||
        ["mine", "wind", "workshop"].find(
          (t) =>
            !aiResources.some(
              (r) => r.type === t && r.hp > 0 && beams.some((b) => b.id === r.beamId && b.hp > 0),
            ),
        ) ||
        null;
      const mountClear =
        horizontal &&
        aiEquipmentFootprintClear(mountX, mountY, neededType || (aiNeedsGun ? "gun" : "workshop"));
      const mineDeckBonus =
        neededType === "mine" && horizontal && Math.abs(n.homeY - floor()) < 10 && Math.abs(y - floor()) < 10
          ? 230
          : 0;
      const mountBonus = mountClear
        ? aiNeedsGun
          ? mountY < floor() - 45
            ? 175
            : 15
          : aiNeedsEconomy
            ? 105
            : 13
        : 0;
      const lowGunDeckPenalty = aiNeedsGun && horizontal && mountY >= floor() - 45 ? 35 : 0;
      // V14.63: Avoid repeatedly enclosing already crowded decks. Prefer beams
      // that actually add a new usable joint or connect existing ones.
      const endpointExisting = near !== undefined;
      const crowded = local >= 6;
      const deckDuplicate =
        horizontal &&
        own.some((b) => {
          if (!aiHorizontalBeam(b)) return false;
          const a = nodes[b.a],
            z = nodes[b.b];
          return (
            Math.abs((a.homeX + z.homeX) / 2 - (n.homeX + x) / 2) < 8 &&
            Math.abs((a.homeY + z.homeY) / 2 - y) < 8
          );
        });
      if (deckDuplicate) continue;
      // Avoid packing a second beam into an already serviced deck. A new
      // horizontal member is valuable only if it creates a genuinely new site.
      const deckNear =
        horizontal &&
        mounts.some((m) => Math.abs(m.x - mountX) < 115 && Math.abs(m.y - (n.homeY + y) / 2) < 45);
      const crowdedPenalty = Math.max(0, local - 3) * 8 + (deckNear ? 38 : 0);
      const createsNewJoint = !endpointExisting;
      const verticalSpire = !horizontal && !endpointExisting && elevation > 0.55;
      const usefulMount = mountClear && !deckNear;
      const strategic = aiStrategicBeamScore(n.homeX, n.homeY, x, y, own, used);
      if (strategic < -24 || (crowded && !mountClear && !endpointExisting && local >= 10)) continue;
      if (verticalSpire && local < 3) continue;
      if (own.length >= 32 && !emergency && !usefulMount && !endpointExisting) continue;
      // Under fire, consolidate around surviving joints rather than growing exposed towers.
      const pressure = aiStrategy.damagePressure || 0;
      const stability =
        pressure * (Math.min(local, 5) * 2.3 - (nearbyMount ? 1 : 0) - elevation * 3.5 - frontier * 2.5);
      const score =
        (diagonal
          ? style === "tower"
            ? 12
            : style === "compact"
              ? 9
              : 11
          : style === "compact"
            ? compact
            : style === "tower"
              ? tower
              : battery) +
        Math.random() * 0.35 +
        aiStrategy.bias * (isFront ? 2 : -2) -
        gunClearance +
        aiCandidateQuality(n.homeX, n.homeY, x, y, own) +
        strategic +
        stability +
        truss +
        mountBonus +
        mineDeckBonus -
        lowGunDeckPenalty -
        crowdedPenalty -
        (crowded ? 12 : 0) -
        (endpointExisting ? 0 : 3) +
        (usefulMount ? 85 : 0) +
        (createsNewJoint && local < 5 ? 7 : 0);
      candidates.push({ x1: n.homeX, y1: n.homeY, x2: x, y2: y, score });
    }
  }
  candidates.sort((a, b) => b.score - a.score);
  for (const c of candidates) if (aiBeam(c.x1, c.y1, c.x2, c.y2)) return true;
  return false;
}
function aiBeamUsed(b) {
  return (
    guns.some((g) => g.owner === "enemy" && g.beamId === b.id) || aiResources.some((r) => r.beamId === b.id)
  );
}
function aiCanRemoveBeam(b) {
  if (!b || b.owner !== "enemy" || b.hp <= 0 || aiBeamUsed(b) || b.armorDoor) return false;
  const own = beams.filter((e) => e.owner === "enemy" && e.hp > 0 && e.id !== b.id);
  if (!own.length) return false;
  const root = own.find((e) => nodes[e.a].fixed || nodes[e.b].fixed);
  if (!root) return false;
  const visited = new Set([root.a, root.b]);
  let change = true;
  while (change) {
    change = false;
    for (const e of own) {
      if (visited.has(e.a) && !visited.has(e.b)) {
        visited.add(e.b);
        change = true;
      } else if (visited.has(e.b) && !visited.has(e.a)) {
        visited.add(e.a);
        change = true;
      }
    }
  }
  return own.every((e) => visited.has(e.a) && visited.has(e.b));
}
function aiMaintainStructure(own, enemyGuns) {
  // Replace obstructing front beams with back beams; they still support the fort.
  for (const gun of enemyGuns.filter((g) => (g.buildRemaining || 0) <= 0)) {
    const target = { x: playerCore.x, y: playerCore.y };
    if (!aiOwnShotBlocked(gun, target.x, target.y)) continue;
    const blockers = aiShotBlockers(gun, target.x, target.y);
    for (const b of blockers) {
      if (b.owner === "enemy" && !b.background && !b.armorDoor && b.id !== gun.beamId && aiSetBackground(b)) {
        aiLastAction = "Balken nach hinten";
        return true;
      }
    }
  }
  // V14.33: repair the most strategically valuable damaged beam first.
  // Prioritize weapon/resource mounts, heavily damaged supports and beams near the reactor.
  const important = own.filter(
    (b) => !b.background && !b.armorDoor && (b.buildRemaining || 0) <= 0 && b.hp > 0 && b.hp < 110,
  );
  const repairs = important
    .map((b) => {
      const a = nodes[b.a],
        z = nodes[b.b];
      if (!a || !z) return { b, score: -Infinity };
      const mx = (a.x + z.x) / 2,
        my = (a.y + z.y) / 2;
      const mounted = aiBeamUsed(b),
        nearCore = enemyCore && Math.hypot(mx - enemyCore.x, my - enemyCore.y) < 165;
      const connected = own.filter(
        (e) => e !== b && (e.a === b.a || e.a === b.b || e.b === b.a || e.b === b.b),
      ).length;
      const score =
        (mounted ? 85 : 0) + (nearCore ? 35 : 0) + Math.min(connected, 5) * 6 + (110 - b.hp) * 0.65;
      return { b, score };
    })
    .sort((a, b) => b.score - a.score);
  if (repairs.length && aiMetal >= 28 && repairs[0].score >= 65) {
    const b = repairs[0].b;
    b.hp = Math.min(160, b.hp + 55);
    aiMetal -= 28;
    aiLastAction = aiBeamUsed(b) ? "Repariert Waffenplattform" : "Verstärkt beschädigte Struktur";
    return true;
  }
  // Remove redundant, unused, badly damaged beams when the economy is tight.
  if (aiMetal < 70) {
    const redundant = own.filter((b) => b.hp < 35 && !aiBeamUsed(b) && aiCanRemoveBeam(b));
    if (redundant.length) {
      const id = redundant[0].id;
      beams = beams.filter((b) => b.id !== id);
      aiLastAction = "Entfernt defekten Balken";
      return true;
    }
  }
  return false;
}
function aiHorizontalBeam(b) {
  if (!b || b.hp <= 0 || b.armorDoor || (b.buildRemaining || 0) > 0) return false;
  const a = nodes[b.a],
    z = nodes[b.b];
  return !!(
    a &&
    z &&
    Math.abs(z.x - a.x) > 28 &&
    Math.abs(z.y - a.y) <= Math.max(4, Math.abs(z.x - a.x) * 0.08)
  );
}
function aiMountOccupied(x, y, radius = 72) {
  return [...guns, ...aiResources].some((item) => {
    const b = beams.find((b) => b.id === item.beamId);
    if (!b) return false;
    const a = nodes[b.a],
      z = nodes[b.b];
    if (!a || !z) return false;
    const t = item.t ?? 0.5;
    return Math.hypot(a.x + (z.x - a.x) * t - x, a.y + (z.y - a.y) * t - 14 - y) < radius;
  });
}
// Predict whether a shot immediately strikes the shooter's own foreground structure.
// Background beams are deliberately transparent to projectiles, as in physics().
function aiOwnShotBlocked(g, tx, ty) {
  const n = weaponPosition(g),
    spec = WEAPONS[g.type || "cannon"];
  if (!n || !spec) return true;
  // Refuse targets inside the blast zone of our own core or equipment.
  const blast = Math.max(28, (spec.radius || spec.explosionRadius || 65) * 0.55);
  if (
    enemyCore &&
    !enemyCore.dead &&
    g.owner === "enemy" &&
    Math.hypot(tx - enemyCore.x, ty - enemyCore.y) < blast + 32
  )
    return true;
  if (
    g.owner === "enemy" &&
    [...aiResources, ...guns.filter((w) => w.owner === "enemy" && w !== g)].some((w) => {
      const p =
        w.beamId != null
          ? (() => {
              const b = beams.find((b) => b.id === w.beamId);
              if (!b) return null;
              const a = nodes[b.a],
                z = nodes[b.b];
              return a && z
                ? { x: a.x + (z.x - a.x) * (w.t ?? 0.5), y: a.y + (z.y - a.y) * (w.t ?? 0.5) - 14 }
                : null;
            })()
          : null;
      return p && Math.hypot(p.x - tx, p.y - ty) < blast * 0.8;
    })
  )
    return true;
  const angle = calculateLaunchAngle(g, tx, ty);
  let x = n.x + Math.cos(angle) * 58,
    y = n.y + Math.sin(angle) * 58;
  let vx = Math.cos(angle) * spec.speed,
    vy = Math.sin(angle) * spec.speed;
  const gravity = GRAV * 0.45,
    dt = 0.025;
  for (let step = 0; step < 360; step++) {
    const oldX = x,
      oldY = y;
    vy += gravity * dt;
    x += vx * dt;
    y += vy * dt;
    if (y >= floor() || x < 0 || x > WORLD_W) break;
    // Stop checking when the shell has reached the desired target area.
    if (Math.hypot(x - tx, y - ty) < Math.max(18, spec.ball + 9)) break;
    // Other friendly weapons physically intercept shells. Predict that before firing.
    for (const friendly of guns) {
      if (friendly === g || friendly.owner !== g.owner || (friendly.hp || 130) <= 0) continue;
      const p = weaponPosition(friendly);
      if (!p) continue;
      if (segmentHit(oldX, oldY, x, y, p.x - 21, p.y - 13, p.x + 21, p.y + 13, spec.ball + 6)) return true;
    }
    for (const b of beams) {
      if (
        b.owner !== g.owner ||
        b.background ||
        b.hp <= 0 ||
        (b.buildRemaining || 0) > 0 ||
        b.id === g.beamId
      )
        continue;
      const a = nodes[b.a],
        z = nodes[b.b];
      if (!a || !z) continue;
      // A friendly door is opened by fireGun when within 145 units of the gun.
      if (b.armorDoor) {
        const centerDist = Math.hypot((a.x + z.x) / 2 - n.x, (a.y + z.y) / 2 - n.y);
        if (centerDist < 145) continue;
        const opening = (b.doorProgress || 0) * 1.0;
        for (const [u, v] of [
          [0, (1 - opening) / 2],
          [(1 + opening) / 2, 1],
        ]) {
          if (v - u < 0.01) continue;
          if (
            segmentHit(
              oldX,
              oldY,
              x,
              y,
              a.x + (z.x - a.x) * u,
              a.y + (z.y - a.y) * u,
              a.x + (z.x - a.x) * v,
              a.y + (z.y - a.y) * v,
              spec.ball + 6,
            )
          )
            return true;
        }
      } else if (segmentHit(oldX, oldY, x, y, a.x, a.y, z.x, z.y, spec.ball + 5)) return true;
    }
  }
  return false;
}
// Find precisely which friendly foreground beams block a projectile's route.
function aiShotBlockers(g, tx, ty) {
  const n = weaponPosition(g),
    spec = WEAPONS[g.type || "cannon"];
  if (!n || !spec) return [];
  const angle = calculateLaunchAngle(g, tx, ty),
    gravity = GRAV * 0.45,
    dt = 0.025;
  let x = n.x + Math.cos(angle) * 58,
    y = n.y + Math.sin(angle) * 58;
  let vx = Math.cos(angle) * spec.speed,
    vy = Math.sin(angle) * spec.speed;
  const result = new Set();
  for (let step = 0; step < 360; step++) {
    const ox = x,
      oy = y;
    vy += gravity * dt;
    x += vx * dt;
    y += vy * dt;
    if (y >= floor() || x < 0 || x > WORLD_W) break;
    if (Math.hypot(x - tx, y - ty) < Math.max(18, spec.ball + 9)) break;
    for (const b of beams) {
      if (
        b.owner !== "enemy" ||
        b.background ||
        b.hp <= 0 ||
        (b.buildRemaining || 0) > 0 ||
        b.armorDoor ||
        b.id === g.beamId
      )
        continue;
      const a = nodes[b.a],
        z = nodes[b.b];
      if (!a || !z) continue;
      if (segmentHit(ox, oy, x, y, a.x, a.y, z.x, z.y, spec.ball + 5)) result.add(b);
    }
  }
  return [...result];
}
// Prefer opening an existing gun's firing lane to expanding the fort blindly.
function aiClearGunLane(enemyGuns) {
  for (const g of enemyGuns) {
    if ((g.buildRemaining || 0) > 0) continue;
    const target = { x: playerCore.x, y: playerCore.y };
    if (!aiOwnShotBlocked(g, target.x, target.y)) continue;
    const blockers = aiShotBlockers(g, target.x, target.y);
    if (!blockers.length) continue;
    // Moving a beam to the rear is a valid structural edit, not destruction.
    const first = blockers.find((b) => !b.armorDoor && !b.background);
    if (first) {
      aiLastAction = "Schussweg freimachen";
      return aiSetBackground(first);
    }
  }
  return false;
}
function aiAimPoint(g, target) {
  return target;
}
function aiTargetFor(g) {
  const playerGuns = guns.filter(
    (w) => w.owner === "player" && (w.buildRemaining || 0) <= 0 && weaponPosition(w),
  );
  const exposed = beams.filter((b) => b.owner === "player" && !b.background && b.hp > 0);
  const weak = exposed.filter((b) => b.hp < 68).sort((a, b) => a.hp - b.hp);
  let target = null;
  // Defend against the greatest immediate threat, then seek the reactor.
  if (playerGuns.length && Math.random() < 0.3) {
    const w = playerGuns.reduce((a, b) =>
      WEAPONS[a.type || "cannon"].damage > WEAPONS[b.type || "cannon"].damage ? a : b,
    );
    target = weaponPosition(w);
  } else if (playerCore && !playerCore.dead && Math.random() < 0.6) {
    target = { x: playerCore.x, y: playerCore.y };
  } else if (weak.length) {
    const b = weak[0],
      a = nodes[b.a],
      z = nodes[b.b];
    target = { x: (a.x + z.x) / 2, y: (a.y + z.y) / 2 };
  } else target = playerTarget();
  return aiAimPoint(g, target);
}
function updateEnemyAI(dt) {
  aiMetal = Math.min(
    FW_RESOURCE_CAP,
    aiMetal +
      dt *
        aiResources.filter(
          (r) =>
            r.type === "mine" &&
            (r.buildRemaining || 0) <= 0 &&
            beams.some((b) => b.id === r.beamId && b.hp > 0 && (b.buildRemaining || 0) <= 0),
        ).length *
        RESOURCE_TYPES.mine.rate,
  );
  aiEnergy = Math.min(
    FW_RESOURCE_CAP,
    aiEnergy +
      dt *
        aiResources.filter(
          (r) =>
            r.type === "wind" &&
            (r.buildRemaining || 0) <= 0 &&
            beams.some((b) => b.id === r.beamId && b.hp > 0 && (b.buildRemaining || 0) <= 0),
        ).length *
        RESOURCE_TYPES.wind.rate,
  );
  if (
    !aiResources.some(
      (r) =>
        r.type === "mine" && (r.buildRemaining || 0) <= 0 && beams.some((b) => b.id === r.beamId && b.hp > 0),
    ) &&
    aiMetal < RESOURCE_TYPES.mine.cost
  ) {
    aiMetal = Math.min(RESOURCE_TYPES.mine.cost, aiMetal + dt * FW_EMERGENCY_METAL);
  }
  aiThink -= dt;
  aiFireDecisionTimer -= dt;
  aiPlanResearch();
  if (gameOver || paused) return;
  const doBuild = aiThink <= 0;
  // Building speed stays responsive on all difficulties; difficulty primarily affects combat accuracy and aggression.
  if (doBuild) aiThink = DIFFICULTY[difficulty].thinkMin + Math.random() * DIFFICULTY[difficulty].thinkSpread;
  const enemyBeams = beams.filter((b) => b.owner === "enemy" && b.hp > 0);
  const enemyGuns = guns.filter((g) => g.owner === "enemy" && weaponPosition(g));
  const mines = aiResources.filter(
    (r) => r.type === "mine" && enemyBeams.some((b) => b.id === r.beamId),
  ).length;
  const winds = aiResources.filter(
    (r) => r.type === "wind" && enemyBeams.some((b) => b.id === r.beamId),
  ).length;
  // Combat and construction are independent: do not let repeated building suppress attacks.
  const canConsiderFiring = aiFireDecisionTimer <= 0;
  if (canConsiderFiring)
    aiFireDecisionTimer =
      (DIFFICULTY[difficulty].fireDelay + Math.random() * DIFFICULTY[difficulty].fireDelaySpread) *
      (window.fwMission?.ai?.fireDelayScale ?? 1);
  // The AI may fire at most three weapons per attack decision, even with a larger arsenal.
  const readyToFire = (canConsiderFiring ? enemyGuns : [])
    .filter(
      (g) =>
        g.type !== "flak" &&
        !!aiGunDoor(g, false) &&
        (g.buildRemaining || 0) <= 0 &&
        (g.cooldown || 0) <= 0 &&
        aiEnergy >= WEAPONS[g.type || "cannon"].energy,
    )
    .sort((a, b) => (a.lastAiVolley || 0) - (b.lastAiVolley || 0))
    .slice(0, 3);
  for (const gun of readyToFire) {
    if (gameOver) break;
    const targets = [
      { p: { x: playerCore.x, y: playerCore.y }, score: 65 },
      ...guns
        .filter((w) => w.owner === "player" && (w.buildRemaining || 0) <= 0)
        .map((w) => ({
          p: weaponPosition(w),
          score: 35 + (WEAPONS[w.type || "cannon"]?.damage || 20) * 0.32,
        })),
      ...beams
        .filter((b) => b.owner === "player" && !b.background && b.hp > 0)
        .map((b) => ({
          p: { x: (nodes[b.a].x + nodes[b.b].x) / 2, y: (nodes[b.a].y + nodes[b.b].y) / 2 },
          score: 20 + (100 - b.hp) * 0.45,
        })),
      { p: aiTargetFor(gun), score: 32 },
    ];
    // V14.82: Try alternative aiming points on the opposing fortress when a direct
    // core shot is obstructed. All candidates still pass the own-structure test.
    const fallbackTargets = beams
      .filter((b) => b.owner === "player" && b.hp > 0 && !b.background)
      .slice(0, 35)
      .flatMap((b) => {
        const a = nodes[b.a],
          z = nodes[b.b];
        return a && z
          ? [
              { p: { x: a.x, y: a.y }, score: 16 },
              { p: { x: z.x, y: z.y }, score: 16 },
            ]
          : [];
      });
    const viable = [...targets, ...fallbackTargets].filter(
      (o) => o.p && Number.isFinite(o.p.x) && Number.isFinite(o.p.y) && !aiOwnShotBlocked(gun, o.p.x, o.p.y),
    );
    viable.sort((a, b) => b.score + Math.random() * 12 - (a.score + Math.random() * 12));
    let target = viable.length ? viable[0].p : null;
    if (target && difficulty === "easy" && Math.random() < 0.4) {
      target = {
        x: target.x + (Math.random() - 0.5) * DIFFICULTY.easy.aimNoise,
        y: target.y + (Math.random() - 0.5) * DIFFICULTY.easy.aimNoise,
      };
    }
    if (
      target &&
      Math.random() <= DIFFICULTY[difficulty].fireChance &&
      aiEnergy >= WEAPONS[gun.type || "cannon"].energy &&
      fireGun("enemy", target.x, target.y, gun)
    ) {
      aiEnergy -= WEAPONS[gun.type || "cannon"].energy;
      aiShots++;
      gun.lastAiVolley = performance.now();
      aiLastAction = "Feuert " + gun.type;
    }
  }
  if (!doBuild) return;
  // Before adding more material, restore existing usable gun corridors.
  if (
    enemyGuns.some((g) => g.type !== "flak" && (g.buildRemaining || 0) <= 0) &&
    aiClearGunLane(enemyGuns.filter((g) => g.type !== "flak"))
  )
    aiLastAction = "Schussfeld korrigiert";
  // Maintenance and construction are separate work streams. A repair no longer consumes the entire AI turn.
  if (aiMetal >= 135 && Math.random() < DIFFICULTY[difficulty].maintainChance)
    aiMaintainStructure(enemyBeams, enemyGuns);
  // Move some existing diagonal braces to the back, retaining horizontal gun decks.
  // This gradually creates clear firing corridors without deleting structural supports.

  // Two concurrent AI priorities: structural maintenance and strategic development.
  // Each planning pass reads the CURRENT world so it can react to what the first pass built.
  // Two independent construction orders per thinking cycle: the second one
  // selects a different work stream from the updated state of the fortress.
  const firstWorkStream = aiStrategicDecision();
  // Second order must not add another structure before the economy and first gun are viable.
  if (firstWorkStream !== "structure" || guns.some((g) => g.owner === "enemy" && g.hp > 0))
    aiStrategicDecision(firstWorkStream);
}
// V14.12: threat-aware cover evaluation; no fixed building coordinates.
// V14.13: tactical exposure is evaluated against the actual beam geometry.
function aiLineShieldScore(target, extra = null) {
  const origin = { x: playerCore.x, y: playerCore.y };
  const dx = target.x - origin.x,
    dy = target.y - origin.y,
    den = dx * dx + dy * dy || 1;
  let score = 0;
  const shields = beams.filter(
    (b) => b.owner === "enemy" && b.hp > 0 && !b.background && (b.buildRemaining || 0) <= 0,
  );
  for (const b of shields) {
    const a = nodes[b.a],
      z = nodes[b.b];
    if (!a || !z) continue;
    const mx = (a.homeX + z.homeX) / 2,
      my = (a.homeY + z.homeY) / 2;
    const t = ((mx - origin.x) * dx + (my - origin.y) * dy) / den;
    if (t <= 0.12 || t >= 0.94) continue;
    const perp = Math.abs((mx - origin.x) * dy - (my - origin.y) * dx) / Math.sqrt(den);
    const len = Math.hypot(a.homeX - z.homeX, a.homeY - z.homeY);
    if (perp < Math.max(22, len * 0.46)) score += (b.armorDoor ? 2.3 : 1) * Math.max(0.2, 1 - perp / 85);
  }
  if (extra) {
    const mx = (extra.x1 + extra.x2) / 2,
      my = (extra.y1 + extra.y2) / 2;
    const t = ((mx - origin.x) * dx + (my - origin.y) * dy) / den;
    const perp = Math.abs((mx - origin.x) * dy - (my - origin.y) * dx) / Math.sqrt(den);
    if (t > 0.12 && t < 0.94 && perp < 45) score += Math.max(0.1, 1 - perp / 60);
  }
  return score;
}
function aiPlacementSafety(x, y, priority = 1) {
  const target = { x, y };
  const protection = aiLineShieldScore(target);
  const enemyDistance = Math.abs(x - playerCore.x);
  const height = floor() - y;
  return priority * (Math.min(3, protection) * 23 + Math.min(400, enemyDistance) * 0.025 - height * 0.045);
}
function aiProtectionTargets() {
  const buildings = aiResources
    .filter((r) => r.owner === "enemy" && r.buildRemaining <= 0)
    .map((r) => {
      const b = beams.find((e) => e.id === r.beamId);
      if (!b) return null;
      const a = nodes[b.a],
        z = nodes[b.b];
      if (!a || !z) return null;
      return {
        x: a.homeX + (z.homeX - a.homeX) * (r.t ?? 0.5),
        y: a.homeY + (z.homeY - a.homeY) * (r.t ?? 0.5) - 30,
        priority: r.type === "workshop" ? 1.45 : r.type === "wind" ? 1.2 : 1,
      };
    })
    .filter(Boolean);
  // V14.68: operational guns are protection targets too, not only buildings.
  // Use the real muzzle/mount position rather than an arbitrary fixed offset.
  for (const g of guns) {
    if (g.owner !== "enemy" || g.hp <= 0 || (g.buildRemaining || 0) > 0) continue;
    const p = weaponPosition(g);
    if (!p) continue;
    buildings.push({ x: p.x, y: p.y, priority: 2.35, gun: g });
  }
  if (enemyCore && !enemyCore.dead) buildings.push({ x: enemyCore.x, y: enemyCore.y, priority: 2.6 });
  return buildings;
}
function aiCoverValue(target) {
  // The enemy approaches from the left. A foreground shield should be between
  // the player's fort and the building, without occupying the building itself.
  const shields = beams.filter(
    (b) => b.owner === "enemy" && b.hp > 0 && !b.background && (b.buildRemaining || 0) <= 0,
  );
  let cover = 0;
  for (const b of shields) {
    const a = nodes[b.a],
      z = nodes[b.b];
    if (!a || !z) continue;
    const mx = (a.homeX + z.homeX) / 2,
      my = (a.homeY + z.homeY) / 2;
    const ahead = target.x - mx;
    if (ahead < 25 || ahead > 185) continue;
    const verticalReach = Math.abs(my - target.y);
    if (verticalReach > 100) continue;
    const vertical = Math.abs(z.homeY - a.homeY) > Math.abs(z.homeX - a.homeX);
    cover +=
      (b.armorDoor ? 2.0 : vertical ? 1.2 : 0.55) *
      Math.max(0.15, 1 - verticalReach / 115) *
      Math.max(0.2, 1 - ahead / 260);
  }
  return cover;
}
function aiAddDefensiveCover() {
  if (aiMetal < cost) return false;
  const targets = aiProtectionTargets()
    .filter((t) => !t.gun)
    .sort((a, b) => b.priority / (1 + aiCoverValue(b)) - a.priority / (1 + aiCoverValue(a)));
  const own = beams.filter((b) => b.owner === "enemy" && b.hp > 0);
  const points = new Map();
  for (const b of own) {
    for (const id of [b.a, b.b]) {
      const n = nodes[id];
      if (n) points.set(id, n);
    }
  }
  const proposals = [];
  for (const target of targets.slice(0, 5)) {
    if (aiLineShieldScore(target) >= 1.6) continue;
    for (const n of points.values()) {
      const dx = target.x - n.homeX,
        dy = target.y - n.homeY;
      if (dx < 35 || dx > 175 || Math.abs(dy) > 115) continue;
      for (const step of [-80, 80]) {
        const x = n.homeX,
          y = n.homeY + step;
        if (y < floor() - 480 || y > floor() - 12) continue;
        if (aiCandidateInterferesWithEquipment(n.homeX, n.homeY, x, y)) continue;
        if (
          own.some((b) => {
            const a = nodes[b.a],
              z = nodes[b.b];
            return (
              a &&
              z &&
              ((Math.hypot(a.homeX - n.homeX, a.homeY - n.homeY) < 4 &&
                Math.hypot(z.homeX - x, z.homeY - y) < 4) ||
                (Math.hypot(z.homeX - n.homeX, z.homeY - n.homeY) < 4 &&
                  Math.hypot(a.homeX - x, a.homeY - y) < 4))
            );
          })
        )
          continue;
        const mid = (n.homeY + y) / 2;
        const score =
          (target.priority * 65) / (0.5 + aiLineShieldScore(target)) -
          Math.abs(mid - target.y) * 0.18 -
          Math.abs(dx - 90) * 0.08 +
          aiLineShieldScore(target, { x1: n.homeX, y1: n.homeY, x2: x, y2: y }) * 38 +
          Math.random() * 7;
        proposals.push({ x1: n.homeX, y1: n.homeY, x2: x, y2: y, score });
      }
    }
  }
  proposals.sort((a, b) => b.score - a.score);
  for (const p of proposals.slice(0, 35))
    if (aiBeam(p.x1, p.y1, p.x2, p.y2)) {
      aiLastAction = "Schützt wichtige Gebäude";
      return true;
    }
  return false;
}
// V14.69: actual armored cover is required; ordinary wood is not protection.
function aiActualArmoredCover(t) {
  if (t.gun) return aiGunDoor(t.gun) ? 1.6 : 0;
  const ox = playerCore.x,
    oy = playerCore.y,
    dx = t.x - ox,
    dy = t.y - oy;
  let cover = 0;
  for (const b of beams) {
    if (b.owner !== "enemy" || b.hp <= 0 || b.background || !b.armorWall) continue;
    const a = nodes[b.a],
      z = nodes[b.b];
    if (!a || !z) continue;
    const sx = z.homeX - a.homeX,
      sy = z.homeY - a.homeY;
    const det = dx * sy - dy * sx;
    if (Math.abs(det) < 1e-7) continue;
    const rx = a.homeX - ox,
      ry = a.homeY - oy;
    const u = (rx * sy - ry * sx) / det,
      v = (rx * dy - ry * dx) / det;
    if (u > 0.08 && u < 0.98 && v >= 0 && v <= 1) cover += 1.3;
  }
  return cover;
}
function aiArmorCriticalCover() {
  if (aiMetal < 48) return false;
  const targets = aiProtectionTargets()
    .filter((t) => !t.gun && aiActualArmoredCover(t) < 1)
    .sort((a, b) => b.priority - a.priority);
  const options = [];
  for (const b of beams) {
    if (
      b.owner !== "enemy" ||
      b.hp <= 0 ||
      b.background ||
      b.armorDoor ||
      b.armorWall ||
      (b.buildRemaining || 0) > 0 ||
      aiBeamUsed(b)
    )
      continue;
    const a = nodes[b.a],
      z = nodes[b.b];
    if (!a || !z) continue;
    const len = Math.hypot(a.homeX - z.homeX, a.homeY - z.homeY);
    if (len < 48 || len > 125) continue;
    const mx = (a.homeX + z.homeX) / 2,
      my = (a.homeY + z.homeY) / 2;
    for (const t of targets) {
      const ahead = t.x - mx,
        dy = Math.abs(t.y - my);
      if (ahead < 24 || ahead > 150 || dy > 85) continue;
      // A wall only protects the building if it really intersects incoming fire.
      if (!aiExactLineCross(playerCore.x, playerCore.y, t.x, t.y, a.x, a.y, z.x, z.y)) continue;
      const vertical = Math.abs(a.homeY - z.homeY) > Math.abs(a.homeX - z.homeX);
      // Only a line-intersecting shield counts, and doors protect firing lanes.
      const gun = null;
      const score = t.priority * 55 - ahead * 0.16 - dy * 0.48 + (vertical ? 20 : 0);
      options.push({ b, gun, score });
    }
  }
  options.sort((a, b) => b.score - a.score);
  if (!options.length) return false;
  const { b, gun } = options[0];
  b.background = false;
  b.armorDoor = !!gun;
  b.armorWall = !gun;
  b.doorTimer = 0;
  b.doorProgress = 0;
  b.hp = Math.max(b.hp, gun ? 220 : 320);
  b.buildRemaining = gun ? BUILD_TIMES.door : BUILD_TIMES.armor;
  b.buildTotal = b.buildRemaining;
  aiMetal -= 48;
  aiLastAction = gun ? "Sichert Waffe mit Panzertür" : "Sichert Gebäude mit Panzerwand";
  return true;
}
function aiFortressReadyForWeapons() {
  // Bounded shell phase: a finite structure quota ensures weapons cannot deadlock.
  const own = beams.filter((b) => b.owner === "enemy" && b.hp > 0);
  if (!enemyCore) return false;
  if (own.length < 16) return false;
  const close = own.filter((b) => {
    const a = nodes[b.a],
      z = nodes[b.b];
    if (!a || !z) return false;
    return Math.hypot((a.homeX + z.homeX) / 2 - enemyCore.x, (a.homeY + z.homeY) / 2 - enemyCore.y) < 245;
  });
  // A serviceable, braced shell is enough. Do not require 26+ arbitrary beams.
  // Weapon rooms and armor doors are still constructed before gun placement.
  return (
    (close.length >= 9 && aiLineShieldScore({ x: enemyCore.x, y: enemyCore.y }) >= 0.35) ||
    own.length >= 21 ||
    (aiShellAttempts >= 90 && own.length >= 18)
  );
}
// V14.78: A gun position is not eligible merely because the fort has many beams.
// It needs a physical front-side shield erected BEFORE the gun is installed.
function aiCoveredGunSite(site) {
  const own = beams.filter((b) => b.owner === "enemy" && b.hp > 0 && !b.background);
  return own.some((b) => {
    const a = nodes[b.a],
      z = nodes[b.b];
    if (!a || !z) return false;
    const midX = (a.homeX + z.homeX) * 0.5,
      top = Math.min(a.homeY, z.homeY),
      bottom = Math.max(a.homeY, z.homeY);
    return (
      Math.abs(z.homeY - a.homeY) >= 48 &&
      midX < site.x - 22 &&
      midX > site.x - 180 &&
      top < site.y - 25 &&
      bottom > site.y - 105
    );
  });
}
function aiPrepareCoveredGunSite(sites) {
  if (aiMetal < cost) return false;
  const own = beams.filter((b) => b.owner === "enemy" && b.hp > 0);
  for (const site of sites) {
    if (aiCoveredGunSite(site)) continue;
    const b = site.b,
      a = nodes[b.a],
      z = nodes[b.b];
    if (!a || !z) continue;
    const ends = [a, z].sort((u, v) => u.homeX - v.homeX);
    for (const n of ends) {
      if (n.homeX > site.x - 24) continue;
      // A vertical shield attached to a real existing joint, not a free-floating beam.
      const x = n.homeX,
        y = n.homeY - 85;
      if (y < floor() - 470 || aiCandidateInterferesWithEquipment(n.homeX, n.homeY, x, y)) continue;
      if (aiBeam(n.homeX, n.homeY, x, y)) {
        aiLastAction = "Errichtet Sichtschutz vor Waffenplatz";
        return true;
      }
    }
  }
  return false;
}
// V14.80: Doors are a prerequisite, not an optional upgrade after gun placement.
function aiTemporaryGunForSite(site) {
  return { beamId: site.b.id, t: 0.5, owner: "enemy", type: "mg", hp: 130, buildRemaining: 0 };
}
function aiDoorProtectedSite(site, includePending = true) {
  const probe = aiTemporaryGunForSite(site);
  return !!aiGunDoor(probe, includePending);
}
function aiPrepareDoorForSite(sites) {
  if (aiMetal < 48 + cost) return false;
  const ranked = [...sites].sort((a, b) => Math.abs(a.x - enemyCore.x) - Math.abs(b.x - enemyCore.x));
  for (const site of ranked) {
    if (aiDoorProtectedSite(site, true)) continue;
    const chamber = aiEmplacementShell(site);
    if (!chamber.closed || !chamber.frontBeam) continue;
    // Directly turn the front edge of the finished chamber into a functional door.
    const front = chamber.frontBeam;
    if (!front.armorDoor) {
      if (aiMetal < 48) return false;
      front.armorDoor = true;
      front.armorWall = false;
      front.background = false;
      front.doorTimer = 0;
      front.doorProgress = 0;
      front.maxHp = 220;
      front.hp = Math.min(220, Math.max(front.hp, 180));
      front.buildRemaining = BUILD_TIMES.door;
      front.buildTotal = BUILD_TIMES.door;
      aiMetal -= 48;
      aiLastAction = "Wand des fertigen Waffenraums wird Panzertür";
      return true;
    }
    const probe = aiTemporaryGunForSite(site);
    guns.push(probe);
    let ok = false;
    try {
      ok = aiInstallArmorDoor();
    } finally {
      guns.splice(guns.indexOf(probe), 1);
    }
    if (ok) {
      aiLastAction = "Baut Panzertür vor Waffenmontage";
      return true;
    }
  }
  return false;
}

// V14.81: Real emplacement geometry, not simply "a nearby vertical beam".
// A rear wall and overhead roof are required in addition to the armor door.
// V14.83: Check a continuous four-sided structural loop, not disconnected nearby beams.
// Coordinates are the beam's fixed construction endpoints; destroyed or rear-layer beams cannot seal a room.
// V14.84: build an actual closed structural chamber BEFORE installing the door and gun.
// The room is derived from each real horizontal platform rather than a global prefab.
function aiEmplacementShell(site) {
  const base = site.b,
    a = nodes[base.a],
    z = nodes[base.b];
  if (!a || !z || base.hp <= 0 || base.background) return { closed: false };
  const left = a.homeX < z.homeX ? a : z,
    right = left === a ? z : a;
  const y = (left.homeY + right.homeY) / 2;
  let height = base.aiChamberHeight;
  if (!Number.isFinite(height)) {
    const span = right.homeX - left.homeX;
    const nearby = beams
      .filter((q) => q.owner === "enemy" && q.hp > 0 && q !== base)
      .filter((q) => {
        const u = nodes[q.a],
          v = nodes[q.b];
        return u && v && Math.hypot((u.homeX + v.homeX) / 2 - site.x, (u.homeY + v.homeY) / 2 - y) < 135;
      }).length;
    // A weapon room is sized to its real mounting beam and local density.
    // Once selected, the height stays on the beam even if strategy changes.
    const intent = aiStrategy.style === "tower" ? 94 : aiStrategy.style === "battery" ? 83 : 73;
    const desired = intent + (span - 80) * 0.14 - Math.max(0, nearby - 4) * 2;
    const candidates = [68, 76, 84, 92, 100].sort((a, b) => Math.abs(a - desired) - Math.abs(b - desired));
    height =
      candidates.find(
        (h) =>
          y - h >= floor() - 470 &&
          !aiCandidateInterferesWithEquipment(left.homeX, y, left.homeX, y - h) &&
          !aiCandidateInterferesWithEquipment(right.homeX, y, right.homeX, y - h) &&
          !aiCandidateInterferesWithEquipment(left.homeX, y - h, right.homeX, y - h),
      ) || 80;
    base.aiChamberHeight = height;
  }
  const corners = [
    [left.homeX, y],
    [right.homeX, y],
    [right.homeX, y - height],
    [left.homeX, y - height],
  ];
  const own = beams.filter((b) => b.owner === "enemy" && b.hp > 0 && !b.background);
  const edge = (p, q) =>
    own.find((b) => {
      const u = nodes[b.a],
        v = nodes[b.b];
      if (!u || !v) return false;
      const matches = (n, t) => Math.hypot(n.homeX - t[0], n.homeY - t[1]) < 7;
      return (matches(u, p) && matches(v, q)) || (matches(v, p) && matches(u, q));
    }) || null;
  const floorBeam = edge(corners[0], corners[1]);
  const rearBeam = edge(corners[1], corners[2]);
  const roofBeam = edge(corners[2], corners[3]);
  const frontBeam = edge(corners[3], corners[0]);
  return {
    rear: !!rearBeam,
    front: !!frontBeam,
    roof: !!roofBeam,
    floor: !!floorBeam,
    closed: !!(floorBeam && rearBeam && roofBeam && frontBeam),
    left,
    right,
    y,
    height,
    corners,
    frontBeam,
  };
}
function aiCompleteEmplacement(sites) {
  if (aiMetal < cost) return false;
  const ranked = [...sites].sort((a, b) => {
    const value = (site) => {
      const room = aiEmplacementShell(site);
      if (!room.left || room.closed) return -10000;
      const progress = (Number(room.front) + Number(room.rear) + Number(room.roof)) * 125;
      const front = enemyCore.x - site.x;
      const coreDistance = Math.abs(front);
      const separation = guns
        .filter((g) => g.owner === "enemy" && weaponPosition(g))
        .reduce((m, g) => {
          const p = weaponPosition(g);
          return Math.min(m, Math.hypot(p.x - site.x, p.y - site.y));
        }, 250);
      return progress + Math.min(separation, 170) * 0.2 - coreDistance * 0.055 + Math.max(0, front) * 0.06;
    };
    return value(b) - value(a);
  });
  for (const site of ranked) {
    const e = aiEmplacementShell(site);
    if (!e.left || e.closed) continue;
    const c = e.corners;
    // Construct anchored sides first; add the roof only after both sides exist.
    // Do not require a door first: otherwise the door often consumes the only usable wall.
    const jobs = [];
    if (!e.rear) jobs.push([c[1], c[2]]);
    if (!e.front) jobs.push([c[0], c[3]]);
    if (!e.roof && e.rear && e.front) jobs.push([c[3], c[2]]);
    for (const [p, q] of jobs) {
      if (aiBeam(p[0], p[1], q[0], q[1])) {
        aiLastAction = "Baut geschlossenen Waffenraum vor Waffenmontage";
        return true;
      }
    }
  }
  return false;
}
function aiFullyProtectedSite(site) {
  const e = aiEmplacementShell(site);
  return e.closed && !!e.frontBeam && e.frontBeam.armorDoor && aiDoorProtectedSite(site, true);
}
function aiStrategicDecision(excludeStream = null) {
  aiReviewStrategy();
  // V13.99: reactive utility planner. Decisions are recomputed from actual
  // completed/pending buildings, production, ammunition and available mount sites.
  // No predetermined build sequence. The AI first checks what can actually be built.
  const enemyBeams = beams.filter((b) => b.owner === "enemy" && b.hp > 0);
  const enemyGuns = guns.filter((g) => g.owner === "enemy" && weaponPosition(g));
  const completed = (r) => (r.buildRemaining || 0) <= 0;
  const ownBuildings = aiResources.filter(
    (r) => r.hp > 0 && enemyBeams.some((b) => b.id === r.beamId && b.hp > 0),
  );
  const countType = (t) => ownBuildings.filter((r) => r.type === t).length;
  const activeType = (t) => ownBuildings.filter((r) => r.type === t && completed(r)).length;
  const pendingType = (t) => ownBuildings.filter((r) => r.type === t && !completed(r)).length;
  const workshopReady = activeType("workshop") > 0;
  // Recover missing essential production first; a half-built replacement counts as pending.
  const missingEssentials = ["mine", "wind", "workshop"].filter((t) => countType(t) === 0);
  const restoringEconomy = missingEssentials.length > 0;
  const imminentMissiles =
    guns.some(
      (g) =>
        g.owner === "player" &&
        g.hp > 0 &&
        ["rocket", "mortar"].includes(g.type) &&
        (g.buildRemaining || 0) <= 0,
    ) || shots.some((s) => !s.enemy && ["rocket", "mortar"].includes(s.weaponType) && s.life > 0);
  const flakUrgent =
    imminentMissiles && aiUnlockedWeapons.has("flak") && !enemyGuns.some((g) => g.type === "flak");
  const incomeMetal = activeType("mine") * RESOURCE_TYPES.mine.rate;
  const incomeEnergy = activeType("wind") * RESOURCE_TYPES.wind.rate;
  const playerGuns = guns.filter(
    (g) => g.owner === "player" && weaponPosition(g) && (g.buildRemaining || 0) <= 0,
  );
  const threat = Math.min(2, playerGuns.length / Math.max(1, enemyGuns.length));
  const weak = enemyBeams
    .filter((b) => b.hp > 0 && b.hp < 65 && !b.background && !b.armorDoor)
    .sort((a, b) => a.hp - b.hp);
  const maxGuns = window.fwMission?.ai?.maxGuns ?? DIFFICULTY[difficulty].maxGuns;
  const occupied = new Set([...ownBuildings, ...enemyGuns].map((r) => r.beamId));
  const mountSites = enemyBeams
    .filter((b) => aiHorizontalBeam(b) && !occupied.has(b.id))
    .map((b) => {
      const a = nodes[b.a],
        z = nodes[b.b];
      return { b, x: (a.x + z.x) / 2, y: (a.y + z.y) / 2 - 14 };
    })
    .filter((o) => o.y < floor() - 8); // Include ground-level mine foundations; guns retain their own height restriction.
  const resourceSites = mountSites.filter((o) =>
    ["mine", "wind", "workshop"].some(
      (t) => (t !== "mine" || mineGroundMount({ beamId: o.b.id })) && aiEquipmentFootprintClear(o.x, o.y, t),
    ),
  );
  const gunSites = mountSites.filter((o) => aiEquipmentFootprintClear(o.x, o.y, "gun") && o.y < floor() - 45);
  // A free deck is not a usable weapon emplacement unless a projectile can leave it.
  const safeGunSites = gunSites.filter(
    (o) =>
      !aiOwnShotBlocked(
        { beamId: o.b.id, t: 0.5, owner: "enemy", type: "cannon" },
        playerCore.x,
        playerCore.y,
      ),
  );
  const coveredGunSites = safeGunSites; // V14.84: enclosure itself provides cover; do not require an unrelated shield
  const roomGunSites = coveredGunSites.filter((site) => aiEmplacementShell(site).closed);
  const doorGunSites = roomGunSites.filter((site) => aiDoorProtectedSite(site, true));
  const enclosedGunSites = doorGunSites.filter(aiFullyProtectedSite);
  const missing = aiBlueprint.filter(
    (e) =>
      !enemyBeams.some((b) => {
        const a = nodes[b.a],
          z = nodes[b.b];
        if (!a || !z) return false;
        return (
          (Math.hypot(a.homeX - e.x1, a.homeY - e.y1) < 5 &&
            Math.hypot(z.homeX - e.x2, z.homeY - e.y2) < 5) ||
          (Math.hypot(a.homeX - e.x2, a.homeY - e.y2) < 5 && Math.hypot(z.homeX - e.x1, z.homeY - e.y1) < 5)
        );
      }),
  );
  const criticalPositions = [
    { x: enemyCore.x, y: enemyCore.y },
    ...ownBuildings.map((r) => {
      const b = enemyBeams.find((b) => b.id === r.beamId);
      if (!b) return null;
      const a = nodes[b.a],
        z = nodes[b.b];
      return a && z ? { x: (a.homeX + z.homeX) / 2, y: (a.homeY + z.homeY) / 2 } : null;
    }),
    ...enemyGuns.map((g) => weaponPosition(g)),
  ].filter(Boolean);
  const repairCandidates = missing
    .filter((e) => {
      const mx = (e.x1 + e.x2) / 2,
        my = (e.y1 + e.y2) / 2;
      if (!criticalPositions.some((p) => Math.hypot(p.x - mx, p.y - my) < 135)) return false;
      return enemyBeams.some((b) => {
        const a = nodes[b.a],
          z = nodes[b.b];
        return [a, z].some(
          (n) =>
            Math.hypot(n.homeX - e.x1, n.homeY - e.y1) < 5 || Math.hypot(n.homeX - e.x2, n.homeY - e.y2) < 5,
        );
      });
    })
    .sort(
      (a, b) =>
        Math.hypot((a.x1 + a.x2) / 2 - enemyCore.x, (a.y1 + a.y2) / 2 - enemyCore.y) -
        Math.hypot((b.x1 + b.x2) / 2 - enemyCore.x, (b.y1 + b.y2) / 2 - enemyCore.y),
    );
  const actions = [];
  const vulnerable = aiProtectionTargets().filter((t) => aiActualArmoredCover(t) < 1);
  const exposedGuns = vulnerable.filter((t) => t.gun).length;
  const preWeaponLock = enemyGuns.length === 0 && !aiFortressReadyForWeapons();
  if (preWeaponLock && workshopReady) aiShellAttempts++;
  if (enemyGuns.length > 0) aiShellAttempts = 0;
  if (
    excludeStream !== "defense" &&
    vulnerable.length &&
    aiMetal >= 85 &&
    enemyBeams.length < 76 &&
    (enemyGuns.length > 0 || !workshopReady)
  ) {
    const urgency = vulnerable.reduce((v, t) => v + t.priority / (0.4 + aiLineShieldScore(t)), 0);
    actions.push({
      name: "Schützt kritische Gebäude",
      stream: "defense",
      score: 85 + Math.min(urgency, 6) * 15 + exposedGuns * 16 + threat * 10 + Math.random() * 10,
      run: () => aiAddDefensiveCover(),
    });
  }
  if (
    excludeStream !== "armor" &&
    vulnerable.some((t) => !t.gun) &&
    aiMetal >= 48 &&
    enemyBeams.some((b) => !b.armorDoor && !b.armorWall) &&
    enemyGuns.length > 0
  ) {
    actions.push({
      name: "Panzert wichtige Gebäude",
      stream: "armor",
      score: 205 + vulnerable[0].priority * 35 + exposedGuns * 35 + threat * 12 + Math.random() * 10,
      run: () => aiArmorCriticalCover(),
    });
  }
  const streamFor = (name) =>
    name.startsWith("Errichtet")
      ? "economy"
      : name.startsWith("Baut")
        ? "weapons"
        : name.includes("Schussfeld") || name.includes("Panzertür")
          ? "tactics"
          : name.includes("Repariert") || name.includes("Rekonstruiert")
            ? "repair"
            : "structure";
  const propose = (name, score, run) => {
    const stream = streamFor(name);
    if (stream === excludeStream) return;
    // Different priorities each match, without a fixed blueprint or build order.
    const styleBias =
      aiStrategy.style === "battery"
        ? stream === "weapons"
          ? 20
          : stream === "structure"
            ? -5
            : 0
        : aiStrategy.style === "tower"
          ? stream === "structure"
            ? 16
            : stream === "weapons"
              ? -4
              : 0
          : stream === "economy"
            ? 12
            : stream === "repair"
              ? 9
              : 0;
    actions.push({ name, stream, score: score + styleBias + Math.random() * 16, run });
  };
  if (repairCandidates.length && aiMetal >= 145 && enemyGuns.length > 0)
    propose(
      "Rekonstruiert Festung",
      190 + Math.min(repairCandidates.length, 8) * 8 + threat * 25 + aiStrategy.damagePressure * 35,
      () => {
        for (const e of repairCandidates.slice(0, 16)) if (aiBeam(e.x1, e.y1, e.x2, e.y2)) return true;
        return false;
      },
    );
  // Resource demand rises if the AI cannot afford useful weapons or buildings.
  const affordableGun = Object.keys(WEAPONS).some(
    (t) => t !== "flak" && aiUnlockedWeapons.has(t) && aiMetal >= WEAPONS[t].cost,
  );
  const economyPressure = aiMetal < 110 ? 1 : aiMetal < 170 ? 0.5 : 0;
  const energyPressure = aiEnergy < 55 ? 1 : aiEnergy < 110 ? 0.5 : 0;
  for (const type of ["mine", "wind", "workshop"]) {
    const spec = RESOURCE_TYPES[type],
      count = countType(type);
    if (
      aiMetal < spec.cost ||
      !resourceSites.length ||
      (type === "mine" &&
        !resourceSites.some(
          (o) => mineGroundMount({ beamId: o.b.id }) && aiEquipmentFootprintClear(o.x, o.y, "mine"),
        ))
    )
      continue;
    let score = 0;
    if (type === "mine")
      score =
        count === 0
          ? 1950
          : enemyGuns.length === 0
            ? 0
            : count === 1
              ? 225
              : count === 2 && aiMetal < 150
                ? 125
                : 0;
    if (type === "wind")
      score = count === 0 ? 1820 : count === 1 && aiEnergy < 55 && enemyGuns.length > 0 ? 125 : 0;
    if (type === "workshop") score = count === 0 ? 1780 : 0;
    if (type === "wind" && count >= 2) score = 0;
    if (type === "mine" && count >= 3) score = 0;
    // Do not repeatedly commission identical buildings while earlier ones are under construction.
    if (pendingType(type)) score = 0;
    if (score <= 0) continue;
    propose("Errichtet " + type, score, () => {
      const viable = resourceSites.filter(
        (o) =>
          (type !== "mine" || mineGroundMount({ beamId: o.b.id })) &&
          aiEquipmentFootprintClear(o.x, o.y, type),
      );
      if (!viable.length || aiMetal < spec.cost) return false;
      viable.sort((a, b) => {
        const quality = (o) => {
          const proximity = Math.abs(o.x - enemyCore.x);
          const cover = enemyBeams.filter((e) => e.background).length;
          return (
            -proximity * 0.02 +
            aiPlacementSafety(o.x, o.y, type === "workshop" ? 1.6 : 1.0) +
            Math.min(cover, 10) * 0.1 +
            Math.random() * 9
          );
        };
        return quality(b) - quality(a);
      });
      const site = viable[0];
      const maxHp = getResourceMaxHp({ type });
      aiResources.push({
        type,
        beamId: site.b.id,
        t: 0.5,
        owner: "enemy",
        hp: maxHp,
        maxHp,
        buildRemaining: BUILD_TIMES[type],
        buildTotal: BUILD_TIMES[type],
      });
      aiMetal -= spec.cost;
      return true;
    });
  }
  // V15.58: Emergency restoration has exclusive budget priority over guns,
  // armor and research. Existing build orders finish on their own.
  if (restoringEconomy) {
    const urgent = missingEssentials.find((t) => t === "mine") || missingEssentials[0];
    const usable = mountSites.some(
      (o) =>
        (urgent !== "mine" || mineGroundMount({ beamId: o.b.id })) &&
        aiEquipmentFootprintClear(o.x, o.y, urgent),
    );
    if (!usable && aiMetal >= cost + Math.min(RESOURCE_TYPES[urgent].cost, 40)) {
      // Creates connected, usable economy deck, rather than random decorative beams.
      if (aiBuildPlatform(urgent)) {
        aiLastAction = "Schafft Ersatz-Bauplatz fuer " + urgent;
        return "structure";
      }
    }
    actions.sort((a, b) => b.score - a.score);
    for (const action of actions) {
      if (action.name === "Errichtet " + urgent && action.run()) {
        aiLastAction = action.name;
        return "economy";
      }
    }
    return null; // Save resources until the missing essential is affordable.
  }
  // Build a repair tower if the reactor is genuinely endangered.
  if (
    enemyCore &&
    enemyCore.hp < enemyCore.maxHp * 0.75 &&
    !ownBuildings.some((r) => r.type === "repair") &&
    aiMetal >= RESOURCE_TYPES.repair.cost &&
    resourceSites.length
  ) {
    propose("Errichtet Reparaturturm", 1080 + (1 - enemyCore.hp / enemyCore.maxHp) * 220, () => {
      const site = resourceSites
        .filter((o) => aiEquipmentFootprintClear(o.x, o.y, "repair"))
        .sort(
          (a, b) =>
            Math.hypot(a.x - enemyCore.x, a.y - enemyCore.y) -
            Math.hypot(b.x - enemyCore.x, b.y - enemyCore.y),
        )[0];
      if (!site || aiMetal < RESOURCE_TYPES.repair.cost) return false;
      const type = "repair";
      const maxHp = getResourceMaxHp({ type });
      aiResources.push({
        type,
        beamId: site.b.id,
        t: 0.5,
        owner: "enemy",
        hp: maxHp,
        maxHp,
        buildRemaining: BUILD_TIMES.repair,
        buildTotal: BUILD_TIMES.repair,
      });
      aiMetal -= RESOURCE_TYPES.repair.cost;
      return true;
    });
  }
  // Repairing a critically wounded reactor must not lose to a cheap cannon.
  if (
    enemyCore &&
    enemyCore.hp < enemyCore.maxHp * 0.75 &&
    !ownBuildings.some((r) => r.type === "repair") &&
    resourceSites.some((o) => aiEquipmentFootprintClear(o.x, o.y, "repair")) &&
    aiMetal < RESOURCE_TYPES.repair.cost
  ) {
    return null;
  }
  // Under an active missile threat, save for the Flak technology first.
  if (
    imminentMissiles &&
    !aiUnlockedWeapons.has("flak") &&
    !aiResearchJob &&
    enemyGuns.length > 0 &&
    aiMetal < RESEARCH.flak.metal + 20
  ) {
    return null;
  }
  // Once the first cannon is operational, choose a technology upgrade over
  // endlessly purchasing further cannons. Full turret cost is reserved after research.
  const hasFirstCannon = enemyGuns.some((g) => g.type === "cannon");
  const awaitingAutocannon =
    workshopReady &&
    hasFirstCannon &&
    !aiUnlockedWeapons.has("autocannon") &&
    (!aiResearchJob || aiResearchJob.type === "autocannon");
  if (awaitingAutocannon && aiMetal < RESEARCH.autocannon.metal + WEAPONS.mg.cost) {
    return null;
  }
  // Keep the researched Flak budget intact. Building a deck is permitted
  // only when there is no free site; otherwise save until the battery is affordable.
  if (flakUrgent && !preWeaponLock && workshopReady && aiMetal < WEAPONS.flak.cost) {
    const freeSkyDeck = gunSites.length > 0;
    if (!freeSkyDeck && aiMetal >= cost + 30 && aiBuildPlatform()) {
      aiLastAction = "Bereitet Flak-Stellung vor";
      return "structure";
    }
    return null;
  }
  // Hard pre-weapon lock: the AI must first seal and cover its fortress.
  // Weapons are not permitted until the shell is sufficiently closed.
  const structuralCount = enemyBeams.length;
  const builtGuns = enemyGuns.length;
  if (
    excludeStream !== "structure" &&
    preWeaponLock &&
    workshopReady &&
    activeType("mine") > 0 &&
    activeType("wind") > 0 &&
    aiMetal >= cost + 125
  ) {
    propose(
      "Versiegelt Festung vor Waffenbau",
      980 + Math.random() * 20,
      () => aiSealFortress(true) || aiAddDefensiveCover() || aiBuildPlatform(),
    );
  }
  // After the shell phase, make a weapon-ready platform before spending surplus on decoration.
  if (
    !preWeaponLock &&
    workshopReady &&
    enemyGuns.length === 0 &&
    safeGunSites.length === 0 &&
    aiMetal >= cost &&
    excludeStream !== "structure"
  ) {
    propose("Schafft geschützte Waffenplattform", 800, () => aiBuildPlatform());
  }
  // Assemble a physically connected room, THEN convert its front wall into a door.
  if (
    !preWeaponLock &&
    workshopReady &&
    coveredGunSites.length &&
    !roomGunSites.length &&
    aiMetal >= cost &&
    excludeStream !== "structure"
  ) {
    propose("Baut Waffenraum vor Tür und Waffe", 990, () => aiCompleteEmplacement(coveredGunSites));
  }
  if (!preWeaponLock && workshopReady && roomGunSites.length && doorGunSites.length === 0 && aiMetal >= 48) {
    propose("Setzt Panzertür in geschlossene Waffenstellung", 980, () => aiPrepareDoorForSite(roomGunSites));
  }
  // Continue sealing remaining short gaps, at lower priority than useful weapons.
  if (excludeStream !== "structure" && builtGuns > 0 && aiMetal >= 215 && structuralCount < 50) {
    propose("Verdichtet Festung", 175 + Math.random() * 18, () => aiSealFortress(false));
  }
  // Door protection is an optional tactical choice competing with other priorities.
  if (enemyGuns.some((g) => g.type !== "flak" && !aiGunDoor(g, true)) && aiMetal >= 60) {
    propose("Sichert Waffenstellung mit Panzertür", 430 + threat * 18 + aiStrategy.damagePressure * 20, () =>
      aiInstallArmorDoor(),
    );
  }
  if (weak.length && aiMetal >= 155 && enemyGuns.length > 0) {
    const target = weak[0];
    propose("Repariert Konstruktion", 25 + (65 - target.hp) * 0.75 + threat * 25, () => {
      if (aiMetal < 20 || target.hp <= 0) return false;
      target.hp = Math.min(100, target.hp + 35);
      aiMetal -= 20;
      return true;
    });
  }
  if (
    !preWeaponLock &&
    workshopReady &&
    enemyGuns.filter((g) => g.type !== "flak").length < maxGuns &&
    enclosedGunSites.length &&
    (!enemyGuns.some((g) => g.type !== "flak" && !aiGunDoor(g, true)) || aiMetal < 48 + cost * 2)
  ) {
    const types = Object.keys(WEAPONS).filter(
      (t) => t !== "flak" && aiUnlockedWeapons.has(t) && aiMetal >= WEAPONS[t].cost,
    );
    for (const type of types) {
      // A single initial MG is fine. Afterwards, accumulate metal for cannons
      // or the researched specialist gun instead of endlessly buying new MGs.
      if (
        type === "mg" &&
        enemyGuns.some((g) => g.type === "mg") &&
        enemyGuns.filter((g) => g.type !== "flak").length >= 1
      )
        continue;
      if (
        type === "cannon" &&
        enemyGuns.some((g) => g.type === "cannon") &&
        !aiUnlockedWeapons.has("autocannon")
      )
        continue;
      if (imminentMissiles && !aiUnlockedWeapons.has("flak") && type !== "mg" && enemyGuns.length >= 1)
        continue;
      if (
        aiUnlockedWeapons.has("autocannon") &&
        !enemyGuns.some((g) => g.type === "autocannon") &&
        type === "cannon" &&
        enemyGuns.some((g) => g.type === "cannon")
      )
        continue;
      if (flakUrgent && aiMetal - WEAPONS[type].cost < WEAPONS.flak.cost) continue;
      const spec = WEAPONS[type],
        same = enemyGuns.filter((g) => g.type === type).length;
      const dmg = Math.min(36, spec.damage * 0.19);
      const shortage = Math.max(0, spec.energy - aiEnergy) * 1.4;
      const weaponDiversity =
        type === "cannon"
          ? 165
          : type === "autocannon"
            ? 400
            : type === "rocket"
              ? 240
              : type === "heavy"
                ? 280
                : type === "mortar"
                  ? 230
                  : type === "sniper"
                    ? 190
                    : 0;
      const score =
        240 +
        weaponDiversity +
        dmg +
        Math.min(threat, 1.5) * 23 -
        same * 38 -
        shortage +
        (aiStrategy.style === "battery" ? 23 : aiStrategy.style === "tower" ? -8 : 0) +
        (enemyGuns.length === 0 ? 37 : 0) +
        (affordableGun ? 0 : -20);
      propose("Baut " + type, score, () => {
        if (aiMetal < spec.cost) return false;
        const viable = enclosedGunSites.filter((o) => aiEquipmentFootprintClear(o.x, o.y, "gun"));
        if (!viable.length) return false;
        viable.sort((a, b) => {
          const quality = (o) => {
            const separation = enemyGuns.length
              ? Math.min(
                  ...enemyGuns.map((g) => {
                    const pos = weaponPosition(g);
                    return pos ? Math.hypot(pos.x - o.x, pos.y - o.y) : 300;
                  }),
                )
              : 260;
            const front = (enemyCore.x - o.x) * 0.07;
            // Prefer compact but safe batteries, not weapons scattered across the map.
            const ideal = 110;
            const spacing = enemyGuns.length ? -Math.abs(separation - ideal) * 0.62 : 0;
            const safeLane = aiOwnShotBlocked(
              { beamId: o.b.id, t: 0.5, owner: "enemy", type },
              playerCore.x,
              playerCore.y,
            )
              ? -105
              : 0;
            const nearAnchors = enemyBeams.some((b) => {
              const a = nodes[b.a],
                z = nodes[b.b];
              return [a, z].some((n) => n && o.x - n.x > 45 && o.x - n.x < 115 && Math.abs(o.y - n.y) < 82);
            });
            const defenseScore = nearAnchors ? 75 : -95;
            return (
              defenseScore +
              spacing +
              front * (aiStrategy.style === "battery" ? 0.8 : 0.2) +
              safeLane +
              (aiStrategy.style === "tower" ? (floor() - o.y) * 0.07 : 0) +
              (aiStrategy.style === "compact" ? -Math.abs(o.x - enemyCore.x) * 0.025 : 0) +
              Math.random() * 18
            );
          };
          return quality(b) - quality(a);
        });
        const site = viable.find(
          (o) =>
            aiFullyProtectedSite(o) &&
            !aiOwnShotBlocked({ beamId: o.b.id, t: 0.5, owner: "enemy", type }, playerCore.x, playerCore.y),
        );
        if (!site) return false;
        guns.push({
          beamId: site.b.id,
          t: 0.5,
          owner: "enemy",
          type,
          hp: 130,
          maxHp: 130,
          angle: Math.PI,
          flash: 0,
          cooldown: 0,
          buildRemaining: BUILD_TIMES[type],
          buildTotal: BUILD_TIMES[type],
        });
        aiMetal -= spec.cost;
        return true;
      });
    }
  }

  // Construct ONE reactive flak battery when the player fields missile or mortar weapons.
  // Uses the same free enclosed decks as the ordinary AI, with no fixed coordinates.
  const missileThreat = imminentMissiles;
  const builtFlak = enemyGuns.filter((g) => g.type === "flak").length;
  if (flakUrgent && !preWeaponLock && workshopReady && !builtFlak) {
    // The anti-air weapon needs a clear sky, not a sealed firing room.
    // No purchase until its whole cost is saved; prioritize it before a new MG.
    if (aiMetal >= WEAPONS.flak.cost && gunSites.length) {
      propose("Baut Flak-Abwehr", 2300 + threat * 55, () => {
        const site = gunSites
          .filter((o) => aiEquipmentFootprintClear(o.x, o.y, "gun"))
          .sort((a, b) => aiPlacementSafety(b.x, b.y, 1.4) - aiPlacementSafety(a.x, a.y, 1.4))[0];
        if (!site || aiMetal < WEAPONS.flak.cost) return false;
        guns.push({
          beamId: site.b.id,
          t: 0.5,
          owner: "enemy",
          type: "flak",
          hp: 130,
          maxHp: 130,
          angle: Math.PI,
          flash: 0,
          cooldown: 0,
          buildRemaining: BUILD_TIMES.flak,
          buildTotal: BUILD_TIMES.flak,
        });
        aiMetal -= WEAPONS.flak.cost;
        return true;
      });
    } else if (!gunSites.length && aiMetal >= cost + 40) {
      propose("Schafft Flak-Stellung", 1500, () => aiBuildPlatform());
    }
  }
  // Only extend the fort when it needs a usable mount, cover, or room to grow.
  // Critically: never allow a high "build more beams" score to starve the economy.
  const needsResourceMount = ["mine", "wind", "workshop"].some(
    (t) =>
      (t === "mine" ? countType(t) < 2 : countType(t) < 1) &&
      !mountSites.some(
        (o) =>
          (t !== "mine" || mineGroundMount({ beamId: o.b.id })) && aiEquipmentFootprintClear(o.x, o.y, t),
      ),
  );
  const needsGunMount =
    workshopReady && !preWeaponLock && safeGunSites.length === 0 && enemyGuns.length < maxGuns;
  const needsExpansion =
    needsResourceMount ||
    needsGunMount ||
    (resourceSites.length === 0 && (economyPressure > 0.5 || energyPressure > 0.5));
  // V14.38: Once the economy and first weapons are established, invest excess
  // metal in gradual, situational fort growth instead of freezing at the old cap.
  // Keep a reserve for repairs, weapons and resource buildings; never prescribe a layout.
  const surplusMetal =
    aiMetal >= 310 &&
    vulnerable.length === 0 &&
    incomeMetal > 0 &&
    workshopReady &&
    enemyGuns.length > 0 &&
    safeGunSites.length > 1 &&
    enemyBeams.length < 46;
  const expansionHeadroom = enemyBeams.length < 46;
  if (surplusMetal && expansionHeadroom && !needsExpansion && excludeStream !== "structure") {
    const density = enemyBeams.length;
    const surplusScore = density < 32 ? 70 : 32;
    propose("Erweitert Festung aus Überschuss", surplusScore + Math.random() * 9, () => aiBuildPlatform());
  }
  if (
    aiMetal >= cost &&
    enemyBeams.length < (needsGunMount ? 100 : 82) &&
    needsExpansion &&
    (countType("mine") > 0 || aiMetal >= RESOURCE_TYPES.mine.cost + cost)
  ) {
    const urgent = needsResourceMount || needsGunMount;
    propose(
      "Erschließt Bauplatz",
      (urgent ? (needsGunMount ? (enemyGuns.length === 0 ? 540 : 355) : 310) : 48) +
        (aiStrategy.style === "tower" ? 12 : aiStrategy.style === "compact" ? -12 : 5) -
        aiStrategy.damagePressure * 12,
      () => aiBuildPlatform(),
    );
  }
  // Clear blocked firing lanes only if guns already exist and have targets.
  if (enemyGuns.length) {
    const blocked = enemyGuns.filter((g) => completed(g) && aiOwnShotBlocked(g, playerCore.x, playerCore.y));
    if (blocked.length)
      propose("Öffnet Schussfeld", 35 + blocked.length * 10, () => {
        for (const gun of blocked) {
          const pos = weaponPosition(gun);
          if (!pos) continue;
          const candidates = enemyBeams
            .filter((b) => !b.background && !b.armorDoor && b.hp > 0)
            .map((b) => ({
              b,
              d: Math.hypot(
                (nodes[b.a].x + nodes[b.b].x) / 2 - pos.x,
                (nodes[b.a].y + nodes[b.b].y) / 2 - pos.y,
              ),
            }))
            .filter((o) => o.d > 42 && o.d < 300)
            .sort((a, b) => a.d - b.d);
          for (const { b } of candidates) {
            aiSetBackground(b);
            if (!aiOwnShotBlocked(gun, playerCore.x, playerCore.y)) return true;
            b.background = false;
          }
        }
        return false;
      });
  }
  actions.sort((a, b) => b.score - a.score);
  for (const action of actions) {
    if (action.run()) {
      if (action.stream === "weapons") {
        aiStallTicks = 0;
        aiLastGunCount = enemyGuns.length + 1;
      } else if (workshopReady && !enemyGuns.length) aiStallTicks = Math.min(200, aiStallTicks + 1);
      aiLastAction = action.name;
      return action.stream;
    }
  }
  if (workshopReady && enemyGuns.length === 0 && aiMetal >= cost) {
    aiStallTicks++;
    if (
      preWeaponLock &&
      workshopReady &&
      activeType("mine") > 0 &&
      activeType("wind") > 0 &&
      aiMetal >= cost + 65
    ) {
      if (aiSealFortress(true) || aiAddDefensiveCover() || aiBuildPlatform()) {
        aiLastAction = "Versiegelt Festung";
        return "structure";
      }
    }
    // Only once the shell is closed may the AI prepare or use weapon mounts.
    else if (aiBuildPlatform()) {
      aiLastAction = "Erschließt fehlende Waffenstellung";
      return "structure";
    }
  }

  // If no scored action is currently possible, use the turn to create a
  // genuine missing mount, not to endlessly fill the map with wooden beams.
  if (
    aiMetal >= cost &&
    enemyBeams.length < (workshopReady && safeGunSites.length === 0 ? 100 : 82) &&
    (resourceSites.length === 0 || (workshopReady && safeGunSites.length === 0 && enemyGuns.length < maxGuns))
  ) {
    if (excludeStream !== "structure" && aiBuildPlatform()) {
      aiLastAction = "Schafft Bauplatz";
      return "structure";
    }
  }
  return null;
}
// V11.7: Cinematic overview of both forts, followed by a smooth focus on the player's fort.
let openingCamera = null;
function startOpeningCamera() {
  const overviewZoom = Math.max(0.16, Math.min(0.8, (W - 32) / 2110, (H - 35) / 560));
  const playerZoom = 0.65;
  const playerCamX = Math.round(W * 0.5 - 320 * playerZoom);
  const playerCamY = Math.round(H * 0.6 - floor() * playerZoom);
  const centerX = 1120,
    centerY = floor() - 120;
  zoom = overviewZoom;
  camX = W / 2 - centerX * zoom;
  camY = H / 2 - centerY * zoom;
  openingCamera = {
    start: performance.now(),
    fromZoom: zoom,
    fromX: camX,
    fromY: camY,
    toZoom: playerZoom,
    toX: playerCamX,
    toY: playerCamY,
  };
  document.getElementById("zoomlevel").textContent = Math.round(zoom * 100) + "%";
}
function animateOpeningCamera(now) {
  if (!openingCamera) return;
  const elapsed = (now - openingCamera.start) / 1000;
  // Hold the two-fort overview briefly, then travel gently to the player's fort.
  const t = Math.max(0, Math.min(1, (elapsed - 1.35) / 2.5));
  const eased = t * t * (3 - 2 * t);
  zoom = openingCamera.fromZoom + (openingCamera.toZoom - openingCamera.fromZoom) * eased;
  camX = openingCamera.fromX + (openingCamera.toX - openingCamera.fromX) * eased;
  camY = openingCamera.fromY + (openingCamera.toY - openingCamera.fromY) * eased;
  document.getElementById("zoomlevel").textContent = Math.round(zoom * 100) + "%";
  if (t >= 1) openingCamera = null;
}
function frame(now) {
  animateOpeningCamera(now);
  let dt = Math.min((now - last) / 1000, 0.04);
  last = now;
  weatherTime += dt;
  fwImpactShake = Math.max(0, fwImpactShake - 38 * dt);
  fwImpactShakePhase += dt * 35;
  updateMusic(dt);
  acc += dt;
  if (!paused) {
    while (acc >= 1 / 60) {
      physics(1 / 60);
      acc -= 1 / 60;
    }
  } else {
    acc = 0;
    if (reactorBlast) {
      for (const p of particles) {
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.vy += 270 * dt;
        p.life -= dt;
      }
      particles = particles.filter((p) => p.life > 0);
    }
  }
  render();
  requestAnimationFrame(frame);
}
demo();
hud();
paused = true;
fwSetPauseOrb(true);
requestAnimationFrame(frame);

// V11.6 main menu and persistent accessibility preferences.
let menuHasGame = false;
const mainOverlay = document.getElementById("mainOverlay"),
  settingsPanel = document.getElementById("settingsPanel");
let menuWasPaused = true;
function openMainMenu() {
  menuWasPaused = paused;
  paused = true;
  fwSetPauseOrb(true);
  document.getElementById("menu").hidden = true;
  document.getElementById("difficultyOverlay").hidden = true;
  document.getElementById("mainContinue").disabled = !menuHasGame;
  mainOverlay.hidden = false;
  hud();
}
function continueGame() {
  if (!menuHasGame) return;
  mainOverlay.hidden = true;
  paused = menuWasPaused;
  fwSetPauseOrb(paused);
  hud();
}
function openGameSettings() {
  document.getElementById("settingDifficulty").value = difficulty;
  document.getElementById("settingSound").checked = soundEnabled;
  document.getElementById("settingMusic").checked = musicEnabled;
  settingsPanel.hidden = false;
}
function saveGameSettings() {
  let v = {
    difficulty: document.getElementById("settingDifficulty").value,
    tips: document.getElementById("settingTips").checked,
    motion: document.getElementById("settingMotion").checked,
    sound: document.getElementById("settingSound").checked,
    music: document.getElementById("settingMusic").checked,
  };
  soundEnabled = v.sound !== false;
  musicEnabled = !!v.music;
  setDifficulty(v.difficulty);
  document.getElementById("tip").style.display = v.tips ? "" : "none";
  document.documentElement.classList.toggle("reduced-motion", v.motion);
  try {
    localStorage.setItem("fortress_settings_v116", JSON.stringify(v));
  } catch (e) {}
  settingsPanel.hidden = true;
}
try {
  const v = JSON.parse(localStorage.getItem("fortress_settings_v116") || "null");
  if (v) {
    setDifficulty(v.difficulty || "normal");
    document.getElementById("settingTips").checked = v.tips !== false;
    document.getElementById("settingMotion").checked = !!v.motion;
    soundEnabled = v.sound !== false;
    musicEnabled = !!v.music;
    document.getElementById("settingSound").checked = soundEnabled;
    document.getElementById("settingMusic").checked = musicEnabled;
    document.getElementById("tip").style.display = v.tips === false ? "none" : "";
    document.documentElement.classList.toggle("reduced-motion", !!v.motion);
  }
} catch (e) {}
document.getElementById("difficultyClose").addEventListener("click", () => {
  // Close the selection without starting or resetting the battle.
  // Return to the main menu with the usual Continue/New Game controls.
  openMainMenu();
});
document.getElementById("mainMenuButton").onclick = openMainMenu;
document.getElementById("openMainFromTools").onclick = openMainMenu;
document.getElementById("mainContinue").onclick = continueGame;
document.getElementById("mainNew").onclick = () => {
  mainOverlay.hidden = true;
  document.getElementById("difficultyOverlay").hidden = false;
  paused = true;
};
document.getElementById("mainSettings").onclick = openGameSettings;
document.getElementById("settingsClose").onclick = () => saveGameSettings();
document.getElementById("fwSettingsX").onclick = saveGameSettings;
const fwOriginalOpenGameSettings = openGameSettings;
openGameSettings = function () {
  fwOriginalOpenGameSettings();
  document.getElementById("fwSettingsScreen").value = document.fullscreenElement ? "fullscreen" : "normal";
  try {
    document.getElementById("fwSettingsVibration").checked =
      localStorage.getItem("fortress_vibration") !== "off";
  } catch (e) {}
};
const fwOriginalSaveGameSettings = saveGameSettings;
saveGameSettings = function () {
  const desiredFull = document.getElementById("fwSettingsScreen").value === "fullscreen";
  try {
    localStorage.setItem(
      "fortress_vibration",
      document.getElementById("fwSettingsVibration").checked ? "on" : "off",
    );
  } catch (e) {}
  if (desiredFull && !document.fullscreenElement) {
    try {
      document.documentElement.requestFullscreen?.().catch(() => {});
    } catch (e) {}
  }
  if (!desiredFull && document.fullscreenElement) {
    try {
      document.exitFullscreen?.().catch(() => {});
    } catch (e) {}
  }
  fwOriginalSaveGameSettings();
};

document.getElementById("mainHelp").onclick = () => {
  fwOpenGuide(false);
  return;
  alert(
    "RIVETS & RUIN\n\n• Bauen: Ziehe von einem Ankerpunkt deiner eigenen Festung zum nächsten Punkt.\n• Waffen und Gebäude: Nur auf waagerechten Balken platzieren.\n• Balken: Im Bauteilmenü nach hinten setzen, panzern oder entfernen.\n• Waffen: Auswählen, Ziel bestimmen und FEUER drücken.\n• Zwei Finger: Kamera verschieben und zoomen.\n• Die KI baut und kämpft selbstständig.\n\nZiel: Zerstöre den gegnerischen Reaktor!",
  );
};
// Restart button in game should return to a difficulty choice, not bypass main menu.
document.getElementById("difficultyStart").addEventListener("click", () => {
  menuWasPaused = false;
});

// Native browser fullscreen (supported on most Android browsers).
const fullscreenButton = document.getElementById("fullscreenButton");
function updateFullscreenButton() {
  const active = !!(document.fullscreenElement || document.webkitFullscreenElement);
  fullscreenButton.textContent = active ? "⛶" : "⛶";
  fullscreenButton.setAttribute("aria-label", active ? "Vollbild beenden" : "Vollbild einschalten");
  fullscreenButton.title = active ? "Vollbild beenden" : "Vollbild einschalten";
  fullscreenButton.classList.toggle("active", active);
}
fullscreenButton.addEventListener("click", async () => {
  try {
    if (document.fullscreenElement || document.webkitFullscreenElement) {
      if (document.exitFullscreen) await document.exitFullscreen();
      else if (document.webkitExitFullscreen) document.webkitExitFullscreen();
    } else {
      const el = document.documentElement;
      if (el.requestFullscreen) await el.requestFullscreen({ navigationUI: "hide" });
      else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen();
      else document.getElementById("tip").textContent = "Dieser Browser unterstützt den Vollbildmodus nicht.";
    }
  } catch (e) {
    document.getElementById("tip").textContent =
      "Vollbild konnte nicht aktiviert werden. Bitte im Browser öffnen.";
  }
  updateFullscreenButton();
});
document.addEventListener("fullscreenchange", updateFullscreenButton);
document.addEventListener("webkitfullscreenchange", updateFullscreenButton);

// Standalone offline studio ident: shown only on initial page load.
(() => {
  const splash = document.getElementById("studioSplash");
  let closed = false;
  const dismiss = () => {
    if (closed) return;
    closed = true;
    splash.classList.add("splashGone");
    setTimeout(() => splash.remove(), 650);
  };
  splash.addEventListener("click", dismiss);
  splash.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      dismiss();
    }
  });
  setTimeout(dismiss, 2600);
})();

// Online play (host-authoritative, both sides fully playable): see js/online-match.js
