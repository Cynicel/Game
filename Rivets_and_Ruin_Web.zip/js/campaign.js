// V15.60: Campaign (12 missions), battlefield choice and Sudden Death.
// Missions only *configure* a normal match: start resources, unlocked/allowed
// weapons, AI limits, battlefield and the objective. The match itself runs on
// the regular game code.
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const store = {
    get(k, d) {
      try {
        const v = localStorage.getItem(k);
        return v == null ? d : JSON.parse(v);
      } catch (e) {
        return d;
      }
    },
    set(k, v) {
      try {
        localStorage.setItem(k, JSON.stringify(v));
      } catch (e) {}
    },
  };
  const fmt = (sec) => {
    sec = Math.max(0, Math.ceil(sec));
    return Math.floor(sec / 60) + ":" + String(sec % 60).padStart(2, "0");
  };

  /* ------------------------------------------------------------------ */
  /* Mission data                                                        */
  /* goal: "destroy" (optional timeLimit) or "survive" (time)            */
  /* par : time in seconds for the 3rd star on "destroy" missions        */
  /* ------------------------------------------------------------------ */
  const MISSIONS = [
    {
      id: 1,
      title: "Feuertaufe",
      difficulty: "easy",
      battlefield: "Alpen",
      goal: "destroy",
      par: 600,
      ai: { maxGuns: 1, fireDelayScale: 1.6 },
      brief:
        "Baue Mine, Windrad und Werkstatt, dann eine Kanone. Mach die Wand vor der Kanone zur Panzertür, damit sie hinausschießen kann – grüne Bauplätze zeigen freie Schusslinien.",
    },
    {
      id: 2,
      title: "Eisen und Wind",
      difficulty: "easy",
      battlefield: "Wüstenklippen",
      goal: "destroy",
      par: 660,
      ai: { maxGuns: 2, fireDelayScale: 1.3 },
      brief: "Eine starke Wirtschaft gewinnt Kriege. Baue früh eine zweite Mine – der Gegner hat nur zwei Geschütze.",
    },
    {
      id: 3,
      title: "Halte die Stellung",
      difficulty: "normal",
      battlefield: "Nebelwald",
      goal: "survive",
      time: 240,
      ai: { metal: 250 },
      brief:
        "Der Feind startet mit Vorsprung. Halte deinen Reaktor 4 Minuten lang am Leben – Panzerwände und Reparatur sind deine Freunde.",
    },
    {
      id: 4,
      title: "Steilfeuer",
      difficulty: "easy",
      battlefield: "Alpen",
      goal: "destroy",
      par: 720,
      allowed: ["mortar", "mg", "flak"],
      player: { unlocked: ["mortar"], metal: 160 },
      ai: { maxGuns: 3 },
      brief: "Nur Mörser und MG erlaubt. Mörser schießen in hohem Bogen über Wände hinweg – nutze das.",
    },
    {
      id: 5,
      title: "Nebelwald",
      difficulty: "normal",
      battlefield: "Nebelwald",
      goal: "destroy",
      par: 720,
      brief: "Ein faires Duell auf normaler Stufe. Zeig, was du gelernt hast.",
    },
    {
      id: 6,
      title: "Blitzangriff",
      difficulty: "normal",
      battlefield: "Wüstenklippen",
      goal: "destroy",
      timeLimit: 480,
      par: 360,
      player: { metal: 260 },
      brief: "Du hast 8 Minuten. Mehr Starteisen – investiere schnell in Geschütze.",
    },
    {
      id: 7,
      title: "Raketenhagel",
      difficulty: "normal",
      battlefield: "Gewitterfront",
      goal: "destroy",
      par: 780,
      player: { unlocked: ["flak"] },
      ai: { metal: 200, unlocked: ["rocket"] },
      brief: "Der Gegner hat Raketen bereits erforscht. Deine Flak-Abwehr ist freigeschaltet – sie fängt Raketen automatisch ab.",
    },
    {
      id: 8,
      title: "Präzisionsarbeit",
      difficulty: "normal",
      battlefield: "Alpen",
      goal: "destroy",
      par: 780,
      allowed: ["sniper", "mg", "flak"],
      player: { unlocked: ["sniper"], metal: 180 },
      brief: "Nur Präzisionsgeschütz, MG und Flak. Wenig Splitterwirkung – triff die richtigen Balken.",
    },
    {
      id: 9,
      title: "Wüstensturm",
      difficulty: "hard",
      battlefield: "Wüstenklippen",
      goal: "destroy",
      par: 840,
      ai: { metal: 300 },
      brief: "Schwere KI mit Startvorsprung. Baue deine Verteidigung, bevor du angreifst.",
    },
    {
      id: 10,
      title: "Gewitterfront",
      difficulty: "hard",
      battlefield: "Gewitterfront",
      goal: "destroy",
      par: 840,
      brief: "Ein Duell auf Augenhöhe gegen die schwere KI.",
    },
    {
      id: 11,
      title: "Belagerung",
      difficulty: "hard",
      battlefield: "Nebelwald",
      goal: "survive",
      time: 360,
      player: { metal: 250 },
      ai: { metal: 400, unlocked: ["rocket", "mortar"] },
      brief: "Die Belagerer haben Raketen und Mörser. Überlebe 6 Minuten.",
    },
    {
      id: 12,
      title: "Entscheidungsschlacht",
      difficulty: "hard",
      battlefield: "Gewitterfront",
      goal: "destroy",
      par: 900,
      suddenDeath: true,
      player: { metal: 300 },
      ai: { metal: 300, maxGuns: 8, unlocked: ["autocannon", "rocket", "mortar", "heavy", "sniper", "flak"] },
      brief: "Der Gegner hat alles erforscht und darf 8 Geschütze bauen. Nach 10 Minuten beginnt Sudden Death.",
    },
  ];
  window.FW_MISSIONS = MISSIONS;
  const PROGRESS_KEY = "fw_campaign_v1";
  const progress = () => store.get(PROGRESS_KEY, {});
  const unlocked = (i) => i === 0 || (progress()[MISSIONS[i - 1].id] || 0) > 0;
  const starsText = (n) => "★".repeat(n) + "☆".repeat(3 - n);
  const goalText = (m) =>
    m.goal === "survive"
      ? "Überlebe " + fmt(m.time) + " Minuten"
      : "Zerstöre den feindlichen Reaktor" + (m.timeLimit ? " in " + fmt(m.timeLimit) + " Minuten" : "");
  const starRules = (m) =>
    m.goal === "survive"
      ? "★ geschafft · ★★ Reaktor ≥ 50 % · ★★★ Reaktor ≥ 80 %"
      : "★ Sieg · ★★ Reaktor ≥ 50 % · ★★★ Sieg in " + fmt(m.par);

  /* ------------------------------------------------------------------ */
  /* UI: campaign dialog, battlefield picker, mission badge              */
  /* ------------------------------------------------------------------ */
  const dlg = document.createElement("div");
  dlg.className = "fw1441Dialog";
  dlg.id = "fwCampaign";
  dlg.hidden = true;
  dlg.innerHTML = '<section role="dialog" aria-modal="true" aria-labelledby="fwCampaignTitle"></section>';
  document.body.appendChild(dlg);
  const box = dlg.querySelector("section");

  function renderList() {
    const prog = progress();
    const total = MISSIONS.reduce((s, m) => s + (prog[m.id] || 0), 0);
    box.innerHTML =
      '<h2 id="fwCampaignTitle">🏰 Kampagne</h2><p class="fwCampSub">' +
      total +
      " / " +
      MISSIONS.length * 3 +
      ' Sterne</p><div class="fwCampList">' +
      MISSIONS.map((m, i) => {
        const open = unlocked(i),
          st = prog[m.id] || 0;
        return (
          '<button type="button" class="fwCampItem' +
          (open ? "" : " locked") +
          '" data-i="' +
          i +
          '"' +
          (open ? "" : " disabled") +
          '><span class="n">' +
          m.id +
          '</span><span class="t">' +
          m.title +
          "<small>" +
          ({ easy: "Leicht", normal: "Normal", hard: "Schwer" }[m.difficulty] || "") +
          " · " +
          (m.goal === "survive" ? "Überleben" : m.timeLimit ? "Auf Zeit" : "Zerstören") +
          '</small></span><span class="s">' +
          (open ? starsText(st) : "🔒") +
          "</span></button>"
        );
      }).join("") +
      '</div><button type="button" id="fwCampClose">Zurück</button>';
    box.querySelectorAll(".fwCampItem").forEach((b) => (b.onclick = () => renderDetail(+b.dataset.i)));
    $("fwCampClose").onclick = () => (dlg.hidden = true);
  }
  function renderDetail(i) {
    const m = MISSIONS[i],
      st = progress()[m.id] || 0;
    box.innerHTML =
      '<div class="fwCampStep">MISSION ' +
      m.id +
      " VON " +
      MISSIONS.length +
      "</div><h2>" +
      m.title +
      '</h2><div class="fwCampStars">' +
      starsText(st) +
      '</div><p class="fwCampBrief">' +
      m.brief +
      '</p><div class="fwCampFacts"><div><b>Ziel:</b> ' +
      goalText(m) +
      "</div><div><b>KI:</b> " +
      ({ easy: "Leicht", normal: "Normal", hard: "Schwer" }[m.difficulty] || "") +
      " · <b>Schlachtfeld:</b> " +
      m.battlefield +
      "</div>" +
      (m.allowed
        ? "<div><b>Erlaubte Waffen:</b> " + m.allowed.map((w) => WEAPONS[w]?.name || w).join(", ") + "</div>"
        : "") +
      '<div class="fwCampRules">' +
      starRules(m) +
      '</div></div><button type="button" class="primary" id="fwCampStart">▶ Mission starten</button><button type="button" id="fwCampBack">‹ Alle Missionen</button>';
    $("fwCampStart").onclick = () => startMission(m);
    $("fwCampBack").onclick = renderList;
  }
  window.fwOpenCampaign = function () {
    renderList();
    dlg.hidden = false;
  };
  $("fwPlayCampaign")?.addEventListener("click", () => {
    $("fwPlayChoice").hidden = true;
    fwOpenCampaign();
  });
  $("fwPlayNew")?.addEventListener("click", () => {
    pendingMission = null;
  });

  // Battlefield + Sudden Death options in the skirmish (Gefecht) dialog
  const opts = document.createElement("div");
  opts.id = "fwSkirmishOptions";
  opts.innerHTML =
    '<label>Schlachtfeld<select id="fwBattlefield"><option value="">Zufällig</option>' +
    BATTLEFIELDS.map((b) => '<option value="' + b.name + '">' + b.name + "</option>").join("") +
    '</select></label><label class="fwSdToggle"><input type="checkbox" id="fwSuddenDeathOpt"> Sudden Death nach 10 Minuten</label>';
  const startBtn = $("difficultyStart");
  startBtn.parentNode.insertBefore(opts, startBtn);
  const prefs = store.get("fw_skirmish_prefs", { battlefield: "", suddenDeath: true });
  $("fwBattlefield").value = prefs.battlefield || "";
  $("fwSuddenDeathOpt").checked = prefs.suddenDeath !== false;
  const savePrefs = () =>
    store.set("fw_skirmish_prefs", { battlefield: $("fwBattlefield").value, suddenDeath: $("fwSuddenDeathOpt").checked });
  $("fwBattlefield").addEventListener("change", savePrefs);
  $("fwSuddenDeathOpt").addEventListener("change", savePrefs);

  const badge = document.createElement("div");
  badge.id = "fwMissionBadge";
  badge.hidden = true;
  document.body.appendChild(badge);

  /* ------------------------------------------------------------------ */
  /* Starting a match                                                    */
  /* ------------------------------------------------------------------ */
  let pendingMission = null;
  const SUDDEN_DEATH_AT = 600;

  function startMission(m) {
    pendingMission = m;
    setDifficulty(m.difficulty);
    dlg.hidden = true;
    $("fwPlayChoice").hidden = true;
    $("resultOverlay").hidden = true;
    $("mainOverlay").hidden = true;
    startBtn.click(); // regular start path: reset(), camera, tutorial, autosave …
  }

  function placeFree(owner, type, x) {
    const list = owner === "enemy" ? aiResources : resources;
    const b = beams.find((b) => {
      if (b.owner !== owner || b.hp <= 0) return false;
      const a = nodes[b.a],
        z = nodes[b.b];
      return (
        a && z && Math.abs(a.y - floor()) < 2 && Math.abs(z.y - floor()) < 2 && Math.min(a.x, z.x) < x && Math.max(a.x, z.x) > x
      );
    });
    if (!b) return;
    const a = nodes[b.a],
      z = nodes[b.b];
    const t = (x - a.x) / (z.x - a.x);
    const maxHp = getResourceMaxHp({ type });
    list.push({ type, beamId: b.id, t, owner, hp: maxHp, maxHp, buildRemaining: 0, buildTotal: 0 });
  }

  // Runs after the regular start handlers (registered later).
  startBtn.addEventListener("click", () => {
    const m = pendingMission;
    pendingMission = null;
    window.fwMission = m || null;
    window.__fwEndReason = null;
    sdAnnounced = false;
    lastT = 0;
    if (m) {
      const bf = BATTLEFIELDS.find((b) => b.name === m.battlefield);
      if (bf) battlefield = bf;
      const p = m.player || {},
        ai = m.ai || {};
      if (p.metal != null) metal = p.metal;
      if (p.energy != null) energy = p.energy;
      (p.unlocked || []).forEach((w) => unlockedWeapons.add(w));
      (p.buildings || []).forEach(([type, x]) => placeFree("player", type, x));
      if (ai.metal != null) aiMetal = ai.metal;
      if (ai.energy != null) aiEnergy = ai.energy;
      (ai.unlocked || []).forEach((w) => aiUnlockedWeapons.add(w));
      window.fwSuddenDeath = !!m.suddenDeath;
      hud();
      refreshResearchUI();
      refreshArsenalLocks();
      setTimeout(() => {
        if (window.fwToast) fwToast("Mission " + m.id + ": " + m.title + " – " + goalText(m), "info");
      }, 900);
    } else {
      const name = $("fwBattlefield").value;
      const bf = name && BATTLEFIELDS.find((b) => b.name === name);
      if (bf) battlefield = bf;
      window.fwSuddenDeath = $("fwSuddenDeathOpt").checked;
      refreshArsenalLocks();
    }
    restoreResultButtons();
  });

  /* ------------------------------------------------------------------ */
  /* Objectives, timers and Sudden Death                                 */
  /* ------------------------------------------------------------------ */
  let lastT = 0,
    sdAnnounced = false;
  function endWith(core, reason) {
    window.__fwEndReason = reason;
    finishRound(core);
  }
  setInterval(() => {
    const inGame = menuHasGame && !gameOver && $("mainOverlay")?.hidden !== false;
    if (!inGame) {
      badge.hidden = true;
      return;
    }
    const t = fwMatchTime || 0;
    let dt = t - lastT;
    if (dt < 0 || dt > 1) dt = 0; // after loading a save or a new match
    lastT = t;
    const m = window.fwMission;
    let text = "";
    if (m) {
      if (m.goal === "survive") {
        text = "🛡 Halte durch · noch " + fmt(m.time - t);
        if (t >= m.time) return endWith(enemyCore, "Durchgehalten! Deine Verstärkung hat die Belagerer vernichtet.");
      } else if (m.timeLimit) {
        text = "⏱ Reaktor zerstören · noch " + fmt(m.timeLimit - t);
        if (t >= m.timeLimit) return endWith(playerCore, "Zeit abgelaufen – der Angriff ist gescheitert.");
      } else text = "🎯 Mission " + m.id + " · " + fmt(t);
    }
    if (window.fwSuddenDeath) {
      if (t >= SUDDEN_DEATH_AT) {
        text = "☠ SUDDEN DEATH – Reaktoren verlieren HP";
        if (!sdAnnounced) {
          sdAnnounced = true;
          if (window.fwToast) fwToast("☠ Sudden Death! Beide Reaktoren verlieren ab jetzt stetig HP. Wer mehr ausgeteilt hat, gewinnt.");
          if (window.fwVibrate) fwVibrate([120, 80, 120]);
        }
        const loss = 1.5 * dt,
          now = performance.now();
        const order = [playerCore, enemyCore].sort((a, b) => a.hp - b.hp);
        for (const core of order) {
          if (!core || core.dead || gameOver) continue;
          core.hp = Math.max(0, core.hp - loss);
          core.repairBlockedUntil = now + 1000;
          if (core.hp <= 0) {
            endWith(core, core.owner === "enemy" ? "Sudden Death: Der feindliche Reaktor gab zuerst nach." : "Sudden Death: Dein Reaktor gab zuerst nach.");
            break;
          }
        }
        hud();
      } else if (!m && SUDDEN_DEATH_AT - t <= 60) text = "☠ Sudden Death in " + fmt(SUDDEN_DEATH_AT - t);
    }
    badge.textContent = text;
    badge.hidden = !text;
  }, 250);

  /* ------------------------------------------------------------------ */
  /* Results: stars, next mission                                        */
  /* ------------------------------------------------------------------ */
  const restartBtn = $("resultRestart");
  const nextBtn = document.createElement("button");
  nextBtn.type = "button";
  nextBtn.id = "fwResultNext";
  nextBtn.hidden = true;
  const campBtn = document.createElement("button");
  campBtn.type = "button";
  campBtn.id = "fwResultCampaign";
  campBtn.textContent = "🏰 Kampagne";
  campBtn.hidden = true;
  restartBtn.after(nextBtn, campBtn);
  function restoreResultButtons() {
    restartBtn.textContent = "↻ Neue Runde";
    nextBtn.hidden = true;
    campBtn.hidden = true;
    $("fwResultStars")?.remove();
  }
  restartBtn.addEventListener(
    "click",
    (e) => {
      const m = window.fwMission;
      if (!m) return;
      e.stopImmediatePropagation();
      startMission(m);
    },
    true,
  );
  campBtn.onclick = () => {
    $("resultOverlay").hidden = true;
    openMainMenu();
    fwOpenCampaign();
  };

  const origEnd = window.fwOnMatchEnd;
  window.fwOnMatchEnd = function (win) {
    if (origEnd) origEnd(win);
    const m = window.fwMission;
    const reason = window.__fwEndReason;
    let stars = 0;
    if (m && win) {
      const hpRatio = playerCore ? playerCore.hp / (playerCore.maxHp || 500) : 0;
      stars = 1;
      if (hpRatio >= 0.5) stars++;
      if (m.goal === "survive" ? hpRatio >= 0.8 : (fwMatchTime || 0) <= m.par) stars++;
      const prog = progress();
      if ((prog[m.id] || 0) < stars) {
        prog[m.id] = stars;
        store.set(PROGRESS_KEY, prog);
      }
    }
    setTimeout(() => {
      if (reason) $("resultSubtitle").textContent = reason;
      if (!m) return;
      $("resultTitle").textContent = win ? "MISSION ERFÜLLT" : "MISSION GESCHEITERT";
      let s = $("fwResultStars");
      if (!s) {
        s = document.createElement("div");
        s.id = "fwResultStars";
        $("resultTitle").after(s);
      }
      s.textContent = win ? starsText(stars) : "";
      s.hidden = !win;
      restartBtn.textContent = "↻ Mission wiederholen";
      const idx = MISSIONS.indexOf(m);
      const next = MISSIONS[idx + 1];
      nextBtn.hidden = !(win && next);
      if (next) {
        nextBtn.textContent = "▶ Nächste Mission: " + next.title;
        nextBtn.onclick = () => startMission(next);
      }
      campBtn.hidden = false;
    }, 1520);
  };
})();

// V15.60: honest labels on the main-menu artwork (Multiplayer = BETA, More games = soon)
(function () {
  const chip = (forId, text, right, top) => {
    const target = document.getElementById(forId);
    if (!target) return;
    const c = document.createElement("span");
    c.className = "fwMenuChip";
    c.textContent = text;
    c.style.right = right;
    c.style.top = top;
    target.style.overflow = "visible";
    target.appendChild(c);
  };
  chip("onlineOpen", "BETA", "4%", "-14%");
  chip("fwMore", "BALD", "3%", "6%");
})();

// V15.60: "Große Schrift" option in the profile dialog
(function () {
  const KEY = "fw_large_text";
  const apply = (on) => document.documentElement.classList.toggle("fw-large-text", on);
  let on = false;
  try {
    on = localStorage.getItem(KEY) === "1";
  } catch (e) {}
  apply(on);
  const box = document.querySelector("#fwProfileDialog section");
  if (!box) return;
  const label = document.createElement("label");
  label.className = "fwProfileOpt";
  label.innerHTML = '<input type="checkbox" id="fwLargeText"> Große Schrift';
  const summary = document.getElementById("fwProfileSummary");
  (summary || box.querySelector("p")).after(label);
  const cb = label.querySelector("input");
  cb.checked = on;
  cb.addEventListener("change", () => {
    apply(cb.checked);
    try {
      localStorage.setItem(KEY, cb.checked ? "1" : "0");
    } catch (e) {}
  });
})();

// V15.60: privacy policy shown inside the app (no navigation away from the game)
window.fwShowPrivacy = function () {
  let d = document.getElementById("fwPrivacy");
  if (!d) {
    d = document.createElement("div");
    d.className = "fw1441Dialog";
    d.id = "fwPrivacy";
    d.innerHTML =
      '<section style="max-width:520px;height:85vh;display:flex;flex-direction:column;padding:12px"><iframe src="privacy.html" title="Datenschutzerklärung" style="flex:1;width:100%;border:0;border-radius:10px;background:#0d1724"></iframe><button type="button" onclick="this.closest(\'.fw1441Dialog\').hidden=true">Schließen</button></section>';
    document.body.appendChild(d);
  }
  d.hidden = false;
};
