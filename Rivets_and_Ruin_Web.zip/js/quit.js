// V15.60: "Beenden" – really closes the app (Android), after saving a running match.
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);

  // confirmation dialog
  const dlg = document.createElement("div");
  dlg.className = "fw1441Dialog";
  dlg.id = "fwQuitDialog";
  dlg.hidden = true;
  dlg.innerHTML =
    '<section role="dialog" aria-modal="true" aria-labelledby="fwQuitTitle">' +
    '<h2 id="fwQuitTitle">⏻ Spiel beenden?</h2><p id="fwQuitText"></p>' +
    '<button type="button" class="fwQuitConfirm" id="fwQuitConfirm">⏻ Beenden</button>' +
    '<button type="button" id="fwQuitCancel">Abbrechen</button></section>';
  document.body.appendChild(dlg);

  function openQuit() {
    const running = typeof menuHasGame !== "undefined" && menuHasGame && !gameOver;
    $("fwQuitText").textContent = running
      ? "Deine laufende Partie wird gespeichert – beim nächsten Start kannst du sie über „Spielen“ fortsetzen."
      : "Bis zum nächsten Gefecht, Kommandant!";
    $("menu") && ($("menu").hidden = true);
    dlg.hidden = false;
  }
  window.fwQuitGame = function () {
    try {
      if (window.fwSaveMatch) fwSaveMatch();
    } catch (e) {}
    const App = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App;
    if (App && App.exitApp) {
      App.exitApp();
      return;
    }
    // Browser: a page may not close itself unless it opened the window.
    window.close();
    setTimeout(() => {
      $("fwQuitText").textContent = "Im Browser kann sich das Spiel nicht selbst schließen – schließe einfach den Tab. Dein Spielstand ist gespeichert.";
    }, 300);
  };
  $("fwQuitConfirm").onclick = () => fwQuitGame();
  $("fwQuitCancel").onclick = () => (dlg.hidden = true);

  // power button on the main menu (next to the player icon)
  const panel = $("mainPanel");
  if (panel) {
    const b = document.createElement("button");
    b.type = "button";
    b.id = "fwQuit";
    b.setAttribute("aria-label", "Spiel beenden");
    b.title = "Spiel beenden";
    b.onclick = openQuit;
    panel.appendChild(b);
  }
  // entry in the in-game tools menu
  const menu = $("menu");
  if (menu) {
    const m = document.createElement("button");
    m.type = "button";
    m.textContent = "⏻ Spiel beenden";
    m.style.cssText = "width:100%;margin-bottom:8px";
    m.onclick = openQuit;
    const help = [...menu.querySelectorAll("button")].find((x) => x.textContent.includes("Anleitung"));
    (help || $("openMainFromTools"))?.after(m);
  }
})();
